
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class E1_NFCe
{
    private const string DllName = "E1_Notas.dll";

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int AbreCupomVenda(string chaveDeAcesso);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaIdentificacao(string UF, string cNF, string natOp, int mod, string serie, string nNF, string dhEmi, string dhSaiEnt, int tpNF, int idDest, string cMunFG, int tpImp, int tpEmis, int cDV, int tpAmb, int finNFe, int indFinal, int indPres, int indIntermed, int procEmi, string verProc, string dhCont, string xJust);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaEmitente(string CNPJ, string CPF, string xNome, string xFant, string xLgr, string nro, string xCpl, string xBairro, string cMun, string xMun, string UF, string CEP, string cPais, string xPais, string fone, string IE, string IEST, string IM, string CNAE, int CRT);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaProduto(string cProd, string cEAN, string xProd, string NCM, string NVE, string CEST, string indEscala, string CNPJFab, string cBenef, string EXTIPI, string CFOP, string uCom, string qCom, string vUnCom, string vProd, string cEANTrib, string uTrib, string qTrib, string vUnTrib, string vFrete, string vSeg, string vDesc, string vOutro, int indTot);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS40(int nItem, int orig, string CST, string vICMSDeson, int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaPISAliq(int nItem, string CST, string vBC, string pPIS, string vPIS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaCOFINSAliq(int nItem, string CST, string vBC, string pCOFINS, string vCOFINS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaPagamento(int indPag, string tPag, string vPag, int tpIntegra, string CNPJ, string tBand, string cAut);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaValorTroco(string vTroco);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int FechaCupomVenda(string path);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr EmitirNota(string caminho_arquivo);

    public static string EmitirNotaWrapper(string caminho_arquivo)
    {
        IntPtr ptr = EmitirNota(caminho_arquivo);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr ConsultarNota(string chave);

    public static string ConsultarNotaWrapper(string chave)
    {
        IntPtr ptr = ConsultarNota(chave);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr CancelarNota(string chave_nota, string protocolo, string justificativa);

    public static string CancelarNotaWrapper(string chave_nota, string protocolo, string justificativa)
    {
        IntPtr ptr = CancelarNota(chave_nota, protocolo, justificativa);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaAvulsa(string CNPJ, string xOrgao, string matr, string xAgente, string fone, string UF, string nDAR, string dEmi, string vDAR, string repEmi, string dPag);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaDestinatario(string CNPJ, string CPF, string idEstrangeiro, string xNome, string xLgr, string nro, string xCpl, string xBairro, string cMun, string xMun, string UF, string CEP, string cPais, string xPais, string fone, int indIEDest, string IE, string ISUF, string IM, string email);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaRetirada(string CNPJ, string CPF, string xNome, string xLgr, string nro, string xCpl, string xBairro, string cMun, string xMun, string UF, string CEP, string cPais, string xPais, string fone, string email, string IE);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaEntrega(string CNPJ, string CPF, string xNome, string xLgr, string nro, string xCpl, string xBairro, string cMun, string xMun, string UF, string CEP, string cPais, string xPais, string fone, string email, string IE);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaAutorizacaoXML(string CNPJ, string CPF);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS00(int nItem, int orig, string CST, int modBC, string vBC, string pICMS, string vICMS, string pFCP, string vFCP);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS10(int nItem, int orig, string CST, int modBC, string vBC, string pICMS, string vICMS, string vBCFCP, string pFCP, string vFCP, int modBCST, string pMVAST, string pRedBCST, string vBCST, string pICMSST, string vICMSST, string vBCFCPST, string pFCPST, string vFCPST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS20(int nItem, int orig, string CST, int modBC, string pRedBC, string vBC, string pICMS, string vICMS, string vBCFCP, string pFCP, string vFCP, string vICMSDeson, int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS30(int nItem, int orig, string CST, int modBCST, string pMVAST, string pRedBCST, string vBCST, string pICMSST, string vICMSST, string vBCFCPST, string pFCPST, string vFCPST, string vICMSDeson, int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS51(int nItem, int orig, string CST, int modBC, string pRedBC, string vBC, string pICMS, string vICMSOp, string pDif, string vICMSDif, string vICMS, string vBCFCP, string pFCP, string vFCP);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS60(int nItem, int orig, string CST, string vBCSTRet, string pST, string vICMSSubstituto, string vICMSSTRet, string vBCFCPSTRet, string pFCPSTRet, string vFCPSTRet, string pRedBCEfet, string vBCEfet, string pICMSEfet, string vICMSEfet);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS70(int nItem, int orig, string CST, int modBC, string pRedBC, string vBC, string pICMS, string vICMS, string vBCFCP, string pFCP, string vFCP, int modBCST, string pMVAST, string pRedBCST, string vBCST, string pICMSST, string vICMSST, string vBCFCPST, string pFCPST, string vFCPST, string vICMSDeson, int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMS90(int nItem, int orig, string CST, int modBC_a, string vBC_a, string pRedBCop_a, string pICMS_a, string vICMS_a, string vBCFCP_aa, string pFCP_aa, string vFCP_aa, int modBCST_b, string pMVASTop_b, string pRedBCSTop_b, string vBCST_b, string pICMSST_b, string vICMSST_b, string vBCFCPST_bb, string pFCPST_bb, string vFCPST_bb, string vICMSDeson_c, int motDesICMS_c);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMSPart(int nItem, int orig, string CST, int modBC, string vBC, string pRedBCop, string pICMS, string vICMS, int modBCST, string pMVASTop, string pRedBCSTop, string vBCST, string pICMSST, string vICMSST, string pBCOper, string UFST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int InformaICMSSN102(int nItem, int orig, string CSOSN);
}
