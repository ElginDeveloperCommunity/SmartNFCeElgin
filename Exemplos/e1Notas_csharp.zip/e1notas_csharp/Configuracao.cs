using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Configuracao
{
    public string CodigoMunicipio { get; set; }
    public string cUF { get; set; }
    
    // Emitente
    public string CNPJ { get; set; }
    public string IE { get; set; }
    public string RazaoSocial { get; set; }
    public string NomeFantasia { get; set; }
    public string Logradouro { get; set; }
    public string Numero { get; set; }
    public string Complemento { get; set; }
    public string Bairro { get; set; }
    public string CodigoMunicipioEmitente { get; set; }
    public string Municipio { get; set; }
    public string UF { get; set; }
    public string CEP { get; set; }
    public string CodigoPais { get; set; }
    public string Pais { get; set; }
    public string Fone { get; set; }
    public string IM { get; set; }
    public string CNAE { get; set; }
    public int CRT { get; set; }

    public static Configuracao Carregar(string caminhoArquivo = "dados.ini")
    {
        var config = new Configuracao();
        
        if (!File.Exists(caminhoArquivo))
        {
            throw new FileNotFoundException($"Arquivo de configuração não encontrado: {caminhoArquivo}");
        }

        var linhas = File.ReadAllLines(caminhoArquivo);
        string secaoAtual = "";

        foreach (var linha in linhas)
        {
            var linhaTratada = linha.Trim();
            
            // Ignorar linhas em branco ou comentários
            if (string.IsNullOrEmpty(linhaTratada) || linhaTratada.StartsWith(";") || linhaTratada.StartsWith("#"))
                continue;

            // Verificar se é uma nova seção
            if (linhaTratada.StartsWith("[") && linhaTratada.EndsWith("]"))
            {
                secaoAtual = linhaTratada.Substring(1, linhaTratada.Length - 2);
                continue;
            }

            // Processar chave-valor
            var partes = linhaTratada.Split(new char[] { '=' }, 2);
            if (partes.Length == 2)
            {
                var chave = partes[0].Trim();
                var valor = partes[1].Trim();

                switch (secaoAtual)
                {
                    case "IDENTIFICACAO":
                        if (chave == "CodigoMunicipio")
                            config.CodigoMunicipio = valor;
                        else if (chave == "cUF")
                            config.cUF = valor;
                        break;
                    case "EMITENTE":
                        switch (chave)
                        {
                            case "CNPJ":
                                config.CNPJ = valor;
                                break;
                            case "IE":
                                config.IE = valor;
                                break;
                            case "RazaoSocial":
                                config.RazaoSocial = valor;
                                break;
                            case "NomeFantasia":
                                config.NomeFantasia = valor;
                                break;
                            case "Logradouro":
                                config.Logradouro = valor;
                                break;
                            case "Numero":
                                config.Numero = valor;
                                break;
                            case "Complemento":
                                config.Complemento = valor;
                                break;
                            case "Bairro":
                                config.Bairro = valor;
                                break;
                            case "CodigoMunicipio":
                                config.CodigoMunicipioEmitente = valor;
                                break;
                            case "Municipio":
                                config.Municipio = valor;
                                break;
                            case "UF":
                                config.UF = valor;
                                break;
                            case "CEP":
                                config.CEP = valor;
                                break;
                            case "CodigoPais":
                                config.CodigoPais = valor;
                                break;
                            case "Pais":
                                config.Pais = valor;
                                break;
                            case "Fone":
                                config.Fone = valor;
                                break;
                            case "IM":
                                config.IM = valor;
                                break;
                            case "CNAE":
                                config.CNAE = valor;
                                break;
                            case "CRT":
                                if (int.TryParse(valor, out int crt))
                                    config.CRT = crt;
                                break;
                        }
                        break;
                }
            }
        }

        return config;
    }
}