using System;
using System.Runtime.InteropServices;
using System.Text;

public static class E1NotasWrapper
{
    private const string DllName = "E1_Notas.dll";
    private const string DllImpressoraName = "E1_Impressora01.dll";
    private const string DllPdfName = "E1_Pdf.dll";

    // FUNCOES CONSTRUCAO
    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int AbreCupomVenda([MarshalAs(UnmanagedType.LPUTF8Str)] string chaveDeAcesso);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaIdentificacao(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cUF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cNF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string natOp, 
        int mod, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string serie, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nNF,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dhEmi, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dhSaiEnt, 
        int tpNF, 
        int idDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMunFG, 
        int tpImp,
        int tpEmis, 
        int cDV, 
        int tpAmb, 
        int finNFe, 
        int indFinal, 
        int indPres,
        int indIntermed, 
        int procEmi, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string verProc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dhCont, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xJust);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaEmitente(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xNome, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xFant, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLgr, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nro,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCpl, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xBairro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CEP,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string fone, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IE, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IEST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IM,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNAE, 
        int CRT);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaProduto(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cEAN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string NCM, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string NVE, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CEST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string indEscala, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJFab, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cBenef, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string EXTIPI, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CFOP,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uCom, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qCom, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vUnCom, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cEANTrib,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uTrib, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qTrib, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vUnTrib, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFrete, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vSeg,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDesc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vOutro, 
        int indTot);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS40(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSDeson, 
        int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaPISAliq(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pPIS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPIS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCOFINSAliq(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pCOFINS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCOFINS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaValorTotalTributos(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vTotTrib);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaPagamento(
        int indPagOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tPag, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xPagOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPag, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dPagOp,
        int tpIntegra, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tBandOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cAutOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJRecebOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string idTermPagOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaInformacoesPagamento(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vTrocoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJPag_a, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFPag_a);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaInformacoesAdicionais(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string infAdFiscoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string infCplOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaObservacoesContribuinte(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCampo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xTexto);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaObservacoesFisco(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCampo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xTexto);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaProcessoReferenciado(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nProc, 
        int indProc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tpAtoOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int FechaCupomVenda([MarshalAs(UnmanagedType.LPUTF8Str)] string path);

    // FUNCOES TRANSMISSAO
    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr EmitirNota(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uuid);
    public static string EmitirNotaWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uuid)
    {
        IntPtr ptr = EmitirNota(path, uuid);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr ConsultarNota([MarshalAs(UnmanagedType.LPUTF8Str)] string chave);
    public static string ConsultarNotaWrapper([MarshalAs(UnmanagedType.LPUTF8Str)] string chave)
    {
        IntPtr ptr = ConsultarNota(chave);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr ConsultarStatus([MarshalAs(UnmanagedType.LPUTF8Str)] string uuid);
    public static string ConsultarStatusWrapper([MarshalAs(UnmanagedType.LPUTF8Str)] string uuid)
    {
        IntPtr ptr = ConsultarStatus(uuid);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr CancelarNota(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chave_nota, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string protocolo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string justificativa);
    public static string CancelarNotaWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chave_nota, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string protocolo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string justificativa)
    {
        IntPtr ptr = CancelarNota(chave_nota, protocolo, justificativa);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr CancelamentoPorSubstituicao(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chCFe, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chCFeRef, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string justificativa, 
        int tpAutor);
    public static string CancelamentoPorSubstituicaoWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chCFe, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chCFeRef, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string justificativa, 
        int tpAutor)
    {
        IntPtr ptr = CancelamentoPorSubstituicao(chCFe, chCFeRef, justificativa, tpAutor);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr CartaDeCorrecao(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chCFe, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCorrecao);
    public static string CartaDeCorrecaoWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chCFe, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCorrecao)
    {
        IntPtr ptr = CartaDeCorrecao(chCFe, xCorrecao);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaAvulsa(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xOrgao, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string matr, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xAgente, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string fone,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nDAR, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dEmi, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDAR, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string repEmi, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dPag);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDestinatario(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string idEstrangeiro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xNome, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLgr,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCpl, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xBairro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CEP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string fone, 
        int indIEDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IE,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string ISUF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IM, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string email);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaRetirada(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xNome, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLgr, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCpl,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xBairro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CEP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cPais,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string fone, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string email, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IE);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaEntrega(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xNome, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLgr, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCpl,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xBairro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CEP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cPais,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string fone, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string email, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IE);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaAutorizacaoXML(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPF);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS00(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCP);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS10(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCP, 
        int modBCST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVAST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS20(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCP,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSDeson, 
        int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS30(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVAST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSDeson, 
        int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS51(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pDif, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSDif, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCP);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS60(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSubstituto, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPSTRet,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSEfet);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS70(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCP,
        int modBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVAST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSDeson,
        int motDesICMS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS90(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC_a, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC_a, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCop_a,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS_a, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS_a, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCP_aa, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCP_aa, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCP_aa,
        int modBCST_b, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVASTop_b, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCSTop_b, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST_b,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST_b, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST_b, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST_bb, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST_bb,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST_bb, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSDeson_c, 
        int motDesICMS_c);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSPart(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCop,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS, 
        int modBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVASTop, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCSTop,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pBCOper, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSSN102(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CSOSN);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr InutilizarNumeracao(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cnpj, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string ano, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string justificativa, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uf, 
        int tpAmb,
        int serie, 
        int numeroInicial, 
        int numeroFinal);
    public static string InutilizarNumeracaoWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cnpj, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string ano, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string justificativa, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uf, 
        int tpAmb,
        int serie, 
        int numeroInicial, 
        int numeroFinal)
    {
        IntPtr ptr = InutilizarNumeracao(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr ProcessamentoContingencia();
    public static string ProcessamentoContingenciaWrapper()
    {
        IntPtr ptr = ProcessamentoContingencia();
        return Marshal.PtrToStringAnsi(ptr);
    }

    // FUNCOES PDF
    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int LoadPDF();

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr ConfigurarDiretorioSaidaPDF([MarshalAs(UnmanagedType.LPUTF8Str)] string path);
    public static string ConfigurarDiretorioSaidaPDFWrapper([MarshalAs(UnmanagedType.LPUTF8Str)] string path)
    {
        IntPtr ptr = ConfigurarDiretorioSaidaPDF(path);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr GerarDanfeNFCePDF(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        int indexcsc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string csc);
    public static string GerarDanfeNFCePDFWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        int indexcsc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string csc)
    {
        IntPtr ptr = GerarDanfeNFCePDF(path, indexcsc, csc);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr GerarDanfeNFCePersonalizadoPDF(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        int indexcsc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string csc, 
        int param);
    public static string GerarDanfeNFCePersonalizadoPDFWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        int indexcsc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string csc, 
        int param)
    {
        IntPtr ptr = GerarDanfeNFCePersonalizadoPDF(path, indexcsc, csc, param);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr GerarDanfeNFePDF(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string logoPath);
    public static string GerarDanfeNFePDFWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string logoPath)
    {
        IntPtr ptr = GerarDanfeNFePDF(path, logoPath);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr GerarDanfeNFePersonalizadoPDF(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string logoPath, 
        int layout, 
        int param);
    public static string GerarDanfeNFePersonalizadoPDFWrapper(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string logoPath, 
        int layout, 
        int param)
    {
        IntPtr ptr = GerarDanfeNFePersonalizadoPDF(path, logoPath, layout, param);
        return Marshal.PtrToStringAnsi(ptr);
    }

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int UnloadPDF();

    // FUNCOES IMPRESSORA
    [DllImport(DllImpressoraName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int AbreConexaoImpressora(
        int tipo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string modelo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string conexao, 
        int param);

    [DllImport(DllImpressoraName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int FechaConexaoImpressora();

    [DllImport(DllImpressoraName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int Corte(int avanco);

    [DllImport(DllImpressoraName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int ImprimeXMLNFCe(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dados, 
        int indexcsc, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string csc, 
        int param);

    [DllImport(DllImpressoraName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int ImprimeXMLCancelamentoNFCe(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dados, 
        int param);

    // Additional functions from the header file
    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDocumentoReferenciadoNFe(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string refNFeEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string refNFeSigEx);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDocumentoReferenciadoNF(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cUF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string AAMM, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string mod, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string serie, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nNF);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDocumentoReferenciadoNFP(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cUF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string AAMM, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPFEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IE, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string mod, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string serie, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nNF);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDocumentoReferenciadoCTe([MarshalAs(UnmanagedType.LPUTF8Str)] string refCTeEx);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDocumentoReferenciadoECF(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string mod, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nECF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nCOO);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaInformacoesAdicionaisProduto(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string infAdProd);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDeclaracaoImportacao(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nDI, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dDI, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLocDesemb, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFDesemb,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dDesemb, 
        int tpViaTransp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAFRMMOp, 
        int tpIntermedio,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPFEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFTerceiroOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cExportador);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaAdicaoDeclaracaoImportacao(
        int nItem, 
        int nDI, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nAdicaoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nSeqAdic, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cFabricante,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDescDIOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nDrawOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDetalhamentoExportacao(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nDrawOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaRastreabilidade(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nLote, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qLote, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dFab, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dVal, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cAgregOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaVeiculoNovo(
        int nItem, 
        int tpOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chassi, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cCor, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCor, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pot,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cilin, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pesoL, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pesoB, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nSerie, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tpComb,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nMotor, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CMT, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dist, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string anoMod, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string anoFab,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tpPint, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tpVeic, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string espVeic, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string VIN, 
        int condVeic,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMod, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cCorDENATRAN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string lota, 
        int tpRest);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaMedicamento(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cProdANVISA, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xMotivoIsencaoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPMC);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaArmamento(
        int nItem, 
        int tpArma, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nSerie, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nCano, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string descr);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCombustivel(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cProdANP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string descANP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pGLPOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pGNnOp,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pGNiOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPartOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CODIFOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qTempOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFCons, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pBioOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCombustivelCIDE(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCIDE);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCombustivelEncerrante(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nBico, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nBombaOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nTanque, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vEncIni, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vEncFin);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCombustivelOrigem(
        int nItem, 
        int indImport, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cUFOrig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pOrig);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS02(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCMonoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string adRemICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMono);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS15(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCMonoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string adRemICMS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMono,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCMonoRetenOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string adRemICMSReten, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMonoReten, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedAdRem_a, 
        int motRedAdRem_a);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS53(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCMonoOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string adRemICMSOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMonoOperOp,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pDifOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMonoDifOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMonoOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMS61(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCMonoRetOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string adRemICMSRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSMonoRet);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSST(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSubstituto,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPSTRet,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCSTDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSTDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCEfet,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSEfet);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSSN101(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CSOSN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pCredSN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCredICMSSN);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSSN201(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CSOSN, 
        int modBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVAST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pCredSN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCredICMSSN);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSSN202(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CSOSN, 
        int modBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVAST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSSN500(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CSOSN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSubstituto,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPSTRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPSTRet,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSEfet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSEfet);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSSN900(
        int nItem, 
        int orig, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CSOSN, 
        int modBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMS,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMS, 
        int modBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pMVAST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pRedBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pCredSN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCredICMSSN);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaICMSUFDest(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCUFDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCFCPUFDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pFCPUFDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSUFDest,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSInter, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSInterPart, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFCPUFDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSUFDest, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSUFRemet);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaIPITrib(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cSelo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qSelo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cEnq, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pIPI, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qUnid, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vUnid, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vIPI);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaIPINT(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cSelo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qSelo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cEnq, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaII(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDespAdu, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vII, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vIOF);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaPISQtde(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPIS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaPISNT(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaPISOutr(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pPIS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd_bEx,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd_bEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPIS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaPISST(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pPIS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vPIS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCOFINSQtde(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCOFINS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCOFINSNT(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCOFINSOutr(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CST, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pCOFINS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCOFINS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCOFINSST(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pCOFINS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qBCProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliqProd, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vCOFINS);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaISSQN(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBC, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vAliq, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vISSQN, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMunFG, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cListServ,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDeducao, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vOutro, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDescIncond, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDescCond, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vISSRet,
        int indISS, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cServico, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMun, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nProcesso, 
        int indIncentivo);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaIPIDevolvido(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pDevol, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vIPIDevol);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaObservacaoContribuinteItem(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCampo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xTexto);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaObservacaoFiscoItem(
        int nItem, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xCampo, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xTexto);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaTransporte(
        int modFrete, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vagaoEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string balsaEx);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaTransportador(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CPFEx, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xNomeOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string IEOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xEnderOp,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xMunOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaRetencaoTransporte(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vServ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vBCRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pICMSRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vICMSRet, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CFOP, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string cMunFG);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaVeiculoTransporte(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string placa, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string RNTCOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaReboque(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string placa, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UF, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string RNTCOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaVolume(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qVolOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string espOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string marcaOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nVolOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pesoLOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string pesoBOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaLacre(
        int nVolume, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nLacre);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaFatura(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nFatOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vOrigOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDescOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vLiqOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaParcela(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string nDupOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dVencOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDup);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaIntermediador(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string idCadIntTran);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaExportacao(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string UFSaidaPais, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLocExporta, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xLocDespachoOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCompra(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xNEmpOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xPedOp, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xContOp);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaCana(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string safra, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string referencia, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qTotMes, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qTotAnt, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qTotGer,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vFor, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vTotDed, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vLiqFor);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaFornecimentoDiarioCana(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string dia, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qtde);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaDeducaoCana(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xDed, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string vDed);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaResponsavelTecnico(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string CNPJ, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string xContato, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string email, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string fone, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string idCSRT_a, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string hashCSRT_a);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern int InformaInformacoesSuplementares(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string qrCode, 
        [MarshalAs(UnmanagedType.LPUTF8Str)] string urlChave);
}