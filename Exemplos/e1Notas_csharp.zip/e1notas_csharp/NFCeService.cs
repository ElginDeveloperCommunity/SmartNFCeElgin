using System;
using System.IO;

public class NFCeService
{
    private readonly Configuracao _config;
    private static string _lastUuid = null;
    private const string UUID_FILE = "last_uuid.txt";
    
    public NFCeService(Configuracao config)
    {
        _config = config;
        LoadLastUuid();
    }
    
    private void SaveLastUuid(string uuid)
    {
        _lastUuid = uuid;
        try
        {
            File.WriteAllText(UUID_FILE, uuid);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao salvar UUID: {ex.Message}");
        }
    }
    
    private void LoadLastUuid()
    {
        try
        {
            if (File.Exists(UUID_FILE))
            {
                _lastUuid = File.ReadAllText(UUID_FILE).Trim();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao carregar UUID: {ex.Message}");
        }
    }

    public void EmitirNFCeExemplo()
    {
        try
        {
            // Abre o cupom de venda
            int ret = E1NotasWrapper.AbreCupomVenda("12345678901234567890123456789012345678901234");
            Console.WriteLine($"Retorno AbreCupomVenda: {ret}");

            // Informa identificação
            ret = E1NotasWrapper.InformaIdentificacao(
                _config.cUF,        // cUF
                "",                 // cNF
                "venda",            // natOp
                65,                 // mod (65 para NFCe)
                "",                 // serie
                "",                 // nNF
                "",                 // dhEmi
                "",                 // dhSaiEnt
                1,                  // tpNF
                1,                  // idDest
                _config.CodigoMunicipio, // cMunFG
                5,                  // tpImp (5 para DANFE NFC-e em mensagem eletrônica)
                0,                  // tpEmis
                0,                  // cDV
                0,                  // tpAmb (0 para homologação)
                1,                  // finNFe
                1,                  // indFinal
                1,                  // indPres
                0,                  // indIntermed
                0,                  // procEmi
                "",                 // verProc
                "",                 // dhCont
                ""                  // xJust
            );
            Console.WriteLine($"Retorno InformaIdentificacao: {ret}");

            // Informa emitente
            ret = E1NotasWrapper.InformaEmitente(
                _config.CNPJ,           // CNPJ
                "",                     // CPF
                _config.RazaoSocial,    // xNome
                _config.NomeFantasia,   // xFant
                _config.Logradouro,     // xLgr
                _config.Numero,         // nro
                _config.Complemento,    // xCpl
                _config.Bairro,         // xBairro
                _config.CodigoMunicipioEmitente, // cMun
                _config.Municipio,      // xMun
                _config.UF,             // UF
                _config.CEP,            // CEP
                _config.CodigoPais,     // cPais
                _config.Pais,           // xPais
                _config.Fone,           // fone
                _config.IE,             // IE
                "",                     // IEST
                _config.IM,             // IM
                _config.CNAE,           // CNAE
                _config.CRT             // CRT
            );
            Console.WriteLine($"Retorno InformaEmitente: {ret}");

            // Adiciona produto e impostos
            ret = E1NotasWrapper.InformaProduto(
                "123",              // cProd
                "SEM GTIN",         // cEAN
                "Pães e doces produtos", // xProd
                "22030000",         // NCM
                "",                 // NVE
                "0302100",          // CEST
                "S",                // indEscala
                "",                 // CNPJFab
                "",                 // cBenef
                "",                 // EXTIPI
                "5102",             // CFOP
                "UN",               // uCom
                "1.0000",           // qCom
                "1.00",             // vUnCom
                "",                 // vProd
                "SEM GTIN",         // cEANTrib
                "UN",               // uTrib
                "1.0000",           // qTrib
                "1.00",             // vUnTrib
                "",                 // vFrete
                "",                 // vSeg
                "",                 // vDesc
                "",                 // vOutro
                1                   // indTot
            );
            Console.WriteLine($"Retorno InformaProduto: {ret}");

            // ICMS
            ret = E1NotasWrapper.InformaICMSSN102(1, 0, "102");
            Console.WriteLine($"Retorno InformaICMSSN102: {ret}");

            // PIS
            ret = E1NotasWrapper.InformaPISAliq(1, "99", "1.00", "1.65", "0.02");
            Console.WriteLine($"Retorno InformaPISAliq: {ret}");

            // COFINS
            ret = E1NotasWrapper.InformaCOFINSAliq(1, "01", "1.00", "7.60", "0.08");
            Console.WriteLine($"Retorno InformaCOFINSAliq: {ret}");

            // Pagamento
            ret = E1NotasWrapper.InformaPagamento(
                0,          // indPagOp
                "01",       // tPag
                "",         // xPagOp
                "100.00",   // vPag
                "",         // dPagOp
                0,          // tpIntegra
                "",         // CNPJOp
                "",         // tBandOp
                "",         // cAutOp
                "",         // CNPJRecebOp
                ""          // idTermPagOp
            );
            Console.WriteLine($"Retorno InformaPagamento: {ret}");

            // Fecha o cupom
            ret = E1NotasWrapper.FechaCupomVenda("./venda_nfce.xml");
            Console.WriteLine($"Retorno FechaCupomVenda: {ret}");

            // Emite a nota
            string uuid = Guid.NewGuid().ToString();
            string result = E1NotasWrapper.EmitirNotaWrapper("./venda_nfce.xml", uuid);
            Console.WriteLine($"Retorno EmitirNota: {result}");
            
            // Salva o UUID para uso posterior
            SaveLastUuid(uuid);
            Console.WriteLine($"UUID salvo: {uuid}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao emitir NFCe: {ex.Message}");
        }
    }

    public void EmitirNFeExemplo()
    {
        try
        {
            // Abre o cupom de venda
            int ret = E1NotasWrapper.AbreCupomVenda("12345678901234567890123456789012345678901234");
            Console.WriteLine($"Retorno AbreCupomVenda: {ret}");

            // Informa identificação
            ret = E1NotasWrapper.InformaIdentificacao(
                _config.cUF,        // cUF
                "",                 // cNF
                "venda",            // natOp
                55,                 // mod (55 para NFe)
                "",                 // serie
                "",                 // nNF
                "",                 // dhEmi
                "",                 // dhSaiEnt
                1,                  // tpNF
                1,                  // idDest
                _config.CodigoMunicipio, // cMunFG
                0,                  // tpImp (0 para sem DANFE)
                0,                  // tpEmis
                0,                  // cDV
                0,                  // tpAmb (0 para homologação)
                1,                  // finNFe
                1,                  // indFinal
                1,                  // indPres
                0,                  // indIntermed
                0,                  // procEmi
                "",                 // verProc
                "",                 // dhCont
                ""                  // xJust
            );
            Console.WriteLine($"Retorno InformaIdentificacao: {ret}");

            // Informa emitente
            ret = E1NotasWrapper.InformaEmitente(
                _config.CNPJ,           // CNPJ
                "",                     // CPF
                _config.RazaoSocial,    // xNome
                _config.NomeFantasia,   // xFant
                _config.Logradouro,     // xLgr
                _config.Numero,         // nro
                _config.Complemento,    // xCpl
                _config.Bairro,         // xBairro
                _config.CodigoMunicipioEmitente, // cMun
                _config.Municipio,      // xMun
                _config.UF,             // UF
                _config.CEP,            // CEP
                _config.CodigoPais,     // cPais
                _config.Pais,           // xPais
                _config.Fone,           // fone
                _config.IE,             // IE
                "",                     // IEST
                _config.IM,             // IM
                _config.CNAE,           // CNAE
                _config.CRT             // CRT
            );
            Console.WriteLine($"Retorno InformaEmitente: {ret}");

            // Informa destinatário
            ret = E1NotasWrapper.InformaDestinatario(
                "",                                 // CNPJ
                "45762835880",                      // CPF
                "",                                 // idEstrangeiro
                "NF-E EMITIDA EM AMBIENTE DE HOMOLOGAÇÃO - SEM VALOR FISCAL", // xNome
                "Rua das Flores",                   // xLgr
                "123",                              // nro
                "",                                 // xCpl
                "Centro",                           // xBairro
                "3550308",                          // cMun
                "São Paulo",                        // xMun
                "SP",                               // UF
                "01001000",                         // CEP
                "1058",                             // cPais
                "Brasil",                           // xPais
                "",                                 // fone
                9,                                  // indIEDest
                "",                                 // IE
                "",                                 // ISUF
                "",                                 // IM
                ""                                  // email
            );
            Console.WriteLine($"Retorno InformaDestinatario: {ret}");

            // Adiciona produto e impostos
            ret = E1NotasWrapper.InformaProduto(
                "123",              // cProd
                "SEM GTIN",         // cEAN
                "NFCe - Homologação", // xProd
                "22030000",         // NCM
                "",                 // NVE
                "0302100",          // CEST
                "S",                // indEscala
                "",                 // CNPJFab
                "",                 // cBenef
                "",                 // EXTIPI
                "5102",             // CFOP
                "UN",               // uCom
                "1.0000",           // qCom
                "1.00",             // vUnCom
                "",                 // vProd
                "SEM GTIN",         // cEANTrib
                "UN",               // uTrib
                "1.0000",           // qTrib
                "1.00",             // vUnTrib
                "",                 // vFrete
                "",                 // vSeg
                "",                 // vDesc
                "",                 // vOutro
                1                   // indTot
            );
            Console.WriteLine($"Retorno InformaProduto: {ret}");

            // ICMS
            ret = E1NotasWrapper.InformaICMSSN102(1, 0, "102");
            Console.WriteLine($"Retorno InformaICMSSN102: {ret}");

            // PIS
            ret = E1NotasWrapper.InformaPISAliq(1, "99", "1.00", "1.65", "0.02");
            Console.WriteLine($"Retorno InformaPISAliq: {ret}");

            // COFINS
            ret = E1NotasWrapper.InformaCOFINSAliq(1, "01", "1.00", "7.60", "0.08");
            Console.WriteLine($"Retorno InformaCOFINSAliq: {ret}");

            // Pagamento
            ret = E1NotasWrapper.InformaPagamento(
                0,          // indPagOp
                "01",       // tPag
                "",         // xPagOp
                "100.00",   // vPag
                "",         // dPagOp
                0,          // tpIntegra
                "",         // CNPJOp
                "",         // tBandOp
                "",         // cAutOp
                "",         // CNPJRecebOp
                ""          // idTermPagOp
            );
            Console.WriteLine($"Retorno InformaPagamento: {ret}");

            // Fecha o cupom
            ret = E1NotasWrapper.FechaCupomVenda("./venda_nfe.xml");
            Console.WriteLine($"Retorno FechaCupomVenda: {ret}");

            // Emite a nota
            string uuid = Guid.NewGuid().ToString();
            string result = E1NotasWrapper.EmitirNotaWrapper("./venda_nfe.xml", uuid);
            Console.WriteLine($"Retorno EmitirNota: {result}");
            
            // Salva o UUID para uso posterior
            SaveLastUuid(uuid);
            Console.WriteLine($"UUID salvo: {uuid}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao emitir NFe: {ex.Message}");
        }
    }

    public void CancelarNFCe()
    {
        try
        {
            Console.Write("Digite a chave da NFCe que deseja cancelar: ");
            string chaveNFCe = Console.ReadLine();
            
            Console.Write("Digite o protocolo de autorização: ");
            string protocolo = Console.ReadLine();
            
            Console.Write("Digite a justificativa do cancelamento (mínimo 15 caracteres): ");
            string justificativa = Console.ReadLine();
            
            if (justificativa.Length < 15)
            {
                Console.WriteLine("A justificativa deve ter no mínimo 15 caracteres!");
                return;
            }
            
            string result = E1NotasWrapper.CancelarNotaWrapper(chaveNFCe, protocolo, justificativa);
            Console.WriteLine($"Retorno CancelarNota: {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao cancelar NFCe: {ex.Message}");
        }
    }

    public void GerarPDFNFCePersonalizado()
    {
        try
        {
            Console.Write("Digite o caminho do arquivo XML da NFCe: ");
            string caminhoXml = Console.ReadLine();
            
            if (!File.Exists(caminhoXml))
            {
                Console.WriteLine("Arquivo XML não encontrado!");
                return;
            }
            
            Console.Write("Digite o diretório de saída para o PDF (ou pressione ENTER para padrão): ");
            string diretorioSaida = Console.ReadLine();
            
            Console.Write("Digite o índice do CSC: ");
            int indexCsc = int.Parse(Console.ReadLine());
            
            Console.Write("Digite o CSC: ");
            string csc = Console.ReadLine();
            
            Console.Write("Digite o layout (0=Padrão, 1=Personalizado): ");
            int layout = int.Parse(Console.ReadLine());
            
            Console.Write("Digite o parâmetro adicional: ");
            int parametro = int.Parse(Console.ReadLine());
            
            // Inicializar o módulo PDF
            int ret = E1NotasWrapper.LoadPDF();
            Console.WriteLine($"Retorno LoadPDF: {ret}");
            
            if (ret != 0)
            {
                Console.WriteLine("Erro ao inicializar o módulo PDF!");
                return;
            }
            
            try
            {
                // Configurar diretório de saída se especificado
                if (!string.IsNullOrEmpty(diretorioSaida))
                {
                    string configResult = E1NotasWrapper.ConfigurarDiretorioSaidaPDFWrapper(diretorioSaida);
                    Console.WriteLine($"Retorno ConfigurarDiretorioSaidaPDF: {configResult}");
                }
                
                // Gerar o PDF personalizado
                string pdfResult = E1NotasWrapper.GerarDanfeNFCePersonalizadoPDFWrapper(caminhoXml, indexCsc, csc, parametro);
                Console.WriteLine($"Retorno GerarDanfeNFCePersonalizadoPDF: {pdfResult}");
            }
            finally
            {
                // Finalizar o módulo PDF
                ret = E1NotasWrapper.UnloadPDF();
                Console.WriteLine($"Retorno UnloadPDF: {ret}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao gerar PDF NFCe: {ex.Message}");
        }
    }

    public void GerarPDFNFePersonalizado()
    {
        try
        {
            Console.Write("Digite o caminho do arquivo XML da NFe: ");
            string caminhoXml = Console.ReadLine();
            
            if (!File.Exists(caminhoXml))
            {
                Console.WriteLine("Arquivo XML não encontrado!");
                return;
            }
            
            Console.Write("Digite o caminho do logo (ou pressione ENTER para não usar logo): ");
            string caminhoLogo = Console.ReadLine();
            
            // Verificar se o logo existe (se foi informado)
            if (!string.IsNullOrEmpty(caminhoLogo) && !File.Exists(caminhoLogo))
            {
                Console.WriteLine("Arquivo de logo não encontrado! Continuando sem logo...");
                caminhoLogo = "";
            }
            
            Console.Write("Digite o layout (0=Retrato, 1=Paisagem): ");
            int layout = int.Parse(Console.ReadLine());
            
            Console.Write("Digite o parâmetro adicional: ");
            int parametro = int.Parse(Console.ReadLine());
            
            // Gerar o PDF personalizado da NFe
            string resultStr = E1NotasWrapper.GerarDanfeNFePersonalizadoPDFWrapper(caminhoXml, caminhoLogo, layout, parametro);
            Console.WriteLine($"Retorno GerarDanfeNFePersonalizadoPDF: {resultStr}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao gerar PDF NFe: {ex.Message}");
        }
    }

    public void ImprimirNFCe()
    {
        try
        {
            Console.WriteLine("=== IMPRESSÃO DE NFCe ===");
            Console.WriteLine("1 - Imprimir NFCe de Venda");
            Console.WriteLine("2 - Imprimir NFCe de Cancelamento");
            Console.Write("Escolha o tipo de operação: ");
            int tipoOperacao = int.Parse(Console.ReadLine());
            
            if (tipoOperacao != 1 && tipoOperacao != 2)
            {
                Console.WriteLine("Opção inválida!");
                return;
            }
            
            // Solicitar o caminho do XML
            Console.Write("Digite o caminho do arquivo XML da NFCe: ");
            string caminhoXml = Console.ReadLine();
            
            if (!File.Exists(caminhoXml))
            {
                Console.WriteLine("Arquivo XML não encontrado!");
                return;
            }
            
            // Ler o conteúdo do arquivo XML
            string xmlContent;
            try
            {
                xmlContent = File.ReadAllText(caminhoXml, System.Text.Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ler o arquivo XML: {ex.Message}");
                return;
            }
            
            // Configuração da impressora
            Console.WriteLine("\n=== CONFIGURAÇÃO DA IMPRESSORA ===");
            Console.WriteLine("Tipos de conexão:");
            Console.WriteLine("1 - USB");
            Console.WriteLine("2 - RS232");
            Console.WriteLine("3 - TCP/IP");
            Console.WriteLine("4 - Bluetooth");
            Console.WriteLine("5 - Impressoras acopladas (Android)");
            Console.Write("Digite o tipo de conexão: ");
            int tipoImpressora = int.Parse(Console.ReadLine());
            
            if (tipoImpressora < 1 || tipoImpressora > 5)
            {
                Console.WriteLine("Tipo de impressora inválido!");
                return;
            }
            
            string modelo, conexao;
            int parametro;
            
            if (tipoImpressora == 5)
            {
                // Para impressoras acopladas (Android), modelo e conexão são vazios
                modelo = "";
                conexao = "";
                parametro = 0;
            }
            else
            {
                Console.WriteLine("\nModelos disponíveis:");
                Console.WriteLine("i7, i7 Plus, i8, i9, ix, Fitpos, BK-T681, MP-4200, MP-4200 HS, MP-2800");
                Console.Write("Digite o modelo da impressora: ");
                modelo = Console.ReadLine();
                Console.Write("Digite a conexão (ex: USB, COM2, 192.168.0.20, AA:BB:CC:DD:EE:FF): ");
                conexao = Console.ReadLine();
                
                if (tipoImpressora == 1 || tipoImpressora == 4)
                {
                    parametro = 0; // USB e Bluetooth não precisam de parâmetro
                }
                else if (tipoImpressora == 2)
                {
                    Console.Write("Digite o baudrate para RS232: ");
                    parametro = int.Parse(Console.ReadLine());
                }
                else if (tipoImpressora == 3)
                {
                    Console.Write("Digite a porta TCP/IP: ");
                    parametro = int.Parse(Console.ReadLine());
                }
                else
                {
                    parametro = 0;
                }
            }
            
            // Abrir conexão com a impressora
            Console.WriteLine("\nAbrindo conexão com a impressora...");
            int ret = E1NotasWrapper.AbreConexaoImpressora(tipoImpressora, modelo, conexao, parametro);
            Console.WriteLine($"Retorno AbreConexaoImpressora: {ret}");
            
            if (ret != 0)
            {
                Console.WriteLine("Erro ao conectar com a impressora!");
                return;
            }
            
            try
            {
                // Imprimir conforme o tipo de operação
                if (tipoOperacao == 1)
                {
                    // Impressão de NFCe de venda
                    Console.Write("Digite o índice do CSC: ");
                    int indexCsc = int.Parse(Console.ReadLine());
                    Console.Write("Digite o CSC: ");
                    string csc = Console.ReadLine();
                    Console.Write("Digite o parâmetro adicional (ou 0 para padrão): ");
                    int param = int.Parse(Console.ReadLine());
                    
                    Console.WriteLine("Imprimindo NFCe de venda...");
                    ret = E1NotasWrapper.ImprimeXMLNFCe(xmlContent, indexCsc, csc, param);
                    Console.WriteLine($"Retorno ImprimeXMLNFCe: {ret}");
                }
                else
                {
                    // Impressão de NFCe de cancelamento
                    Console.Write("Digite o parâmetro adicional (ou 0 para padrão): ");
                    int param = int.Parse(Console.ReadLine());
                    
                    Console.WriteLine("Imprimindo NFCe de cancelamento...");
                    ret = E1NotasWrapper.ImprimeXMLCancelamentoNFCe(xmlContent, param);
                    Console.WriteLine($"Retorno ImprimeXMLCancelamentoNFCe: {ret}");
                }
                
                if (ret == 0)
                {
                    Console.WriteLine("Impressão realizada com sucesso!");
                    
                    // Realizar o corte do papel
                    Console.WriteLine("Realizando corte do papel...");
                    ret = E1NotasWrapper.Corte(5);
                    Console.WriteLine($"Retorno Corte: {ret}");
                }
                else
                {
                    Console.WriteLine("Erro na impressão!");
                }
            }
            finally
            {
                // Fechar conexão com a impressora
                Console.WriteLine("Fechando conexão com a impressora...");
                ret = E1NotasWrapper.FechaConexaoImpressora();
                Console.WriteLine($"Retorno FechaConexaoImpressora: {ret}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao imprimir NFCe: {ex.Message}");
        }
    }

    public void ConsultarStatus()
    {
        try
        {
            string uuid = _lastUuid;
            
            if (string.IsNullOrEmpty(uuid))
            {
                Console.WriteLine("Nenhuma nota foi emitida ainda.");
                Console.Write("Deseja digitar um UUID manualmente? (S/N): ");
                string resposta = Console.ReadLine();
                
                if (resposta?.ToUpper() == "S")
                {
                    Console.Write("Digite o UUID da nota: ");
                    uuid = Console.ReadLine();
                    
                    if (string.IsNullOrEmpty(uuid))
                    {
                        Console.WriteLine("UUID não fornecido.");
                        return;
                    }
                }
                else
                {
                    Console.WriteLine("Operação cancelada.");
                    return;
                }
            }
            else
            {
                Console.WriteLine($"Último UUID registrado: {uuid}");
                Console.Write("Deseja usar este UUID? (S/N) ou digite outro UUID: ");
                string resposta = Console.ReadLine();
                
                if (resposta?.ToUpper() == "N")
                {
                    Console.Write("Digite o UUID da nota: ");
                    uuid = Console.ReadLine();
                    
                    if (string.IsNullOrEmpty(uuid))
                    {
                        Console.WriteLine("UUID não fornecido.");
                        return;
                    }
                }
                else if (!string.IsNullOrEmpty(resposta) && resposta.Length > 1)
                {
                    // Usuário digitou um UUID diferente
                    uuid = resposta;
                }
                // Se pressionar Enter ou digitar "S", usa o UUID carregado
            }
            
            Console.WriteLine($"Consultando status da nota com UUID: {uuid}");
            string resultStr = E1NotasWrapper.ConsultarStatusWrapper(uuid);
            Console.WriteLine($"Retorno ConsultarStatus: {resultStr}");
            
            // Tentar parsear o JSON para melhor formatação
            try
            {
                var resultJson = Newtonsoft.Json.Linq.JObject.Parse(resultStr);
                Console.WriteLine("Resultado formatado:");
                Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(resultJson, Newtonsoft.Json.Formatting.Indented));
            }
            catch
            {
                // Se não for JSON válido, mostrar como string normal
                Console.WriteLine("Resultado: " + resultStr);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao consultar status: {ex.Message}");
        }
    }
}