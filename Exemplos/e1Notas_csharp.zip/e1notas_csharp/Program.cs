using System;

class Program
{
    static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Carregando configurações...");
            var config = Configuracao.Carregar();
            var nfceService = new NFCeService(config);
            
            bool continuar = true;
            while (continuar)
            {
                ExibirMenu();
                string opcao = Console.ReadLine();
                
                switch (opcao)
                {
                    case "1":
                        Console.WriteLine("=== EMISSÃO DE NFCe ===");
                        nfceService.EmitirNFCeExemplo();
                        Console.WriteLine("=======================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "2":
                        Console.WriteLine("=== EMISSÃO DE NFe ===");
                        nfceService.EmitirNFeExemplo();
                        Console.WriteLine("======================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "3":
                        Console.WriteLine("=== CANCELAMENTO DE NFCe ===");
                        nfceService.CancelarNFCe();
                        Console.WriteLine("============================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "4":
                        Console.WriteLine("=== GERAÇÃO DE PDF NFCe PERSONALIZADO ===");
                        nfceService.GerarPDFNFCePersonalizado();
                        Console.WriteLine("=========================================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "5":
                        Console.WriteLine("=== GERAÇÃO DE PDF NFe PERSONALIZADO ===");
                        nfceService.GerarPDFNFePersonalizado();
                        Console.WriteLine("========================================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "6":
                        Console.WriteLine("=== IMPRESSÃO DE NFCe ===");
                        nfceService.ImprimirNFCe();
                        Console.WriteLine("==========================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "7":
                        Console.WriteLine("=== CONSULTA DE STATUS ===");
                        nfceService.ConsultarStatus();
                        Console.WriteLine("===========================");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                    case "8":
                        Console.WriteLine("Saindo do programa...");
                        continuar = false;
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
                        Console.ReadKey();
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro na aplicação: {ex.Message}");
            Console.WriteLine("Pressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
    
    static void ExibirMenu()
    {
        Console.Clear();
        Console.WriteLine("========================================");
        Console.WriteLine("            MENU PRINCIPAL              ");
        Console.WriteLine("========================================");
        Console.WriteLine("1 - Emitir NFCe");
        Console.WriteLine("2 - Emitir NFe");
        Console.WriteLine("3 - Cancelar NFCe");
        Console.WriteLine("4 - Gerar PDF NFCe Personalizado");
        Console.WriteLine("5 - Gerar PDF NFe Personalizado");
        Console.WriteLine("6 - Imprimir NFCe");
        Console.WriteLine("7 - Consultar Status");
        Console.WriteLine("8 - Sair");
        Console.WriteLine("========================================");
        Console.Write("Escolha uma opção: ");
    }
}