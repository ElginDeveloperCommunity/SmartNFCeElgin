# Novo Projeto E1 Notas - C#

Este projeto é uma implementação em C# do sistema E1 Notas, baseado no exemplo Python fornecido. Ele permite a emissão de NFCe e NFe utilizando as bibliotecas DLL fornecidas.

## Estrutura do Projeto

- `E1NotasWrapper.cs`: Wrapper completo para todas as funções das DLLs E1_Notas, E1_Impressora01 e E1_Pdf
- `Configuracao.cs`: Classe para leitura do arquivo dados.ini
- `NFCeService.cs`: Serviço com exemplos de emissão de NFCe e NFe
- `Program.cs`: Aplicação de console com menu interativo
- `dados.ini`: Arquivo de configuração com dados do emitente
- `E1_Notas.dll`: Biblioteca principal para geração de notas fiscais
- `E1_Impressora01.dll`: Biblioteca para impressão
- `E1_Pdf.dll`: Biblioteca para geração de PDFs

## Funcionalidades Implementadas

1. Emissão de NFCe (Nota Fiscal do Consumidor Eletrônica)
2. Emissão de NFe (Nota Fiscal Eletrônica)
3. Cancelamento de NFCe
4. Leitura de configurações do arquivo dados.ini

## Como Usar

1. Certifique-se de que todas as DLLs estão no mesmo diretório do executável
2. Verifique e atualize o arquivo `dados.ini` com as informações corretas do emitente
3. Compile e execute o projeto
4. Use o menu interativo para acessar as funcionalidades

## Requisitos

- .NET Framework 4.8
- DLLs E1_Notas fornecidas

## Observações

- O projeto foi configurado para ambiente de homologação (tpAmb = 0)
- Os exemplos incluem produtos e impostos básicos
- Para ambientes de produção, ajuste os parâmetros conforme necessário