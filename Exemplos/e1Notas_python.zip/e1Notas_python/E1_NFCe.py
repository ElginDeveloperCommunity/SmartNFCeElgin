import ctypes
import platform

###
### CARREGA LIB
###

if platform.system() == "Windows":
  ffi = ctypes.WinDLL("./E1_Notas.dll")
else:
  ffi = ctypes.cdll.LoadLibrary("./libE1_Notas.so")

###
### FUNCOES CONSTRUCAO
###

def AbreCupomVenda(chaveDeAcesso):
    fn = ffi.AbreCupomVenda

    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]

    chaveDeAcesso = ctypes.c_char_p(bytes(chaveDeAcesso, "utf-8"))

    return fn(chaveDeAcesso)

def InformaIdentificacao(UF, cNF, natOp, mod, serie, nNF, dhEmi, dhSaiEnt, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV, 
                         tpAmb, finNFe, indFinal, indPres, indIntermed, procEmi, verProc, dhCont, xJust):
    fn = ffi.InformaIdentificacao

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,  # UF
        ctypes.c_char_p,  # cNF
        ctypes.c_char_p,  # natOp
        ctypes.c_int,     # mod
        ctypes.c_char_p,  # serie
        ctypes.c_char_p,  # nNF
        ctypes.c_char_p,  # dhEmi
        ctypes.c_char_p,  # dhSaiEnt
        ctypes.c_int,     # tpNF
        ctypes.c_int,     # idDest
        ctypes.c_char_p,  # cMunFG
        ctypes.c_int,     # tpImp
        ctypes.c_int,     # tpEmis
        ctypes.c_int,     # cDV
        ctypes.c_int,     # tpAmb
        ctypes.c_int,     # finNFe
        ctypes.c_int,     # indFinal
        ctypes.c_int,     # indPres
        ctypes.c_int,     # indIntermed
        ctypes.c_int,     # procEmi
        ctypes.c_char_p,  # verProc
        ctypes.c_char_p,  # dhCont
        ctypes.c_char_p   # xJust
    ]

    UF          = ctypes.c_char_p(bytes(UF,         "utf-8"))
    cNF         = ctypes.c_char_p(bytes(cNF,        "utf-8"))
    natOp       = ctypes.c_char_p(bytes(natOp,      "utf-8"))
    serie       = ctypes.c_char_p(bytes(serie,      "utf-8"))
    nNF         = ctypes.c_char_p(bytes(nNF,        "utf-8"))
    dhEmi       = ctypes.c_char_p(bytes(dhEmi,      "utf-8"))
    dhSaiEnt    = ctypes.c_char_p(bytes(dhSaiEnt,   "utf-8"))
    cMunFG      = ctypes.c_char_p(bytes(cMunFG,     "utf-8"))
    verProc     = ctypes.c_char_p(bytes(verProc,    "utf-8"))
    dhCont      = ctypes.c_char_p(bytes(dhCont,     "utf-8"))
    xJust       = ctypes.c_char_p(bytes(xJust,      "utf-8"))

    return fn(UF, cNF, natOp, mod, serie, nNF, dhEmi, dhSaiEnt, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV,
              tpAmb, finNFe, indFinal, indPres, indIntermed, procEmi, verProc, dhCont, xJust)

def InformaEmitente(CNPJ, CPF, xNome, xFant, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, IE, IEST, IM, CNAE, CRT):
    fn = ffi.InformaEmitente

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,       "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,        "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,      "utf-8"))
    xFant   = ctypes.c_char_p(bytes(xFant,      "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,       "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,        "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,       "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro,    "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,       "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,       "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,         "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,        "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,      "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,      "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,       "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,         "utf-8"))
    IEST    = ctypes.c_char_p(bytes(IEST,       "utf-8"))
    IM      = ctypes.c_char_p(bytes(IM,         "utf-8"))
    CNAE    = ctypes.c_char_p(bytes(CNAE,       "utf-8"))

    return fn(CNPJ, CPF, xNome, xFant, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, IE, IEST, IM, CNAE, CRT)

def InformaProduto(cProd, cEAN, xProd, NCM, NVE, CEST, indEscala, CNPJFab, cBenef, EXTIPI, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib,
                   uTrib, qTrib, vUnTrib, vFrete, vSeg, vDesc, vOutro, indTot):
    fn = ffi.InformaProduto

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    cProd       = ctypes.c_char_p(bytes(cProd,      "utf-8"))
    cEAN        = ctypes.c_char_p(bytes(cEAN,       "utf-8"))
    xProd       = ctypes.c_char_p(bytes(xProd,      "utf-8"))
    NCM         = ctypes.c_char_p(bytes(NCM,        "utf-8"))
    NVE         = ctypes.c_char_p(bytes(NVE,        "utf-8"))
    CEST        = ctypes.c_char_p(bytes(CEST,       "utf-8"))
    indEscala   = ctypes.c_char_p(bytes(indEscala,  "utf-8"))
    CNPJFab     = ctypes.c_char_p(bytes(CNPJFab,    "utf-8"))
    cBenef      = ctypes.c_char_p(bytes(cBenef,     "utf-8"))
    EXTIPI      = ctypes.c_char_p(bytes(EXTIPI,     "utf-8"))
    CFOP        = ctypes.c_char_p(bytes(CFOP,       "utf-8"))
    uCom        = ctypes.c_char_p(bytes(uCom,       "utf-8"))
    qCom        = ctypes.c_char_p(bytes(qCom,       "utf-8"))
    vUnCom      = ctypes.c_char_p(bytes(vUnCom,     "utf-8"))
    vProd       = ctypes.c_char_p(bytes(vProd,      "utf-8"))
    cEANTrib    = ctypes.c_char_p(bytes(cEANTrib,   "utf-8"))
    uTrib       = ctypes.c_char_p(bytes(uTrib,      "utf-8"))
    qTrib       = ctypes.c_char_p(bytes(qTrib,      "utf-8"))
    vUnTrib     = ctypes.c_char_p(bytes(vUnTrib,    "utf-8"))
    vFrete      = ctypes.c_char_p(bytes(vFrete,     "utf-8"))
    vSeg        = ctypes.c_char_p(bytes(vSeg,       "utf-8"))
    vDesc       = ctypes.c_char_p(bytes(vDesc,      "utf-8"))
    vOutro      = ctypes.c_char_p(bytes(vOutro,     "utf-8"))

    return fn(cProd, cEAN, xProd, NCM, NVE, CEST, indEscala, CNPJFab, cBenef, EXTIPI, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib,
              uTrib, qTrib, vUnTrib, vFrete, vSeg, vDesc, vOutro, indTot)

def InformaICMS40(nItem, orig, CST, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS40

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson, "utf-8"))

    return fn(nItem, orig, CST, vICMSDeson, motDesICMS)

def InformaPISAliq(nItem, CST, vBC, pPIS, vPIS):
    fn = ffi.InformaPISAliq

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST     = ctypes.c_char_p(bytes(CST,    "utf-8"))
    vBC     = ctypes.c_char_p(bytes(vBC,    "utf-8"))
    pPIS    = ctypes.c_char_p(bytes(pPIS,   "utf-8"))
    vPIS    = ctypes.c_char_p(bytes(vPIS,   "utf-8"))

    return fn(nItem, CST, vBC, pPIS, vPIS)

def InformaCOFINSAliq(nItem, CST, vBC, pCOFINS, vCOFINS):
    fn = ffi.InformaCOFINSAliq

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST     = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vBC     = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    vCOFINS = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, vBC, pCOFINS, vCOFINS)

def InformaPagamento(indPag, tPag, vPag, tpIntegra, CNPJ, tBand, cAut):
    fn = ffi.InformaPagamento

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    tPag    = ctypes.c_char_p(bytes(tPag,   "utf-8"))
    vPag    = ctypes.c_char_p(bytes(vPag,   "utf-8"))
    CNPJ    = ctypes.c_char_p(bytes(CNPJ,   "utf-8"))
    tBand   = ctypes.c_char_p(bytes(tBand,  "utf-8"))
    cAut    = ctypes.c_char_p(bytes(cAut,   "utf-8"))

    return fn(indPag, tPag, vPag, tpIntegra, CNPJ, tBand, cAut)

def InformaValorTroco(vTroco):
    fn = ffi.InformaValorTroco

    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]

    vTroco = ctypes.c_char_p(bytes(vTroco, "utf-8"))

    return fn(vTroco)

def FechaCupomVenda(path):
    fn = ffi.FechaCupomVenda

    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]

    path = ctypes.c_char_p(bytes(path, "utf-8"))

    return fn(path)

###
### FUNCOES TRANSMISSAO
###

def EmitirNota(caminho_arquivo):
    fn = ffi.EmitirNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p]

    caminho_arquivo = ctypes.c_char_p(bytes(caminho_arquivo, "utf-8"))

    return fn(caminho_arquivo).decode("utf-8")

def ConsultarNota(chave):
    fn = ffi.ConsultarNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p]

    chave = ctypes.c_char_p(bytes(chave, "utf-8"))

    return fn(chave).decode("utf-8")

def CancelarNota(chave_nota, protocolo, justificativa):
    fn = ffi.CancelarNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    chave_nota      = ctypes.c_char_p(bytes(chave_nota,     "utf-8"))
    protocolo       = ctypes.c_char_p(bytes(protocolo,      "utf-8"))
    justificativa   = ctypes.c_char_p(bytes(justificativa,  "utf-8"))

    return fn(chave_nota, protocolo, justificativa).decode("utf-8")

def InformaAvulsa(CNPJ, xOrgao, matr, xAgente, fone, UF, nDAR, dEmi, vDAR, repEmi, dPag):
    fn = ffi.InformaAvulsa

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    xOrgao  = ctypes.c_char_p(bytes(xOrgao,  "utf-8"))
    matr    = ctypes.c_char_p(bytes(matr,    "utf-8"))
    xAgente = ctypes.c_char_p(bytes(xAgente, "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    nDAR    = ctypes.c_char_p(bytes(nDAR,    "utf-8"))
    dEmi    = ctypes.c_char_p(bytes(dEmi,    "utf-8"))
    vDAR    = ctypes.c_char_p(bytes(vDAR,    "utf-8"))
    repEmi  = ctypes.c_char_p(bytes(repEmi,  "utf-8"))
    dPag    = ctypes.c_char_p(bytes(dPag,    "utf-8"))

    return fn(CNPJ, xOrgao, matr, xAgente, fone, UF, nDAR, dEmi, vDAR, repEmi, dPag)

def InformaDestinatario(CNPJ, CPF, idEstrangeiro, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, indIEDest, IE, ISUF, IM, email):
    fn = ffi.InformaDestinatario

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ          = ctypes.c_char_p(bytes(CNPJ,          "utf-8"))
    CPF           = ctypes.c_char_p(bytes(CPF,           "utf-8"))
    idEstrangeiro = ctypes.c_char_p(bytes(idEstrangeiro, "utf-8"))
    xNome         = ctypes.c_char_p(bytes(xNome,         "utf-8"))
    xLgr          = ctypes.c_char_p(bytes(xLgr,          "utf-8"))
    nro           = ctypes.c_char_p(bytes(nro,           "utf-8"))
    xCpl          = ctypes.c_char_p(bytes(xCpl,          "utf-8"))
    xBairro       = ctypes.c_char_p(bytes(xBairro,       "utf-8"))
    cMun          = ctypes.c_char_p(bytes(cMun,          "utf-8"))
    xMun          = ctypes.c_char_p(bytes(xMun,          "utf-8"))
    UF            = ctypes.c_char_p(bytes(UF,            "utf-8"))
    CEP           = ctypes.c_char_p(bytes(CEP,           "utf-8"))
    cPais         = ctypes.c_char_p(bytes(cPais,         "utf-8"))
    xPais         = ctypes.c_char_p(bytes(xPais,         "utf-8"))
    fone          = ctypes.c_char_p(bytes(fone,          "utf-8"))
    IE            = ctypes.c_char_p(bytes(IE,            "utf-8"))
    ISUF          = ctypes.c_char_p(bytes(ISUF,          "utf-8"))
    IM            = ctypes.c_char_p(bytes(IM,            "utf-8"))
    email         = ctypes.c_char_p(bytes(email,         "utf-8"))

    return fn(CNPJ, CPF, idEstrangeiro, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, indIEDest, IE, ISUF, IM, email)

def InformaRetirada(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE):
    fn = ffi.InformaRetirada

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,     "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,   "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,    "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,     "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,    "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro, "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,    "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,     "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,   "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,   "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    email   = ctypes.c_char_p(bytes(email,   "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,      "utf-8"))

    return fn(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE)

def InformaEntrega(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE):
    fn = ffi.InformaEntrega

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,     "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,   "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,    "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,     "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,    "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro, "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,    "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,     "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,   "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,   "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    email   = ctypes.c_char_p(bytes(email,   "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,      "utf-8"))

    return fn(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE)

def InformaAutorizacaoXML(CNPJ, CPF):
    fn = ffi.InformaAutorizacaoXML

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ = ctypes.c_char_p(bytes(CNPJ, "utf-8"))
    CPF  = ctypes.c_char_p(bytes(CPF,  "utf-8"))

    return fn(CNPJ, CPF)

def InformaICMS00(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP, vFCP):
    fn = ffi.InformaICMS00

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST   = ctypes.c_char_p(bytes(CST,   "utf-8"))
    vBC   = ctypes.c_char_p(bytes(vBC,   "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    pFCP  = ctypes.c_char_p(bytes(pFCP,  "utf-8"))
    vFCP  = ctypes.c_char_p(bytes(vFCP,  "utf-8"))

    return fn(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP, vFCP)

def InformaICMS10(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST):
    fn = ffi.InformaICMS10

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))
    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    pICMS    = ctypes.c_char_p(bytes(pICMS,    "utf-8"))
    vICMS    = ctypes.c_char_p(bytes(vICMS,    "utf-8"))
    vBCFCP   = ctypes.c_char_p(bytes(vBCFCP,   "utf-8"))
    pFCP     = ctypes.c_char_p(bytes(pFCP,     "utf-8"))
    vFCP     = ctypes.c_char_p(bytes(vFCP,     "utf-8"))
    pMVAST   = ctypes.c_char_p(bytes(pMVAST,   "utf-8"))
    pRedBCST = ctypes.c_char_p(bytes(pRedBCST, "utf-8"))
    vBCST    = ctypes.c_char_p(bytes(vBCST,    "utf-8"))
    pICMSST  = ctypes.c_char_p(bytes(pICMSST,  "utf-8"))
    vICMSST  = ctypes.c_char_p(bytes(vICMSST,  "utf-8"))
    vBCFCPST = ctypes.c_char_p(bytes(vBCFCPST, "utf-8"))
    pFCPST   = ctypes.c_char_p(bytes(pFCPST,   "utf-8"))
    vFCPST   = ctypes.c_char_p(bytes(vFCPST,   "utf-8"))

    return fn(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST)

def InformaICMS20(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS20

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,         "utf-8"))
    pRedBC      = ctypes.c_char_p(bytes(pRedBC,      "utf-8"))
    vBC         = ctypes.c_char_p(bytes(vBC,         "utf-8"))
    pICMS       = ctypes.c_char_p(bytes(pICMS,       "utf-8"))
    vICMS       = ctypes.c_char_p(bytes(vICMS,       "utf-8"))
    vBCFCP      = ctypes.c_char_p(bytes(vBCFCP,      "utf-8"))
    pFCP        = ctypes.c_char_p(bytes(pFCP,        "utf-8"))
    vFCP        = ctypes.c_char_p(bytes(vFCP,        "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson,  "utf-8"))

    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, vICMSDeson, motDesICMS)

def InformaICMS30(nItem, orig, CST, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS30

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,         "utf-8"))
    pMVAST      = ctypes.c_char_p(bytes(pMVAST,      "utf-8"))
    pRedBCST    = ctypes.c_char_p(bytes(pRedBCST,    "utf-8"))
    vBCST       = ctypes.c_char_p(bytes(vBCST,       "utf-8"))
    pICMSST     = ctypes.c_char_p(bytes(pICMSST,     "utf-8"))
    vICMSST     = ctypes.c_char_p(bytes(vICMSST,     "utf-8"))
    vBCFCPST    = ctypes.c_char_p(bytes(vBCFCPST,    "utf-8"))
    pFCPST      = ctypes.c_char_p(bytes(pFCPST,      "utf-8"))
    vFCPST      = ctypes.c_char_p(bytes(vFCPST,      "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson,  "utf-8"))

    return fn(nItem, orig, CST, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS)

def InformaICMS51(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMSOp, pDif, vICMSDif, vICMS, vBCFCP, pFCP, vFCP):
    fn = ffi.InformaICMS51

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST       = ctypes.c_char_p(bytes(CST,       "utf-8"))
    pRedBC    = ctypes.c_char_p(bytes(pRedBC,    "utf-8"))
    vBC       = ctypes.c_char_p(bytes(vBC,       "utf-8"))
    pICMS     = ctypes.c_char_p(bytes(pICMS,     "utf-8"))
    vICMSOp   = ctypes.c_char_p(bytes(vICMSOp,   "utf-8"))
    pDif      = ctypes.c_char_p(bytes(pDif,      "utf-8"))
    vICMSDif  = ctypes.c_char_p(bytes(vICMSDif,  "utf-8"))
    vICMS     = ctypes.c_char_p(bytes(vICMS,     "utf-8"))
    vBCFCP    = ctypes.c_char_p(bytes(vBCFCP,    "utf-8"))
    pFCP      = ctypes.c_char_p(bytes(pFCP,      "utf-8"))
    vFCP      = ctypes.c_char_p(bytes(vFCP,      "utf-8"))

    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMSOp, pDif, vICMSDif, vICMS, vBCFCP, pFCP, vFCP)

def InformaICMS60(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMS60

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMS70(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS70
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    pRedBC = ctypes.c_char_p(bytes(pRedBC, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    vBCFCP = ctypes.c_char_p(bytes(vBCFCP, "utf-8"))
    pFCP = ctypes.c_char_p(bytes(pFCP, "utf-8"))
    vFCP = ctypes.c_char_p(bytes(vFCP, "utf-8"))
    pMVAST = ctypes.c_char_p(bytes(pMVAST, "utf-8"))
    pRedBCST = ctypes.c_char_p(bytes(pRedBCST, "utf-8"))
    vBCST = ctypes.c_char_p(bytes(vBCST, "utf-8"))
    pICMSST = ctypes.c_char_p(bytes(pICMSST, "utf-8"))
    vICMSST = ctypes.c_char_p(bytes(vICMSST, "utf-8"))
    vBCFCPST = ctypes.c_char_p(bytes(vBCFCPST, "utf-8"))
    pFCPST = ctypes.c_char_p(bytes(pFCPST, "utf-8"))
    vFCPST = ctypes.c_char_p(bytes(vFCPST, "utf-8"))
    vICMSDeson = ctypes.c_char_p(bytes(vICMSDeson, "utf-8"))
    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS)

def InformaICMS90(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c):
    fn = ffi.InformaICMS90
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC_a = ctypes.c_char_p(bytes(vBC_a, "utf-8"))
    pRedBCop_a = ctypes.c_char_p(bytes(pRedBCop_a, "utf-8"))
    pICMS_a = ctypes.c_char_p(bytes(pICMS_a, "utf-8"))
    vICMS_a = ctypes.c_char_p(bytes(vICMS_a, "utf-8"))
    vBCFCP_aa = ctypes.c_char_p(bytes(vBCFCP_aa, "utf-8"))
    pFCP_aa = ctypes.c_char_p(bytes(pFCP_aa, "utf-8"))
    vFCP_aa = ctypes.c_char_p(bytes(vFCP_aa, "utf-8"))
    pMVASTop_b = ctypes.c_char_p(bytes(pMVASTop_b, "utf-8"))
    pRedBCSTop_b = ctypes.c_char_p(bytes(pRedBCSTop_b, "utf-8"))
    vBCST_b = ctypes.c_char_p(bytes(vBCST_b, "utf-8"))
    pICMSST_b = ctypes.c_char_p(bytes(pICMSST_b, "utf-8"))
    vICMSST_b = ctypes.c_char_p(bytes(vICMSST_b, "utf-8"))
    vBCFCPST_bb = ctypes.c_char_p(bytes(vBCFCPST_bb, "utf-8"))
    pFCPST_bb = ctypes.c_char_p(bytes(pFCPST_bb, "utf-8"))
    vFCPST_bb = ctypes.c_char_p(bytes(vFCPST_bb, "utf-8"))
    vICMSDeson_c = ctypes.c_char_p(bytes(vICMSDeson_c, "utf-8"))
    return fn(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c)

def InformaICMSPart(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, pBCOper, UFST):
    fn = ffi.InformaICMSPart
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pRedBCop = ctypes.c_char_p(bytes(pRedBCop, "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    pMVASTop = ctypes.c_char_p(bytes(pMVASTop, "utf-8"))
    pRedBCSTop = ctypes.c_char_p(bytes(pRedBCSTop, "utf-8"))
    vBCST = ctypes.c_char_p(bytes(vBCST, "utf-8"))
    pICMSST = ctypes.c_char_p(bytes(pICMSST, "utf-8"))
    vICMSST = ctypes.c_char_p(bytes(vICMSST, "utf-8"))
    pBCOper = ctypes.c_char_p(bytes(pBCOper, "utf-8"))
    UFST = ctypes.c_char_p(bytes(UFST, "utf-8"))
    return fn(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, pBCOper, UFST)

def InformaICMSSN102(nItem, orig, CSOSN):
    fn = ffi.InformaICMSSN102
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p
    ]
    CSOSN = ctypes.c_char_p(bytes(CSOSN, "utf-8"))
    return fn(nItem, orig, CSOSN)
    
def InutilizarNumeracao(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal):
    fn = ffi.InutilizarNumeracao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # cnpj
        ctypes.c_char_p,  # ano
        ctypes.c_char_p,  # justificativa
        ctypes.c_char_p,  # uf
        ctypes.c_int,     # tpAmb
        ctypes.c_int,     # serie
        ctypes.c_int,     # numeroInicial
        ctypes.c_int      # numeroFinal
    ]

    cnpj          = ctypes.c_char_p(bytes(cnpj, "utf-8"))
    ano           = ctypes.c_char_p(bytes(ano, "utf-8"))
    justificativa = ctypes.c_char_p(bytes(justificativa, "utf-8"))
    uf            = ctypes.c_char_p(bytes(uf, "utf-8"))

    return fn(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal).decode("utf-8")

def ProcessamentoContingencia():
    fn = ffi.ProcessamentoContingencia

    fn.restype = ctypes.c_char_p
    fn.argtypes = []

    return fn().decode("utf-8")