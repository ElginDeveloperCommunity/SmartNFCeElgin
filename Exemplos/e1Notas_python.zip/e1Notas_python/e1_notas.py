import ctypes    # interagir com bibliotecas ou DLLs escritas em C/C++   
import platform  # informacoes do SO e Local


###
### CARREGA LIB
###

if platform.system() == "Windows":
  ffi = ctypes.WinDLL("./E1_Notas.dll")  #Windows
else:
  ffi = ctypes.cdll.LoadLibrary("./libE1_Notas.so")  #Linux

###
### FUNCOES CONSTRUCAO
###

def AbreCupomVenda(chaveDeAcesso):
    fn = ffi.AbreCupomVenda

    fn.restype = ctypes.c_int                                           #Tipo de retorno da função da DLL
    fn.argtypes = [ctypes.c_char_p]                                     #DLL espera um argumento tipo char*

    chaveDeAcesso = ctypes.c_char_p(bytes(chaveDeAcesso, "utf-8"))      #Converte chaveDeAcesso para C e transforma os bytes em ponteiro char*

    return fn(chaveDeAcesso)                                            #Chama a função da DLL com a chave convertida de retorna o valor inteiro

def InformaIdentificacao(cUF, cNF, natOp, mod, serie, nNF, dhEmi, dhSaiEnt, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV, 
                         tpAmb, finNFe, indFinal, indPres, indIntermed, procEmi, verProc, dhCont, xJust):
    fn = ffi.InformaIdentificacao

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,  # cUF
        ctypes.c_char_p,  # cNF
        ctypes.c_char_p,  # natOp
        ctypes.c_int,     # mod
        ctypes.c_char_p,  # serie
        ctypes.c_char_p,  # nNF
        ctypes.c_char_p,  # dhEmi
        ctypes.c_char_p,  # dhSaiEnt
        ctypes.c_int,     # tpNF
        ctypes.c_int,     # idDest
        ctypes.c_char_p,  # cMunFG
        ctypes.c_int,     # tpImp
        ctypes.c_int,     # tpEmis
        ctypes.c_int,     # cDV
        ctypes.c_int,     # tpAmb
        ctypes.c_int,     # finNFe
        ctypes.c_int,     # indFinal
        ctypes.c_int,     # indPres
        ctypes.c_int,     # indIntermed
        ctypes.c_int,     # procEmi
        ctypes.c_char_p,  # verProc
        ctypes.c_char_p,  # dhCont
        ctypes.c_char_p   # xJust
    ]

    cUF         = ctypes.c_char_p(bytes(cUF,         "utf-8"))
    cNF         = ctypes.c_char_p(bytes(cNF,        "utf-8"))
    natOp       = ctypes.c_char_p(bytes(natOp,      "utf-8"))
    serie       = ctypes.c_char_p(bytes(serie,      "utf-8"))
    nNF         = ctypes.c_char_p(bytes(nNF,        "utf-8"))
    dhEmi       = ctypes.c_char_p(bytes(dhEmi,      "utf-8"))
    dhSaiEnt    = ctypes.c_char_p(bytes(dhSaiEnt,   "utf-8"))
    cMunFG      = ctypes.c_char_p(bytes(cMunFG,     "utf-8"))
    verProc     = ctypes.c_char_p(bytes(verProc,    "utf-8"))
    dhCont      = ctypes.c_char_p(bytes(dhCont,     "utf-8"))
    xJust       = ctypes.c_char_p(bytes(xJust,      "utf-8"))

    return fn(cUF, cNF, natOp, mod, serie, nNF, dhEmi, dhSaiEnt, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV,
              tpAmb, finNFe, indFinal, indPres, indIntermed, procEmi, verProc, dhCont, xJust)

def InformaEmitente(CNPJ, CPF, xNome, xFant, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, IE, IEST, IM, CNAE, CRT):
    fn = ffi.InformaEmitente

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,       "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,        "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,      "utf-8"))
    xFant   = ctypes.c_char_p(bytes(xFant,      "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,       "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,        "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,       "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro,    "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,       "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,       "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,         "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,        "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,      "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,      "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,       "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,         "utf-8"))
    IEST    = ctypes.c_char_p(bytes(IEST,       "utf-8"))
    IM      = ctypes.c_char_p(bytes(IM,         "utf-8"))
    CNAE    = ctypes.c_char_p(bytes(CNAE,       "utf-8"))

    return fn(CNPJ, CPF, xNome, xFant, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, IE, IEST, IM, CNAE, CRT)

def InformaProduto(cProd, cEAN, xProd, NCM, NVE, CEST, indEscala, CNPJFab, cBenef, EXTIPI, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib,
                   uTrib, qTrib, vUnTrib, vFrete, vSeg, vDesc, vOutro, indTot):
    fn = ffi.InformaProduto

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    cProd       = ctypes.c_char_p(bytes(cProd,      "utf-8"))
    cEAN        = ctypes.c_char_p(bytes(cEAN,       "utf-8"))
    xProd       = ctypes.c_char_p(bytes(xProd,      "utf-8"))
    NCM         = ctypes.c_char_p(bytes(NCM,        "utf-8"))
    NVE         = ctypes.c_char_p(bytes(NVE,        "utf-8"))
    CEST        = ctypes.c_char_p(bytes(CEST,       "utf-8"))
    indEscala   = ctypes.c_char_p(bytes(indEscala,  "utf-8"))
    CNPJFab     = ctypes.c_char_p(bytes(CNPJFab,    "utf-8"))
    cBenef      = ctypes.c_char_p(bytes(cBenef,     "utf-8"))
    EXTIPI      = ctypes.c_char_p(bytes(EXTIPI,     "utf-8"))
    CFOP        = ctypes.c_char_p(bytes(CFOP,       "utf-8"))
    uCom        = ctypes.c_char_p(bytes(uCom,       "utf-8"))
    qCom        = ctypes.c_char_p(bytes(qCom,       "utf-8"))
    vUnCom      = ctypes.c_char_p(bytes(vUnCom,     "utf-8"))
    vProd       = ctypes.c_char_p(bytes(vProd,      "utf-8"))
    cEANTrib    = ctypes.c_char_p(bytes(cEANTrib,   "utf-8"))
    uTrib       = ctypes.c_char_p(bytes(uTrib,      "utf-8"))
    qTrib       = ctypes.c_char_p(bytes(qTrib,      "utf-8"))
    vUnTrib     = ctypes.c_char_p(bytes(vUnTrib,    "utf-8"))
    vFrete      = ctypes.c_char_p(bytes(vFrete,     "utf-8"))
    vSeg        = ctypes.c_char_p(bytes(vSeg,       "utf-8"))
    vDesc       = ctypes.c_char_p(bytes(vDesc,      "utf-8"))
    vOutro      = ctypes.c_char_p(bytes(vOutro,     "utf-8"))

    return fn(cProd, cEAN, xProd, NCM, NVE, CEST, indEscala, CNPJFab, cBenef, EXTIPI, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib,
              uTrib, qTrib, vUnTrib, vFrete, vSeg, vDesc, vOutro, indTot)

def InformaICMS40(nItem, orig, CST, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS40

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson, "utf-8"))

    return fn(nItem, orig, CST, vICMSDeson, motDesICMS)

def InformaPISAliq(nItem, CST, vBC, pPIS, vPIS):
    fn = ffi.InformaPISAliq

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST     = ctypes.c_char_p(bytes(CST,    "utf-8"))
    vBC     = ctypes.c_char_p(bytes(vBC,    "utf-8"))
    pPIS    = ctypes.c_char_p(bytes(pPIS,   "utf-8"))
    vPIS    = ctypes.c_char_p(bytes(vPIS,   "utf-8"))

    return fn(nItem, CST, vBC, pPIS, vPIS)

def InformaPISOutr(nItem, CST, vBC, pPIS, qBCProd_bEx, vAliqProd_bEx, vPIS):
    fn = ffi.InformaPISOutr

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
    ]

    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pPIS = ctypes.c_char_p(bytes(pPIS, "utf-8"))
    qBCProd_bEx = ctypes.c_char_p(bytes(qBCProd_bEx, "utf-8"))
    vAliqProd_bEx = ctypes.c_char_p(bytes(vAliqProd_bEx, "utf-8"))
    vPIS = ctypes.c_char_p(bytes(vPIS, "utf-8"))

    return fn(nItem, CST, vBC, pPIS, qBCProd_bEx, vAliqProd_bEx, vPIS)

def InformaCOFINSAliq(nItem, CST, vBC, pCOFINS, vCOFINS):
    fn = ffi.InformaCOFINSAliq

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST     = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vBC     = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    vCOFINS = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, vBC, pCOFINS, vCOFINS)

def InformaValorTotalTributos(nItem, vTotTrib):
    fn = ffi.InformaValorTotalTributos

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
    ]

    vTotTrib = ctypes.c_char_p(bytes(vTotTrib, "utf-8"))

    return fn(nItem, vTotTrib)

def InformaPagamento(indPag, tPag, vPag, tpIntegra, CNPJ, tBand, cAut):
    fn = ffi.InformaPagamento

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    tPag    = ctypes.c_char_p(bytes(tPag,   "utf-8"))
    vPag    = ctypes.c_char_p(bytes(vPag,   "utf-8"))
    CNPJ    = ctypes.c_char_p(bytes(CNPJ,   "utf-8"))
    tBand   = ctypes.c_char_p(bytes(tBand,  "utf-8"))
    cAut    = ctypes.c_char_p(bytes(cAut,   "utf-8"))

    return fn(indPag, tPag, vPag, tpIntegra, CNPJ, tBand, cAut)

def InformaValorTroco(vTroco):
    fn = ffi.InformaValorTroco

    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]

    vTroco = ctypes.c_char_p(bytes(vTroco, "utf-8"))

    return fn(vTroco)

def InformaInformacoesAdicionais(infAdFiscoOp, infCplOp):
    fn = ffi.InformaInformacoesAdicionais

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    infAdFiscoOp    = ctypes.c_char_p(bytes(infAdFiscoOp,   "utf-8"))
    infCplOp        = ctypes.c_char_p(bytes(infCplOp,       "utf-8"))

    return fn(infAdFiscoOp, infCplOp)

def InformaObservacoesContribuinte(xCampo, xTexto):
    fn = ffi.InformaObservacoesContribuinte

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    xCampo  = ctypes.c_char_p(bytes(xCampo, "utf-8"))
    xTexto  = ctypes.c_char_p(bytes(xTexto, "utf-8"))

    return fn(xCampo, xTexto)

def InformaObservacoesFisco(xCampo, xTexto):
    fn = ffi.InformaObservacoesFisco

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    xCampo  = ctypes.c_char_p(bytes(xCampo, "utf-8"))
    xTexto  = ctypes.c_char_p(bytes(xTexto, "utf-8"))

    return fn(xCampo, xTexto)

def InformaProcessoReferenciado(nProc, indProc):
    fn = ffi.InformaProcessoReferenciado

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_int
    ]

    nProc   = ctypes.c_char_p(bytes(nProc,  "utf-8"))

    return fn(nProc, indProc)

def FechaCupomVenda(path):
    fn = ffi.FechaCupomVenda

    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]

    path = ctypes.c_char_p(bytes(path, "utf-8"))

    return fn(path)

###
### FUNCOES TRANSMISSAO
###

def EmitirNota(caminho_arquivo):
    fn = ffi.EmitirNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p]

    caminho_arquivo = ctypes.c_char_p(bytes(caminho_arquivo, "utf-8"))

    return fn(caminho_arquivo).decode("utf-8")

def ConsultarNota(chave):
    fn = ffi.ConsultarNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p]

    chave = ctypes.c_char_p(bytes(chave, "utf-8"))

    return fn(chave).decode("utf-8")

def CancelarNota(chave_nota, protocolo, justificativa):
    fn = ffi.CancelarNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    chave_nota      = ctypes.c_char_p(bytes(chave_nota,     "utf-8"))
    protocolo       = ctypes.c_char_p(bytes(protocolo,      "utf-8"))
    justificativa   = ctypes.c_char_p(bytes(justificativa,  "utf-8"))

    return fn(chave_nota, protocolo, justificativa).decode("utf-8")

def CancelamentoPorSubstituicao(chCFe, chCFeRef, justificativa, tpAutor):       #metodo adicionado 
    fn = ffi.CancelamentoPorSubstituicao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
    ]

    chCFe         = ctypes.c_char_p(bytes(chCFe, "utf-8"))
    chCFeRef      = ctypes.c_char_p(bytes(chCFeRef, "utf-8"))
    justificativa = ctypes.c_char_p(bytes(justificativa, "utf-8"))
    tpAutor       = ctypes.c_int(tpAutor)  # Aqui é só inteiro

    return fn(chCFe, chCFeRef, justificativa, tpAutor).decode("utf-8")


def InformaAvulsa(CNPJ, xOrgao, matr, xAgente, fone, UF, nDAR, dEmi, vDAR, repEmi, dPag):
    fn = ffi.InformaAvulsa

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    xOrgao  = ctypes.c_char_p(bytes(xOrgao,  "utf-8"))
    matr    = ctypes.c_char_p(bytes(matr,    "utf-8"))
    xAgente = ctypes.c_char_p(bytes(xAgente, "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    nDAR    = ctypes.c_char_p(bytes(nDAR,    "utf-8"))
    dEmi    = ctypes.c_char_p(bytes(dEmi,    "utf-8"))
    vDAR    = ctypes.c_char_p(bytes(vDAR,    "utf-8"))
    repEmi  = ctypes.c_char_p(bytes(repEmi,  "utf-8"))
    dPag    = ctypes.c_char_p(bytes(dPag,    "utf-8"))

    return fn(CNPJ, xOrgao, matr, xAgente, fone, UF, nDAR, dEmi, vDAR, repEmi, dPag)

def InformaDestinatario(CNPJ, CPF, idEstrangeiro, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, indIEDest, IE, ISUF, IM, email):
    fn = ffi.InformaDestinatario

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ          = ctypes.c_char_p(bytes(CNPJ,          "utf-8"))
    CPF           = ctypes.c_char_p(bytes(CPF,           "utf-8"))
    idEstrangeiro = ctypes.c_char_p(bytes(idEstrangeiro, "utf-8"))
    xNome         = ctypes.c_char_p(bytes(xNome,         "utf-8"))
    xLgr          = ctypes.c_char_p(bytes(xLgr,          "utf-8"))
    nro           = ctypes.c_char_p(bytes(nro,           "utf-8"))
    xCpl          = ctypes.c_char_p(bytes(xCpl,          "utf-8"))
    xBairro       = ctypes.c_char_p(bytes(xBairro,       "utf-8"))
    cMun          = ctypes.c_char_p(bytes(cMun,          "utf-8"))
    xMun          = ctypes.c_char_p(bytes(xMun,          "utf-8"))
    UF            = ctypes.c_char_p(bytes(UF,            "utf-8"))
    CEP           = ctypes.c_char_p(bytes(CEP,           "utf-8"))
    cPais         = ctypes.c_char_p(bytes(cPais,         "utf-8"))
    xPais         = ctypes.c_char_p(bytes(xPais,         "utf-8"))
    fone          = ctypes.c_char_p(bytes(fone,          "utf-8"))
    IE            = ctypes.c_char_p(bytes(IE,            "utf-8"))
    ISUF          = ctypes.c_char_p(bytes(ISUF,          "utf-8"))
    IM            = ctypes.c_char_p(bytes(IM,            "utf-8"))
    email         = ctypes.c_char_p(bytes(email,         "utf-8"))

    return fn(CNPJ, CPF, idEstrangeiro, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, indIEDest, IE, ISUF, IM, email)

def InformaRetirada(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE):
    fn = ffi.InformaRetirada

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,     "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,   "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,    "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,     "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,    "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro, "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,    "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,     "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,   "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,   "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    email   = ctypes.c_char_p(bytes(email,   "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,      "utf-8"))

    return fn(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE)

def InformaEntrega(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE):
    fn = ffi.InformaEntrega

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,     "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,   "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,    "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,     "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,    "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro, "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,    "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,     "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,   "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,   "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    email   = ctypes.c_char_p(bytes(email,   "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,      "utf-8"))

    return fn(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE)

def InformaAutorizacaoXML(CNPJ, CPF):
    fn = ffi.InformaAutorizacaoXML

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ = ctypes.c_char_p(bytes(CNPJ, "utf-8"))
    CPF  = ctypes.c_char_p(bytes(CPF,  "utf-8"))

    return fn(CNPJ, CPF)

def InformaICMS00(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP, vFCP):
    fn = ffi.InformaICMS00

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST   = ctypes.c_char_p(bytes(CST,   "utf-8"))
    vBC   = ctypes.c_char_p(bytes(vBC,   "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    pFCP  = ctypes.c_char_p(bytes(pFCP,  "utf-8"))
    vFCP  = ctypes.c_char_p(bytes(vFCP,  "utf-8"))

    return fn(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP, vFCP)

def InformaICMS10(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST):
    fn = ffi.InformaICMS10

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))
    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    pICMS    = ctypes.c_char_p(bytes(pICMS,    "utf-8"))
    vICMS    = ctypes.c_char_p(bytes(vICMS,    "utf-8"))
    vBCFCP   = ctypes.c_char_p(bytes(vBCFCP,   "utf-8"))
    pFCP     = ctypes.c_char_p(bytes(pFCP,     "utf-8"))
    vFCP     = ctypes.c_char_p(bytes(vFCP,     "utf-8"))
    pMVAST   = ctypes.c_char_p(bytes(pMVAST,   "utf-8"))
    pRedBCST = ctypes.c_char_p(bytes(pRedBCST, "utf-8"))
    vBCST    = ctypes.c_char_p(bytes(vBCST,    "utf-8"))
    pICMSST  = ctypes.c_char_p(bytes(pICMSST,  "utf-8"))
    vICMSST  = ctypes.c_char_p(bytes(vICMSST,  "utf-8"))
    vBCFCPST = ctypes.c_char_p(bytes(vBCFCPST, "utf-8"))
    pFCPST   = ctypes.c_char_p(bytes(pFCPST,   "utf-8"))
    vFCPST   = ctypes.c_char_p(bytes(vFCPST,   "utf-8"))

    return fn(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST)

def InformaICMS20(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS20

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,         "utf-8"))
    pRedBC      = ctypes.c_char_p(bytes(pRedBC,      "utf-8"))
    vBC         = ctypes.c_char_p(bytes(vBC,         "utf-8"))
    pICMS       = ctypes.c_char_p(bytes(pICMS,       "utf-8"))
    vICMS       = ctypes.c_char_p(bytes(vICMS,       "utf-8"))
    vBCFCP      = ctypes.c_char_p(bytes(vBCFCP,      "utf-8"))
    pFCP        = ctypes.c_char_p(bytes(pFCP,        "utf-8"))
    vFCP        = ctypes.c_char_p(bytes(vFCP,        "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson,  "utf-8"))

    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, vICMSDeson, motDesICMS)

def InformaICMS30(nItem, orig, CST, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS30

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,         "utf-8"))
    pMVAST      = ctypes.c_char_p(bytes(pMVAST,      "utf-8"))
    pRedBCST    = ctypes.c_char_p(bytes(pRedBCST,    "utf-8"))
    vBCST       = ctypes.c_char_p(bytes(vBCST,       "utf-8"))
    pICMSST     = ctypes.c_char_p(bytes(pICMSST,     "utf-8"))
    vICMSST     = ctypes.c_char_p(bytes(vICMSST,     "utf-8"))
    vBCFCPST    = ctypes.c_char_p(bytes(vBCFCPST,    "utf-8"))
    pFCPST      = ctypes.c_char_p(bytes(pFCPST,      "utf-8"))
    vFCPST      = ctypes.c_char_p(bytes(vFCPST,      "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson,  "utf-8"))

    return fn(nItem, orig, CST, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS)

def InformaICMS51(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMSOp, pDif, vICMSDif, vICMS, vBCFCP, pFCP, vFCP):
    fn = ffi.InformaICMS51

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST       = ctypes.c_char_p(bytes(CST,       "utf-8"))
    pRedBC    = ctypes.c_char_p(bytes(pRedBC,    "utf-8"))
    vBC       = ctypes.c_char_p(bytes(vBC,       "utf-8"))
    pICMS     = ctypes.c_char_p(bytes(pICMS,     "utf-8"))
    vICMSOp   = ctypes.c_char_p(bytes(vICMSOp,   "utf-8"))
    pDif      = ctypes.c_char_p(bytes(pDif,      "utf-8"))
    vICMSDif  = ctypes.c_char_p(bytes(vICMSDif,  "utf-8"))
    vICMS     = ctypes.c_char_p(bytes(vICMS,     "utf-8"))
    vBCFCP    = ctypes.c_char_p(bytes(vBCFCP,    "utf-8"))
    pFCP      = ctypes.c_char_p(bytes(pFCP,      "utf-8"))
    vFCP      = ctypes.c_char_p(bytes(vFCP,      "utf-8"))

    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMSOp, pDif, vICMSDif, vICMS, vBCFCP, pFCP, vFCP)

def InformaICMS60(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMS60

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMS70(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS):
    fn = ffi.InformaICMS70
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    pRedBC = ctypes.c_char_p(bytes(pRedBC, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    vBCFCP = ctypes.c_char_p(bytes(vBCFCP, "utf-8"))
    pFCP = ctypes.c_char_p(bytes(pFCP, "utf-8"))
    vFCP = ctypes.c_char_p(bytes(vFCP, "utf-8"))
    pMVAST = ctypes.c_char_p(bytes(pMVAST, "utf-8"))
    pRedBCST = ctypes.c_char_p(bytes(pRedBCST, "utf-8"))
    vBCST = ctypes.c_char_p(bytes(vBCST, "utf-8"))
    pICMSST = ctypes.c_char_p(bytes(pICMSST, "utf-8"))
    vICMSST = ctypes.c_char_p(bytes(vICMSST, "utf-8"))
    vBCFCPST = ctypes.c_char_p(bytes(vBCFCPST, "utf-8"))
    pFCPST = ctypes.c_char_p(bytes(pFCPST, "utf-8"))
    vFCPST = ctypes.c_char_p(bytes(vFCPST, "utf-8"))
    vICMSDeson = ctypes.c_char_p(bytes(vICMSDeson, "utf-8"))
    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS)

def InformaICMS90(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c):
    fn = ffi.InformaICMS90
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC_a = ctypes.c_char_p(bytes(vBC_a, "utf-8"))
    pRedBCop_a = ctypes.c_char_p(bytes(pRedBCop_a, "utf-8"))
    pICMS_a = ctypes.c_char_p(bytes(pICMS_a, "utf-8"))
    vICMS_a = ctypes.c_char_p(bytes(vICMS_a, "utf-8"))
    vBCFCP_aa = ctypes.c_char_p(bytes(vBCFCP_aa, "utf-8"))
    pFCP_aa = ctypes.c_char_p(bytes(pFCP_aa, "utf-8"))
    vFCP_aa = ctypes.c_char_p(bytes(vFCP_aa, "utf-8"))
    pMVASTop_b = ctypes.c_char_p(bytes(pMVASTop_b, "utf-8"))
    pRedBCSTop_b = ctypes.c_char_p(bytes(pRedBCSTop_b, "utf-8"))
    vBCST_b = ctypes.c_char_p(bytes(vBCST_b, "utf-8"))
    pICMSST_b = ctypes.c_char_p(bytes(pICMSST_b, "utf-8"))
    vICMSST_b = ctypes.c_char_p(bytes(vICMSST_b, "utf-8"))
    vBCFCPST_bb = ctypes.c_char_p(bytes(vBCFCPST_bb, "utf-8"))
    pFCPST_bb = ctypes.c_char_p(bytes(pFCPST_bb, "utf-8"))
    vFCPST_bb = ctypes.c_char_p(bytes(vFCPST_bb, "utf-8"))
    vICMSDeson_c = ctypes.c_char_p(bytes(vICMSDeson_c, "utf-8"))
    return fn(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c)

def InformaICMSPart(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, pBCOper, UFST):
    fn = ffi.InformaICMSPart
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pRedBCop = ctypes.c_char_p(bytes(pRedBCop, "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    pMVASTop = ctypes.c_char_p(bytes(pMVASTop, "utf-8"))
    pRedBCSTop = ctypes.c_char_p(bytes(pRedBCSTop, "utf-8"))
    vBCST = ctypes.c_char_p(bytes(vBCST, "utf-8"))
    pICMSST = ctypes.c_char_p(bytes(pICMSST, "utf-8"))
    vICMSST = ctypes.c_char_p(bytes(vICMSST, "utf-8"))
    pBCOper = ctypes.c_char_p(bytes(pBCOper, "utf-8"))
    UFST = ctypes.c_char_p(bytes(UFST, "utf-8"))
    return fn(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, pBCOper, UFST)

def InformaICMSSN102(nItem, orig, CSOSN):
    fn = ffi.InformaICMSSN102
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p
    ]
    CSOSN = ctypes.c_char_p(bytes(CSOSN, "utf-8"))
    return fn(nItem, orig, CSOSN)

def InutilizarNumeracao(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal):
    fn = ffi.InutilizarNumeracao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # cnpj
        ctypes.c_char_p,  # ano
        ctypes.c_char_p,  # justificativa
        ctypes.c_char_p,  # uf
        ctypes.c_int,     # tpAmb
        ctypes.c_int,     # serie
        ctypes.c_int,     # numeroInicial
        ctypes.c_int      # numeroFinal
    ]

    cnpj = ctypes.c_char_p(cnpj.encode("utf-8"))
    ano = ctypes.c_char_p(ano.encode("utf-8"))
    justificativa = ctypes.c_char_p(justificativa.encode("utf-8"))
    uf = ctypes.c_char_p(uf.encode("utf-8"))
    
    # Converter strings para inteiros
    tpAmb = int(tpAmb)
    serie = int(serie)
    numeroInicial = int(numeroInicial)
    numeroFinal = int(numeroFinal)

    return fn(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal).decode("utf-8")

def ProcessamentoContingencia():
    fn = ffi.ProcessamentoContingencia

    fn.restype = ctypes.c_char_p
    fn.argtypes = []

    return fn().decode("utf-8")

def LoadPDF():
    fn = ffi.LoadPDF
    fn.restype = ctypes.c_int
    fn.argtypes = []
    return fn()

def ConfigurarDiretorioSaidaPDF(path):
    fn = ffi.ConfigurarDiretorioSaidaPDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p  # path
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    return fn(path).decode("utf-8")

def GerarDanfeNFCePDF(path, indexcsc, csc):
    fn = ffi.GerarDanfeNFCePDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_int,     # indexcsc
        ctypes.c_char_p   # csc
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    csc = ctypes.c_char_p(csc.encode("utf-8"))
    indexcsc = int(indexcsc)
    return fn(path, indexcsc, csc).decode("utf-8")

def GerarDanfeNFCePersonalizadoPDF(path, indexcsc, csc, param):
    fn = ffi.GerarDanfeNFCePersonalizadoPDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_int,     # indexcsc
        ctypes.c_char_p,  # csc
        ctypes.c_int      # param
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    csc = ctypes.c_char_p(csc.encode("utf-8"))
    indexcsc = int(indexcsc)
    param = int(param)
    return fn(path, indexcsc, csc, param).decode("utf-8")

def GerarDanfeNFePDF(path, logoPath):
    fn = ffi.GerarDanfeNFePDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_char_p   # logoPath
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    logoPath = ctypes.c_char_p(logoPath.encode("utf-8"))
    return fn(path, logoPath).decode("utf-8")

def GerarDanfeNFePersonalizadoPDF(path, logoPath, layout, param):
    fn = ffi.GerarDanfeNFePersonalizadoPDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_char_p,  # logoPath
        ctypes.c_int,     # layout
        ctypes.c_int      # param
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    logoPath = ctypes.c_char_p(logoPath.encode("utf-8"))
    layout = int(layout)
    param = int(param)
    return fn(path, logoPath, layout, param).decode("utf-8")

def UnloadPDF():
    fn = ffi.UnloadPDF
    fn.restype = ctypes.c_int
    fn.argtypes = []
    return fn()

# Funções faltantes para adicionar ao arquivo E1_NFCe.py

def InformaICMSST(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, 
                  vBCSTDest, vICMSSTDest, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMSST

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    vBCSTDest        = ctypes.c_char_p(bytes(vBCSTDest,        "utf-8"))
    vICMSSTDest      = ctypes.c_char_p(bytes(vICMSSTDest,      "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet,
              vBCSTDest, vICMSSTDest, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMSSN101(nItem, orig, CSOSN, pCredSN, vCredICMSSN):
    fn = ffi.InformaICMSSN101

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN         = ctypes.c_char_p(bytes(CSOSN,         "utf-8"))
    pCredSN       = ctypes.c_char_p(bytes(pCredSN,       "utf-8"))
    vCredICMSSN   = ctypes.c_char_p(bytes(vCredICMSSN,   "utf-8"))

    return fn(nItem, orig, CSOSN, pCredSN, vCredICMSSN)

def InformaICMSSN201(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN):
    fn = ffi.InformaICMSSN201

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN        = ctypes.c_char_p(bytes(CSOSN,        "utf-8"))
    pMVAST       = ctypes.c_char_p(bytes(pMVAST,       "utf-8"))
    pRedBCST     = ctypes.c_char_p(bytes(pRedBCST,     "utf-8"))
    vBCST        = ctypes.c_char_p(bytes(vBCST,        "utf-8"))
    pICMSST      = ctypes.c_char_p(bytes(pICMSST,      "utf-8"))
    vICMSST      = ctypes.c_char_p(bytes(vICMSST,      "utf-8"))
    vBCFCPST     = ctypes.c_char_p(bytes(vBCFCPST,     "utf-8"))
    pFCPST       = ctypes.c_char_p(bytes(pFCPST,       "utf-8"))
    vFCPST       = ctypes.c_char_p(bytes(vFCPST,       "utf-8"))
    pCredSN      = ctypes.c_char_p(bytes(pCredSN,      "utf-8"))
    vCredICMSSN  = ctypes.c_char_p(bytes(vCredICMSSN,  "utf-8"))

    return fn(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN)

def InformaICMSSN202(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST):
    fn = ffi.InformaICMSSN202

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN     = ctypes.c_char_p(bytes(CSOSN,     "utf-8"))
    pMVAST    = ctypes.c_char_p(bytes(pMVAST,    "utf-8"))
    pRedBCST  = ctypes.c_char_p(bytes(pRedBCST,  "utf-8"))
    vBCST     = ctypes.c_char_p(bytes(vBCST,     "utf-8"))
    pICMSST   = ctypes.c_char_p(bytes(pICMSST,   "utf-8"))
    vICMSST   = ctypes.c_char_p(bytes(vICMSST,   "utf-8"))
    vBCFCPST  = ctypes.c_char_p(bytes(vBCFCPST,  "utf-8"))
    pFCPST    = ctypes.c_char_p(bytes(pFCPST,    "utf-8"))
    vFCPST    = ctypes.c_char_p(bytes(vFCPST,    "utf-8"))

    return fn(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST)

def InformaICMSSN500(nItem, orig, CSOSN, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMSSN500

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN            = ctypes.c_char_p(bytes(CSOSN,            "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CSOSN, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMSSN900(nItem, orig, CSOSN, modBC, vBC, pRedBC, pICMS, vICMS, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN):
    fn = ffi.InformaICMSSN900

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN        = ctypes.c_char_p(bytes(CSOSN,        "utf-8"))
    vBC          = ctypes.c_char_p(bytes(vBC,          "utf-8"))
    pRedBC       = ctypes.c_char_p(bytes(pRedBC,       "utf-8"))
    pICMS        = ctypes.c_char_p(bytes(pICMS,        "utf-8"))
    vICMS        = ctypes.c_char_p(bytes(vICMS,        "utf-8"))
    pMVAST       = ctypes.c_char_p(bytes(pMVAST,       "utf-8"))
    pRedBCST     = ctypes.c_char_p(bytes(pRedBCST,     "utf-8"))
    vBCST        = ctypes.c_char_p(bytes(vBCST,        "utf-8"))
    pICMSST      = ctypes.c_char_p(bytes(pICMSST,      "utf-8"))
    vICMSST      = ctypes.c_char_p(bytes(vICMSST,      "utf-8"))
    vBCFCPST     = ctypes.c_char_p(bytes(vBCFCPST,     "utf-8"))
    pFCPST       = ctypes.c_char_p(bytes(pFCPST,       "utf-8"))
    vFCPST       = ctypes.c_char_p(bytes(vFCPST,       "utf-8"))
    pCredSN      = ctypes.c_char_p(bytes(pCredSN,      "utf-8"))
    vCredICMSSN  = ctypes.c_char_p(bytes(vCredICMSSN,  "utf-8"))

    return fn(nItem, orig, CSOSN, modBC, vBC, pRedBC, pICMS, vICMS, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN)

def InformaICMSUFDest(nItem, vBCUFDest, vBCFCPUFDest, pFCPUFDest, pICMSUFDest, pICMSInter, pICMSInterPart, vFCPUFDest, vICMSUFDest, vICMSUFRemet):
    fn = ffi.InformaICMSUFDest

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBCUFDest       = ctypes.c_char_p(bytes(vBCUFDest,       "utf-8"))
    vBCFCPUFDest    = ctypes.c_char_p(bytes(vBCFCPUFDest,    "utf-8"))
    pFCPUFDest      = ctypes.c_char_p(bytes(pFCPUFDest,      "utf-8"))
    pICMSUFDest     = ctypes.c_char_p(bytes(pICMSUFDest,     "utf-8"))
    pICMSInter      = ctypes.c_char_p(bytes(pICMSInter,      "utf-8"))
    pICMSInterPart  = ctypes.c_char_p(bytes(pICMSInterPart,  "utf-8"))
    vFCPUFDest      = ctypes.c_char_p(bytes(vFCPUFDest,      "utf-8"))
    vICMSUFDest     = ctypes.c_char_p(bytes(vICMSUFDest,     "utf-8"))
    vICMSUFRemet    = ctypes.c_char_p(bytes(vICMSUFRemet,    "utf-8"))

    return fn(nItem, vBCUFDest, vBCFCPUFDest, pFCPUFDest, pICMSUFDest, pICMSInter, pICMSInterPart, vFCPUFDest, vICMSUFDest, vICMSUFRemet)

def InformaIPITrib(nItem, CNPJProd, cSelo, qSelo, cEnq, CST, vBC, pIPI, qUnid, vUnid, vIPI):
    fn = ffi.InformaIPITrib

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJProd = ctypes.c_char_p(bytes(CNPJProd, "utf-8"))
    cSelo    = ctypes.c_char_p(bytes(cSelo,    "utf-8"))
    qSelo    = ctypes.c_char_p(bytes(qSelo,    "utf-8"))
    cEnq     = ctypes.c_char_p(bytes(cEnq,     "utf-8"))
    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))
    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    pIPI     = ctypes.c_char_p(bytes(pIPI,     "utf-8"))
    qUnid    = ctypes.c_char_p(bytes(qUnid,    "utf-8"))
    vUnid    = ctypes.c_char_p(bytes(vUnid,    "utf-8"))
    vIPI     = ctypes.c_char_p(bytes(vIPI,     "utf-8"))

    return fn(nItem, CNPJProd, cSelo, qSelo, cEnq, CST, vBC, pIPI, qUnid, vUnid, vIPI)

def InformaIPINT(nItem, CNPJProd, cSelo, qSelo, cEnq, CST):
    fn = ffi.InformaIPINT

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJProd = ctypes.c_char_p(bytes(CNPJProd, "utf-8"))
    cSelo    = ctypes.c_char_p(bytes(cSelo,    "utf-8"))
    qSelo    = ctypes.c_char_p(bytes(qSelo,    "utf-8"))
    cEnq     = ctypes.c_char_p(bytes(cEnq,     "utf-8"))
    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))

    return fn(nItem, CNPJProd, cSelo, qSelo, cEnq, CST)

def InformaII(nItem, vBC, vDespAdu, vII, vIOF):
    fn = ffi.InformaII

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    vDespAdu = ctypes.c_char_p(bytes(vDespAdu, "utf-8"))
    vII      = ctypes.c_char_p(bytes(vII,      "utf-8"))
    vIOF     = ctypes.c_char_p(bytes(vIOF,     "utf-8"))

    return fn(nItem, vBC, vDespAdu, vII, vIOF)

def InformaPISQtde(nItem, CST, qBCProd, vAliqProd, vPIS):
    fn = ffi.InformaPISQtde

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST        = ctypes.c_char_p(bytes(CST,        "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vPIS       = ctypes.c_char_p(bytes(vPIS,       "utf-8"))

    return fn(nItem, CST, qBCProd, vAliqProd, vPIS)

def InformaPISNT(nItem, CST):
    fn = ffi.InformaPISNT

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p
    ]

    CST = ctypes.c_char_p(bytes(CST, "utf-8"))

    return fn(nItem, CST)

def InformaPISST(nItem, vBC, pPIS, qBCProd, vAliqProd, vPIS):
    fn = ffi.InformaPISST

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBC        = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pPIS       = ctypes.c_char_p(bytes(pPIS,       "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vPIS       = ctypes.c_char_p(bytes(vPIS,       "utf-8"))

    return fn(nItem, vBC, pPIS, qBCProd, vAliqProd, vPIS)

def InformaCOFINSQtde(nItem, CST, qBCProd, vAliqProd, vCOFINS):
    fn = ffi.InformaCOFINSQtde

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST        = ctypes.c_char_p(bytes(CST,        "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vCOFINS    = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, qBCProd, vAliqProd, vCOFINS)

def InformaCOFINSNT(nItem, CST):
    fn = ffi.InformaCOFINSNT

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p
    ]

    CST = ctypes.c_char_p(bytes(CST, "utf-8"))

    return fn(nItem, CST)

def InformaCOFINSOutr(nItem, CST, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS):
    fn = ffi.InformaCOFINSOutr

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST        = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vBC        = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS    = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vCOFINS    = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS)

def InformaCOFINSST(nItem, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS):
    fn = ffi.InformaCOFINSST

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBC        = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS    = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vCOFINS    = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS)

def InformaISSQN(nItem, vBC, vAliq, vISSQN, cMunFG, cListServ, vDeducao, vOutro, vDescIncond, vDescCond, 
                 vISSRet, indISS, cServico, cMun, cPais, nProcesso, indIncentivo):
    fn = ffi.InformaISSQN

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    vBC          = ctypes.c_char_p(bytes(vBC,          "utf-8"))
    vAliq        = ctypes.c_char_p(bytes(vAliq,        "utf-8"))
    vISSQN       = ctypes.c_char_p(bytes(vISSQN,       "utf-8"))
    cMunFG       = ctypes.c_char_p(bytes(cMunFG,       "utf-8"))
    cListServ    = ctypes.c_char_p(bytes(cListServ,    "utf-8"))
    vDeducao     = ctypes.c_char_p(bytes(vDeducao,     "utf-8"))
    vOutro       = ctypes.c_char_p(bytes(vOutro,       "utf-8"))
    vDescIncond  = ctypes.c_char_p(bytes(vDescIncond,  "utf-8"))
    vDescCond    = ctypes.c_char_p(bytes(vDescCond,    "utf-8"))
    vISSRet      = ctypes.c_char_p(bytes(vISSRet,      "utf-8"))
    cServico     = ctypes.c_char_p(bytes(cServico,     "utf-8"))
    cMun         = ctypes.c_char_p(bytes(cMun,         "utf-8"))
    cPais        = ctypes.c_char_p(bytes(cPais,        "utf-8"))
    nProcesso    = ctypes.c_char_p(bytes(nProcesso,    "utf-8"))

    return fn(nItem, vBC, vAliq, vISSQN, cMunFG, cListServ, vDeducao, vOutro, vDescIncond, vDescCond, 
              vISSRet, indISS, cServico, cMun, cPais, nProcesso, indIncentivo)

def CartaDeCorrecao(chCFe, xCorrecao):
    fn = ffi.CartaDeCorrecao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    chCFe     = ctypes.c_char_p(bytes(chCFe,     "utf-8"))
    xCorrecao = ctypes.c_char_p(bytes(xCorrecao, "utf-8"))

    return fn(chCFe, xCorrecao).decode("utf-8")
    
if platform.system() == "Windows":
    ffimp = ctypes.WinDLL("./E1_Impressora01.dll")
else:
    ffimp = ctypes.cdll.LoadLibrary("./libE1_Impressora.so")
    
def AbreConexaoImpressora(tipo, modelo, conexao, param):
    fn = ffimp.AbreConexaoImpressora
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]

    modelo = ctypes.c_char_p(bytes(modelo, "utf-8"))
    conexao = ctypes.c_char_p(bytes(conexao, "utf-8"))

    return fn(tipo, modelo, conexao, param)


def FechaConexaoImpressora():
    fn = ffimp.FechaConexaoImpressora
    fn.restype = ctypes.c_int
    fn.argtypes = []

    return fn()
    
def Corte(avanco):
    fn = ffimp.Corte
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int]

    return fn(avanco)
    
def ImprimeXMLNFCe(dados, indexcsc, csc, param):
    fn = ffimp.ImprimeXMLNFCe
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]

    dados = ctypes.c_char_p(bytes(dados, "utf-8"))
    csc = ctypes.c_char_p(bytes(csc, "utf-8"))

    return fn(dados, indexcsc, csc, param)    
    
def ImprimeXMLCancelamentoNFCe(dados, param):
    fn = ffimp.ImprimeXMLCancelamentoNFCe
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_int]

    dados = ctypes.c_char_p(bytes(dados, "utf-8"))

    return fn(dados, param)
