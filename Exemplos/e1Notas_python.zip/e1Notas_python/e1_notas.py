import ctypes    # interagir com bibliotecas ou DLLs escritas em C/C++   
import platform  # informacoes do SO e Local


###
### CARREGA LIB
###

if platform.system() == "Windows":
  ffi = ctypes.WinDLL("./E1_Notas.dll")  #Windows
else:
  ffi = ctypes.cdll.LoadLibrary("./libE1_Notas.so")  #Linux

###
### FUNCOES CONSTRUCAO
###

def AbreCupomVenda(chaveDeAcesso):
    fn = ffi.AbreCupomVenda

    fn.restype = ctypes.c_int                                           #Tipo de retorno da função da DLL
    fn.argtypes = [ctypes.c_char_p]                                     #DLL espera um argumento tipo char*

    chaveDeAcesso = ctypes.c_char_p(bytes(chaveDeAcesso, "utf-8"))      #Converte chaveDeAcesso para C e transforma os bytes em ponteiro char*

    return fn(chaveDeAcesso)                                            #Chama a função da DLL com a chave convertida de retorna o valor inteiro

def InformaIdentificacao(cUF, cNF, natOp, mod, serie, nNF, dhEmi, dhSaiEnt, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV, 
                         tpAmb, finNFe, indFinal, indPres, indIntermed, procEmi, verProc, dhCont, xJust):
    fn = ffi.InformaIdentificacao

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,  # cUF
        ctypes.c_char_p,  # cNF
        ctypes.c_char_p,  # natOp
        ctypes.c_int,     # mod
        ctypes.c_char_p,  # serie
        ctypes.c_char_p,  # nNF
        ctypes.c_char_p,  # dhEmi
        ctypes.c_char_p,  # dhSaiEnt
        ctypes.c_int,     # tpNF
        ctypes.c_int,     # idDest
        ctypes.c_char_p,  # cMunFG
        ctypes.c_int,     # tpImp
        ctypes.c_int,     # tpEmis
        ctypes.c_int,     # cDV
        ctypes.c_int,     # tpAmb
        ctypes.c_int,     # finNFe
        ctypes.c_int,     # indFinal
        ctypes.c_int,     # indPres
        ctypes.c_int,     # indIntermed
        ctypes.c_int,     # procEmi
        ctypes.c_char_p,  # verProc
        ctypes.c_char_p,  # dhCont
        ctypes.c_char_p   # xJust
    ]

    cUF         = ctypes.c_char_p(bytes(cUF,         "utf-8"))
    cNF         = ctypes.c_char_p(bytes(cNF,        "utf-8"))
    natOp       = ctypes.c_char_p(bytes(natOp,      "utf-8"))
    serie       = ctypes.c_char_p(bytes(serie,      "utf-8"))
    nNF         = ctypes.c_char_p(bytes(nNF,        "utf-8"))
    dhEmi       = ctypes.c_char_p(bytes(dhEmi,      "utf-8"))
    dhSaiEnt    = ctypes.c_char_p(bytes(dhSaiEnt,   "utf-8"))
    cMunFG      = ctypes.c_char_p(bytes(cMunFG,     "utf-8"))
    verProc     = ctypes.c_char_p(bytes(verProc,    "utf-8"))
    dhCont      = ctypes.c_char_p(bytes(dhCont,     "utf-8"))
    xJust       = ctypes.c_char_p(bytes(xJust,      "utf-8"))

    return fn(cUF, cNF, natOp, mod, serie, nNF, dhEmi, dhSaiEnt, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV,
              tpAmb, finNFe, indFinal, indPres, indIntermed, procEmi, verProc, dhCont, xJust)

def InformaEmitente(CNPJ, CPF, xNome, xFant, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, IE, IEST, IM, CNAE, CRT):
    fn = ffi.InformaEmitente

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,       "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,        "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,      "utf-8"))
    xFant   = ctypes.c_char_p(bytes(xFant,      "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,       "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,        "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,       "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro,    "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,       "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,       "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,         "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,        "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,      "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,      "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,       "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,         "utf-8"))
    IEST    = ctypes.c_char_p(bytes(IEST,       "utf-8"))
    IM      = ctypes.c_char_p(bytes(IM,         "utf-8"))
    CNAE    = ctypes.c_char_p(bytes(CNAE,       "utf-8"))

    return fn(CNPJ, CPF, xNome, xFant, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, IE, IEST, IM, CNAE, CRT)

def InformaProduto(cProd, cEAN, xProd, NCM, NVE, CEST, indEscala, CNPJFab, cBenef, EXTIPI, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib,
                   uTrib, qTrib, vUnTrib, vFrete, vSeg, vDesc, vOutro, indTot):
    fn = ffi.InformaProduto

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    cProd       = ctypes.c_char_p(bytes(cProd,      "utf-8"))
    cEAN        = ctypes.c_char_p(bytes(cEAN,       "utf-8"))
    xProd       = ctypes.c_char_p(bytes(xProd,      "utf-8"))
    NCM         = ctypes.c_char_p(bytes(NCM,        "utf-8"))
    NVE         = ctypes.c_char_p(bytes(NVE,        "utf-8"))
    CEST        = ctypes.c_char_p(bytes(CEST,       "utf-8"))
    indEscala   = ctypes.c_char_p(bytes(indEscala,  "utf-8"))
    CNPJFab     = ctypes.c_char_p(bytes(CNPJFab,    "utf-8"))
    cBenef      = ctypes.c_char_p(bytes(cBenef,     "utf-8"))
    EXTIPI      = ctypes.c_char_p(bytes(EXTIPI,     "utf-8"))
    CFOP        = ctypes.c_char_p(bytes(CFOP,       "utf-8"))
    uCom        = ctypes.c_char_p(bytes(uCom,       "utf-8"))
    qCom        = ctypes.c_char_p(bytes(qCom,       "utf-8"))
    vUnCom      = ctypes.c_char_p(bytes(vUnCom,     "utf-8"))
    vProd       = ctypes.c_char_p(bytes(vProd,      "utf-8"))
    cEANTrib    = ctypes.c_char_p(bytes(cEANTrib,   "utf-8"))
    uTrib       = ctypes.c_char_p(bytes(uTrib,      "utf-8"))
    qTrib       = ctypes.c_char_p(bytes(qTrib,      "utf-8"))
    vUnTrib     = ctypes.c_char_p(bytes(vUnTrib,    "utf-8"))
    vFrete      = ctypes.c_char_p(bytes(vFrete,     "utf-8"))
    vSeg        = ctypes.c_char_p(bytes(vSeg,       "utf-8"))
    vDesc       = ctypes.c_char_p(bytes(vDesc,      "utf-8"))
    vOutro      = ctypes.c_char_p(bytes(vOutro,     "utf-8"))

    return fn(cProd, cEAN, xProd, NCM, NVE, CEST, indEscala, CNPJFab, cBenef, EXTIPI, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib,
              uTrib, qTrib, vUnTrib, vFrete, vSeg, vDesc, vOutro, indTot)

def InformaICMS40(nItem, orig, CST, vICMSDeson, motDesICMS, indDeduzDesonOp):
    fn = ffi.InformaICMS40

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson, "utf-8"))

    return fn(nItem, orig, CST, vICMSDeson, motDesICMS, indDeduzDesonOp)

def InformaPISAliq(nItem, CST, vBC, pPIS, vPIS):
    fn = ffi.InformaPISAliq

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST     = ctypes.c_char_p(bytes(CST,    "utf-8"))
    vBC     = ctypes.c_char_p(bytes(vBC,    "utf-8"))
    pPIS    = ctypes.c_char_p(bytes(pPIS,   "utf-8"))
    vPIS    = ctypes.c_char_p(bytes(vPIS,   "utf-8"))

    return fn(nItem, CST, vBC, pPIS, vPIS)

def InformaPISOutr(nItem, CST, vBC, pPIS, qBCProd_bEx, vAliqProd_bEx, vPIS):
    fn = ffi.InformaPISOutr

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
    ]

    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pPIS = ctypes.c_char_p(bytes(pPIS, "utf-8"))
    qBCProd_bEx = ctypes.c_char_p(bytes(qBCProd_bEx, "utf-8"))
    vAliqProd_bEx = ctypes.c_char_p(bytes(vAliqProd_bEx, "utf-8"))
    vPIS = ctypes.c_char_p(bytes(vPIS, "utf-8"))

    return fn(nItem, CST, vBC, pPIS, qBCProd_bEx, vAliqProd_bEx, vPIS)

def InformaCOFINSAliq(nItem, CST, vBC, pCOFINS, vCOFINS):
    fn = ffi.InformaCOFINSAliq

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST     = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vBC     = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    vCOFINS = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, vBC, pCOFINS, vCOFINS)

def InformaValorTotalTributos(nItem, vTotTrib):
    fn = ffi.InformaValorTotalTributos

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
    ]

    vTotTrib = ctypes.c_char_p(bytes(vTotTrib, "utf-8"))

    return fn(nItem, vTotTrib)

def InformaPagamento(indPagOp, tPag, xPagOp, vPag, dPagOp, tpIntegra, CNPJOp, tBandOp, cAutOp, CNPJRecebOp, idTermPagOp):
    fn = ffi.InformaPagamento

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    tPag        = ctypes.c_char_p(bytes(tPag, "utf-8"))
    xPagOp      = ctypes.c_char_p(bytes(xPagOp, "utf-8"))
    vPag        = ctypes.c_char_p(bytes(vPag, "utf-8"))
    dPagOp      = ctypes.c_char_p(bytes(dPagOp, "utf-8"))
    CNPJOp      = ctypes.c_char_p(bytes(CNPJOp, "utf-8"))
    tBandOp     = ctypes.c_char_p(bytes(tBandOp, "utf-8"))
    cAutOp      = ctypes.c_char_p(bytes(cAutOp, "utf-8"))
    CNPJRecebOp = ctypes.c_char_p(bytes(CNPJRecebOp, "utf-8"))
    idTermPagOp = ctypes.c_char_p(bytes(idTermPagOp, "utf-8"))

    return fn(indPagOp, tPag, xPagOp, vPag, dPagOp, tpIntegra, CNPJOp, tBandOp, cAutOp, CNPJRecebOp, idTermPagOp)

def InformaInformacoesPagamento(vTrocoOp, CNPJPag_a, UFPag_a):
    fn = ffi.InformaInformacoesPagamento

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vTrocoOp = ctypes.c_char_p(bytes(vTrocoOp, "utf-8"))
    CNPJPag_a = ctypes.c_char_p(bytes(CNPJPag_a, "utf-8"))
    UFPag_a = ctypes.c_char_p(bytes(UFPag_a, "utf-8"))

    return fn(vTrocoOp, CNPJPag_a, UFPag_a)

def InformaInformacoesAdicionais(infAdFiscoOp, infCplOp):
    fn = ffi.InformaInformacoesAdicionais

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    infAdFiscoOp    = ctypes.c_char_p(bytes(infAdFiscoOp,   "utf-8"))
    infCplOp        = ctypes.c_char_p(bytes(infCplOp,       "utf-8"))

    return fn(infAdFiscoOp, infCplOp)

def InformaObservacoesContribuinte(xCampo, xTexto):
    fn = ffi.InformaObservacoesContribuinte

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    xCampo  = ctypes.c_char_p(bytes(xCampo, "utf-8"))
    xTexto  = ctypes.c_char_p(bytes(xTexto, "utf-8"))

    return fn(xCampo, xTexto)

def InformaObservacoesFisco(xCampo, xTexto):
    fn = ffi.InformaObservacoesFisco

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    xCampo  = ctypes.c_char_p(bytes(xCampo, "utf-8"))
    xTexto  = ctypes.c_char_p(bytes(xTexto, "utf-8"))

    return fn(xCampo, xTexto)

def InformaProcessoReferenciado(nProc, indProc, tpAtoOp):
    fn = ffi.InformaProcessoReferenciado

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p
    ]

    nProc   = ctypes.c_char_p(bytes(nProc,  "utf-8"))
    tpAtoOp = ctypes.c_char_p(bytes(tpAtoOp, "utf-8"))

    return fn(nProc, indProc, tpAtoOp)

def FechaCupomVenda(path):
    fn = ffi.FechaCupomVenda

    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]

    path = ctypes.c_char_p(bytes(path, "utf-8"))

    return fn(path)

###
### FUNCOES TRANSMISSAO
###

def EmitirNota(path, uuid):
    fn = ffi.EmitirNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]

    path = ctypes.c_char_p(bytes(path, "utf-8"))
    uuid = ctypes.c_char_p(bytes(uuid, "utf-8"))

    return fn(path, uuid).decode("utf-8")

def ConsultarNota(chave):
    fn = ffi.ConsultarNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p]

    chave = ctypes.c_char_p(bytes(chave, "utf-8"))

    return fn(chave).decode("utf-8")

def ConsultarStatus(uuid):
    fn = ffi.ConsultarStatus

    fn.restype = ctypes.c_char_p
    fn.argtypes = [ctypes.c_char_p]

    uuid = ctypes.c_char_p(bytes(uuid, "utf-8"))

    return fn(uuid).decode("utf-8")

def CancelarNota(chave_nota, protocolo, justificativa):
    fn = ffi.CancelarNota

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    chave_nota      = ctypes.c_char_p(bytes(chave_nota,     "utf-8"))
    protocolo       = ctypes.c_char_p(bytes(protocolo,      "utf-8"))
    justificativa   = ctypes.c_char_p(bytes(justificativa,  "utf-8"))

    return fn(chave_nota, protocolo, justificativa).decode("utf-8")

def CancelamentoPorSubstituicao(chCFe, chCFeRef, justificativa, tpAutor):       #metodo adicionado 
    fn = ffi.CancelamentoPorSubstituicao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
    ]

    chCFe         = ctypes.c_char_p(bytes(chCFe, "utf-8"))
    chCFeRef      = ctypes.c_char_p(bytes(chCFeRef, "utf-8"))
    justificativa = ctypes.c_char_p(bytes(justificativa, "utf-8"))
    tpAutor       = ctypes.c_int(tpAutor)  # Aqui é só inteiro

    return fn(chCFe, chCFeRef, justificativa, tpAutor).decode("utf-8")


def InformaAvulsa(CNPJ, xOrgao, matr, xAgente, fone, UF, nDAR, dEmi, vDAR, repEmi, dPag):
    fn = ffi.InformaAvulsa

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    xOrgao  = ctypes.c_char_p(bytes(xOrgao,  "utf-8"))
    matr    = ctypes.c_char_p(bytes(matr,    "utf-8"))
    xAgente = ctypes.c_char_p(bytes(xAgente, "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    nDAR    = ctypes.c_char_p(bytes(nDAR,    "utf-8"))
    dEmi    = ctypes.c_char_p(bytes(dEmi,    "utf-8"))
    vDAR    = ctypes.c_char_p(bytes(vDAR,    "utf-8"))
    repEmi  = ctypes.c_char_p(bytes(repEmi,  "utf-8"))
    dPag    = ctypes.c_char_p(bytes(dPag,    "utf-8"))

    return fn(CNPJ, xOrgao, matr, xAgente, fone, UF, nDAR, dEmi, vDAR, repEmi, dPag)

def InformaDestinatario(CNPJ, CPF, idEstrangeiro, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, indIEDest, IE, ISUF, IM, email):
    fn = ffi.InformaDestinatario

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ          = ctypes.c_char_p(bytes(CNPJ,          "utf-8"))
    CPF           = ctypes.c_char_p(bytes(CPF,           "utf-8"))
    idEstrangeiro = ctypes.c_char_p(bytes(idEstrangeiro, "utf-8"))
    xNome         = ctypes.c_char_p(bytes(xNome,         "utf-8"))
    xLgr          = ctypes.c_char_p(bytes(xLgr,          "utf-8"))
    nro           = ctypes.c_char_p(bytes(nro,           "utf-8"))
    xCpl          = ctypes.c_char_p(bytes(xCpl,          "utf-8"))
    xBairro       = ctypes.c_char_p(bytes(xBairro,       "utf-8"))
    cMun          = ctypes.c_char_p(bytes(cMun,          "utf-8"))
    xMun          = ctypes.c_char_p(bytes(xMun,          "utf-8"))
    UF            = ctypes.c_char_p(bytes(UF,            "utf-8"))
    CEP           = ctypes.c_char_p(bytes(CEP,           "utf-8"))
    cPais         = ctypes.c_char_p(bytes(cPais,         "utf-8"))
    xPais         = ctypes.c_char_p(bytes(xPais,         "utf-8"))
    fone          = ctypes.c_char_p(bytes(fone,          "utf-8"))
    IE            = ctypes.c_char_p(bytes(IE,            "utf-8"))
    ISUF          = ctypes.c_char_p(bytes(ISUF,          "utf-8"))
    IM            = ctypes.c_char_p(bytes(IM,            "utf-8"))
    email         = ctypes.c_char_p(bytes(email,         "utf-8"))

    return fn(CNPJ, CPF, idEstrangeiro, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, indIEDest, IE, ISUF, IM, email)

def InformaRetirada(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE):
    fn = ffi.InformaRetirada

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,     "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,   "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,    "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,     "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,    "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro, "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,    "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,     "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,   "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,   "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    email   = ctypes.c_char_p(bytes(email,   "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,      "utf-8"))

    return fn(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE)

def InformaEntrega(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE):
    fn = ffi.InformaEntrega

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ    = ctypes.c_char_p(bytes(CNPJ,    "utf-8"))
    CPF     = ctypes.c_char_p(bytes(CPF,     "utf-8"))
    xNome   = ctypes.c_char_p(bytes(xNome,   "utf-8"))
    xLgr    = ctypes.c_char_p(bytes(xLgr,    "utf-8"))
    nro     = ctypes.c_char_p(bytes(nro,     "utf-8"))
    xCpl    = ctypes.c_char_p(bytes(xCpl,    "utf-8"))
    xBairro = ctypes.c_char_p(bytes(xBairro, "utf-8"))
    cMun    = ctypes.c_char_p(bytes(cMun,    "utf-8"))
    xMun    = ctypes.c_char_p(bytes(xMun,    "utf-8"))
    UF      = ctypes.c_char_p(bytes(UF,      "utf-8"))
    CEP     = ctypes.c_char_p(bytes(CEP,     "utf-8"))
    cPais   = ctypes.c_char_p(bytes(cPais,   "utf-8"))
    xPais   = ctypes.c_char_p(bytes(xPais,   "utf-8"))
    fone    = ctypes.c_char_p(bytes(fone,    "utf-8"))
    email   = ctypes.c_char_p(bytes(email,   "utf-8"))
    IE      = ctypes.c_char_p(bytes(IE,      "utf-8"))

    return fn(CNPJ, CPF, xNome, xLgr, nro, xCpl, xBairro, cMun, xMun, UF, CEP, cPais, xPais, fone, email, IE)

def InformaAutorizacaoXML(CNPJ, CPF):
    fn = ffi.InformaAutorizacaoXML

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJ = ctypes.c_char_p(bytes(CNPJ, "utf-8"))
    CPF  = ctypes.c_char_p(bytes(CPF,  "utf-8"))

    return fn(CNPJ, CPF)

def InformaICMS00(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP, vFCP):
    fn = ffi.InformaICMS00

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST   = ctypes.c_char_p(bytes(CST,   "utf-8"))
    vBC   = ctypes.c_char_p(bytes(vBC,   "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    pFCP  = ctypes.c_char_p(bytes(pFCP,  "utf-8"))
    vFCP  = ctypes.c_char_p(bytes(vFCP,  "utf-8"))

    return fn(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP, vFCP)

def InformaICMS10(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST):
    fn = ffi.InformaICMS10

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))
    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    pICMS    = ctypes.c_char_p(bytes(pICMS,    "utf-8"))
    vICMS    = ctypes.c_char_p(bytes(vICMS,    "utf-8"))
    vBCFCP   = ctypes.c_char_p(bytes(vBCFCP,   "utf-8"))
    pFCP     = ctypes.c_char_p(bytes(pFCP,     "utf-8"))
    vFCP     = ctypes.c_char_p(bytes(vFCP,     "utf-8"))
    pMVAST   = ctypes.c_char_p(bytes(pMVAST,   "utf-8"))
    pRedBCST = ctypes.c_char_p(bytes(pRedBCST, "utf-8"))
    vBCST    = ctypes.c_char_p(bytes(vBCST,    "utf-8"))
    pICMSST  = ctypes.c_char_p(bytes(pICMSST,  "utf-8"))
    vICMSST  = ctypes.c_char_p(bytes(vICMSST,  "utf-8"))
    vBCFCPST = ctypes.c_char_p(bytes(vBCFCPST, "utf-8"))
    pFCPST   = ctypes.c_char_p(bytes(pFCPST,   "utf-8"))
    vFCPST   = ctypes.c_char_p(bytes(vFCPST,   "utf-8"))

    return fn(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST)

def InformaICMS20(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, vICMSDeson, motDesICMS, indDeduzDesonOp):
    fn = ffi.InformaICMS20

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,         "utf-8"))
    pRedBC      = ctypes.c_char_p(bytes(pRedBC,      "utf-8"))
    vBC         = ctypes.c_char_p(bytes(vBC,         "utf-8"))
    pICMS       = ctypes.c_char_p(bytes(pICMS,       "utf-8"))
    vICMS       = ctypes.c_char_p(bytes(vICMS,       "utf-8"))
    vBCFCP      = ctypes.c_char_p(bytes(vBCFCP,      "utf-8"))
    pFCP        = ctypes.c_char_p(bytes(pFCP,        "utf-8"))
    vFCP        = ctypes.c_char_p(bytes(vFCP,        "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson,  "utf-8"))

    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, vICMSDeson, motDesICMS, indDeduzDesonOp)

def InformaICMS30(nItem, orig, CST, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS, indDeduzDesonOp):
    fn = ffi.InformaICMS30

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_int
    ]

    CST         = ctypes.c_char_p(bytes(CST,         "utf-8"))
    pMVAST      = ctypes.c_char_p(bytes(pMVAST,      "utf-8"))
    pRedBCST    = ctypes.c_char_p(bytes(pRedBCST,    "utf-8"))
    vBCST       = ctypes.c_char_p(bytes(vBCST,       "utf-8"))
    pICMSST     = ctypes.c_char_p(bytes(pICMSST,     "utf-8"))
    vICMSST     = ctypes.c_char_p(bytes(vICMSST,     "utf-8"))
    vBCFCPST    = ctypes.c_char_p(bytes(vBCFCPST,    "utf-8"))
    pFCPST      = ctypes.c_char_p(bytes(pFCPST,      "utf-8"))
    vFCPST      = ctypes.c_char_p(bytes(vFCPST,      "utf-8"))
    vICMSDeson  = ctypes.c_char_p(bytes(vICMSDeson,  "utf-8"))

    return fn(nItem, orig, CST, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS, indDeduzDesonOp)

def InformaICMS51(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMSOp, pDif, vICMSDif, vICMS, vBCFCP, pFCP, vFCP):
    fn = ffi.InformaICMS51

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST       = ctypes.c_char_p(bytes(CST,       "utf-8"))
    pRedBC    = ctypes.c_char_p(bytes(pRedBC,    "utf-8"))
    vBC       = ctypes.c_char_p(bytes(vBC,       "utf-8"))
    pICMS     = ctypes.c_char_p(bytes(pICMS,     "utf-8"))
    vICMSOp   = ctypes.c_char_p(bytes(vICMSOp,   "utf-8"))
    pDif      = ctypes.c_char_p(bytes(pDif,      "utf-8"))
    vICMSDif  = ctypes.c_char_p(bytes(vICMSDif,  "utf-8"))
    vICMS     = ctypes.c_char_p(bytes(vICMS,     "utf-8"))
    vBCFCP    = ctypes.c_char_p(bytes(vBCFCP,    "utf-8"))
    pFCP      = ctypes.c_char_p(bytes(pFCP,      "utf-8"))
    vFCP      = ctypes.c_char_p(bytes(vFCP,      "utf-8"))

    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMSOp, pDif, vICMSDif, vICMS, vBCFCP, pFCP, vFCP)

def InformaICMS60(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMS60

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMS70(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS, indDeduzDesonOp):
    fn = ffi.InformaICMS70
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    pRedBC = ctypes.c_char_p(bytes(pRedBC, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    vBCFCP = ctypes.c_char_p(bytes(vBCFCP, "utf-8"))
    pFCP = ctypes.c_char_p(bytes(pFCP, "utf-8"))
    vFCP = ctypes.c_char_p(bytes(vFCP, "utf-8"))
    pMVAST = ctypes.c_char_p(bytes(pMVAST, "utf-8"))
    pRedBCST = ctypes.c_char_p(bytes(pRedBCST, "utf-8"))
    vBCST = ctypes.c_char_p(bytes(vBCST, "utf-8"))
    pICMSST = ctypes.c_char_p(bytes(pICMSST, "utf-8"))
    vICMSST = ctypes.c_char_p(bytes(vICMSST, "utf-8"))
    vBCFCPST = ctypes.c_char_p(bytes(vBCFCPST, "utf-8"))
    pFCPST = ctypes.c_char_p(bytes(pFCPST, "utf-8"))
    vFCPST = ctypes.c_char_p(bytes(vFCPST, "utf-8"))
    vICMSDeson = ctypes.c_char_p(bytes(vICMSDeson, "utf-8"))
    return fn(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP, pFCP, vFCP, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, vICMSDeson, motDesICMS, indDeduzDesonOp)

def InformaICMS90(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c, indDeduzDesonOp):
    fn = ffi.InformaICMS90
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC_a = ctypes.c_char_p(bytes(vBC_a, "utf-8"))
    pRedBCop_a = ctypes.c_char_p(bytes(pRedBCop_a, "utf-8"))
    pICMS_a = ctypes.c_char_p(bytes(pICMS_a, "utf-8"))
    vICMS_a = ctypes.c_char_p(bytes(vICMS_a, "utf-8"))
    vBCFCP_aa = ctypes.c_char_p(bytes(vBCFCP_aa, "utf-8"))
    pFCP_aa = ctypes.c_char_p(bytes(pFCP_aa, "utf-8"))
    vFCP_aa = ctypes.c_char_p(bytes(vFCP_aa, "utf-8"))
    pMVASTop_b = ctypes.c_char_p(bytes(pMVASTop_b, "utf-8"))
    pRedBCSTop_b = ctypes.c_char_p(bytes(pRedBCSTop_b, "utf-8"))
    vBCST_b = ctypes.c_char_p(bytes(vBCST_b, "utf-8"))
    pICMSST_b = ctypes.c_char_p(bytes(pICMSST_b, "utf-8"))
    vICMSST_b = ctypes.c_char_p(bytes(vICMSST_b, "utf-8"))
    vBCFCPST_bb = ctypes.c_char_p(bytes(vBCFCPST_bb, "utf-8"))
    pFCPST_bb = ctypes.c_char_p(bytes(pFCPST_bb, "utf-8"))
    vFCPST_bb = ctypes.c_char_p(bytes(vFCPST_bb, "utf-8"))
    vICMSDeson_c = ctypes.c_char_p(bytes(vICMSDeson_c, "utf-8"))
    return fn(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c, indDeduzDesonOp)

def InformaICMSPart(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, pBCOper, UFST):
    fn = ffi.InformaICMSPart
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p
    ]
    CST = ctypes.c_char_p(bytes(CST, "utf-8"))
    vBC = ctypes.c_char_p(bytes(vBC, "utf-8"))
    pRedBCop = ctypes.c_char_p(bytes(pRedBCop, "utf-8"))
    pICMS = ctypes.c_char_p(bytes(pICMS, "utf-8"))
    vICMS = ctypes.c_char_p(bytes(vICMS, "utf-8"))
    pMVASTop = ctypes.c_char_p(bytes(pMVASTop, "utf-8"))
    pRedBCSTop = ctypes.c_char_p(bytes(pRedBCSTop, "utf-8"))
    vBCST = ctypes.c_char_p(bytes(vBCST, "utf-8"))
    pICMSST = ctypes.c_char_p(bytes(pICMSST, "utf-8"))
    vICMSST = ctypes.c_char_p(bytes(vICMSST, "utf-8"))
    vBCFCPST_a = ctypes.c_char_p(bytes(vBCFCPST_a, "utf-8"))
    pFCPST_a = ctypes.c_char_p(bytes(pFCPST_a, "utf-8"))
    vFCPST_a = ctypes.c_char_p(bytes(vFCPST_a, "utf-8"))
    pBCOper = ctypes.c_char_p(bytes(pBCOper, "utf-8"))
    UFST = ctypes.c_char_p(bytes(UFST, "utf-8"))
    return fn(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, pBCOper, UFST)

def InformaICMSSN102(nItem, orig, CSOSN):
    fn = ffi.InformaICMSSN102
    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p
    ]
    CSOSN = ctypes.c_char_p(bytes(CSOSN, "utf-8"))
    return fn(nItem, orig, CSOSN)

def InutilizarNumeracao(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal):
    fn = ffi.InutilizarNumeracao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # cnpj
        ctypes.c_char_p,  # ano
        ctypes.c_char_p,  # justificativa
        ctypes.c_char_p,  # uf
        ctypes.c_int,     # tpAmb
        ctypes.c_int,     # serie
        ctypes.c_int,     # numeroInicial
        ctypes.c_int      # numeroFinal
    ]

    cnpj = ctypes.c_char_p(cnpj.encode("utf-8"))
    ano = ctypes.c_char_p(ano.encode("utf-8"))
    justificativa = ctypes.c_char_p(justificativa.encode("utf-8"))
    uf = ctypes.c_char_p(uf.encode("utf-8"))
    
    # Converter strings para inteiros
    tpAmb = int(tpAmb)
    serie = int(serie)
    numeroInicial = int(numeroInicial)
    numeroFinal = int(numeroFinal)

    return fn(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal).decode("utf-8")

def ProcessamentoContingencia():
    fn = ffi.ProcessamentoContingencia

    fn.restype = ctypes.c_char_p
    fn.argtypes = []

    return fn().decode("utf-8")

def LoadPDF():
    fn = ffi.LoadPDF
    fn.restype = ctypes.c_int
    fn.argtypes = []
    return fn()

def ConfigurarDiretorioSaidaPDF(path):
    fn = ffi.ConfigurarDiretorioSaidaPDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p  # path
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    return fn(path).decode("utf-8")

def GerarDanfeNFCePDF(path, indexcsc, csc):
    fn = ffi.GerarDanfeNFCePDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_int,     # indexcsc
        ctypes.c_char_p   # csc
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    csc = ctypes.c_char_p(csc.encode("utf-8"))
    indexcsc = int(indexcsc)
    return fn(path, indexcsc, csc).decode("utf-8")

def GerarDanfeNFCePersonalizadoPDF(path, indexcsc, csc, param):
    fn = ffi.GerarDanfeNFCePersonalizadoPDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_int,     # indexcsc
        ctypes.c_char_p,  # csc
        ctypes.c_int      # param
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    csc = ctypes.c_char_p(csc.encode("utf-8"))
    indexcsc = int(indexcsc)
    param = int(param)
    return fn(path, indexcsc, csc, param).decode("utf-8")

def GerarDanfeNFePDF(path, logoPath):
    fn = ffi.GerarDanfeNFePDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_char_p   # logoPath
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    logoPath = ctypes.c_char_p(logoPath.encode("utf-8"))
    return fn(path, logoPath).decode("utf-8")

def GerarDanfeNFePersonalizadoPDF(path, logoPath, layout, param):
    fn = ffi.GerarDanfeNFePersonalizadoPDF
    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,  # path
        ctypes.c_char_p,  # logoPath
        ctypes.c_int,     # layout
        ctypes.c_int      # param
    ]
    path = ctypes.c_char_p(path.encode("utf-8"))
    logoPath = ctypes.c_char_p(logoPath.encode("utf-8"))
    layout = int(layout)
    param = int(param)
    return fn(path, logoPath, layout, param).decode("utf-8")

def UnloadPDF():
    fn = ffi.UnloadPDF
    fn.restype = ctypes.c_int
    fn.argtypes = []
    return fn()

# Funções faltantes para adicionar ao arquivo E1_NFCe.py

def InformaICMSST(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, 
                  vBCSTDest, vICMSSTDest, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMSST

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    vBCSTDest        = ctypes.c_char_p(bytes(vBCSTDest,        "utf-8"))
    vICMSSTDest      = ctypes.c_char_p(bytes(vICMSSTDest,      "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CST, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet,
              vBCSTDest, vICMSSTDest, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMSSN101(nItem, orig, CSOSN, pCredSN, vCredICMSSN):
    fn = ffi.InformaICMSSN101

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN         = ctypes.c_char_p(bytes(CSOSN,         "utf-8"))
    pCredSN       = ctypes.c_char_p(bytes(pCredSN,       "utf-8"))
    vCredICMSSN   = ctypes.c_char_p(bytes(vCredICMSSN,   "utf-8"))

    return fn(nItem, orig, CSOSN, pCredSN, vCredICMSSN)

def InformaICMSSN201(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN):
    fn = ffi.InformaICMSSN201

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN        = ctypes.c_char_p(bytes(CSOSN,        "utf-8"))
    pMVAST       = ctypes.c_char_p(bytes(pMVAST,       "utf-8"))
    pRedBCST     = ctypes.c_char_p(bytes(pRedBCST,     "utf-8"))
    vBCST        = ctypes.c_char_p(bytes(vBCST,        "utf-8"))
    pICMSST      = ctypes.c_char_p(bytes(pICMSST,      "utf-8"))
    vICMSST      = ctypes.c_char_p(bytes(vICMSST,      "utf-8"))
    vBCFCPST     = ctypes.c_char_p(bytes(vBCFCPST,     "utf-8"))
    pFCPST       = ctypes.c_char_p(bytes(pFCPST,       "utf-8"))
    vFCPST       = ctypes.c_char_p(bytes(vFCPST,       "utf-8"))
    pCredSN      = ctypes.c_char_p(bytes(pCredSN,      "utf-8"))
    vCredICMSSN  = ctypes.c_char_p(bytes(vCredICMSSN,  "utf-8"))

    return fn(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN)

def InformaICMSSN202(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST):
    fn = ffi.InformaICMSSN202

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN     = ctypes.c_char_p(bytes(CSOSN,     "utf-8"))
    pMVAST    = ctypes.c_char_p(bytes(pMVAST,    "utf-8"))
    pRedBCST  = ctypes.c_char_p(bytes(pRedBCST,  "utf-8"))
    vBCST     = ctypes.c_char_p(bytes(vBCST,     "utf-8"))
    pICMSST   = ctypes.c_char_p(bytes(pICMSST,   "utf-8"))
    vICMSST   = ctypes.c_char_p(bytes(vICMSST,   "utf-8"))
    vBCFCPST  = ctypes.c_char_p(bytes(vBCFCPST,  "utf-8"))
    pFCPST    = ctypes.c_char_p(bytes(pFCPST,    "utf-8"))
    vFCPST    = ctypes.c_char_p(bytes(vFCPST,    "utf-8"))

    return fn(nItem, orig, CSOSN, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST)

def InformaICMSSN500(nItem, orig, CSOSN, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet):
    fn = ffi.InformaICMSSN500

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN            = ctypes.c_char_p(bytes(CSOSN,            "utf-8"))
    vBCSTRet         = ctypes.c_char_p(bytes(vBCSTRet,         "utf-8"))
    pST              = ctypes.c_char_p(bytes(pST,              "utf-8"))
    vICMSSubstituto  = ctypes.c_char_p(bytes(vICMSSubstituto,  "utf-8"))
    vICMSSTRet       = ctypes.c_char_p(bytes(vICMSSTRet,       "utf-8"))
    vBCFCPSTRet      = ctypes.c_char_p(bytes(vBCFCPSTRet,      "utf-8"))
    pFCPSTRet        = ctypes.c_char_p(bytes(pFCPSTRet,        "utf-8"))
    vFCPSTRet        = ctypes.c_char_p(bytes(vFCPSTRet,        "utf-8"))
    pRedBCEfet       = ctypes.c_char_p(bytes(pRedBCEfet,       "utf-8"))
    vBCEfet          = ctypes.c_char_p(bytes(vBCEfet,          "utf-8"))
    pICMSEfet        = ctypes.c_char_p(bytes(pICMSEfet,        "utf-8"))
    vICMSEfet        = ctypes.c_char_p(bytes(vICMSEfet,        "utf-8"))

    return fn(nItem, orig, CSOSN, vBCSTRet, pST, vICMSSubstituto, vICMSSTRet, vBCFCPSTRet, pFCPSTRet, vFCPSTRet, pRedBCEfet, vBCEfet, pICMSEfet, vICMSEfet)

def InformaICMSSN900(nItem, orig, CSOSN, modBC, vBC, pRedBC, pICMS, vICMS, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN):
    fn = ffi.InformaICMSSN900

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CSOSN        = ctypes.c_char_p(bytes(CSOSN,        "utf-8"))
    vBC          = ctypes.c_char_p(bytes(vBC,          "utf-8"))
    pRedBC       = ctypes.c_char_p(bytes(pRedBC,       "utf-8"))
    pICMS        = ctypes.c_char_p(bytes(pICMS,        "utf-8"))
    vICMS        = ctypes.c_char_p(bytes(vICMS,        "utf-8"))
    pMVAST       = ctypes.c_char_p(bytes(pMVAST,       "utf-8"))
    pRedBCST     = ctypes.c_char_p(bytes(pRedBCST,     "utf-8"))
    vBCST        = ctypes.c_char_p(bytes(vBCST,        "utf-8"))
    pICMSST      = ctypes.c_char_p(bytes(pICMSST,      "utf-8"))
    vICMSST      = ctypes.c_char_p(bytes(vICMSST,      "utf-8"))
    vBCFCPST     = ctypes.c_char_p(bytes(vBCFCPST,     "utf-8"))
    pFCPST       = ctypes.c_char_p(bytes(pFCPST,       "utf-8"))
    vFCPST       = ctypes.c_char_p(bytes(vFCPST,       "utf-8"))
    pCredSN      = ctypes.c_char_p(bytes(pCredSN,      "utf-8"))
    vCredICMSSN  = ctypes.c_char_p(bytes(vCredICMSSN,  "utf-8"))

    return fn(nItem, orig, CSOSN, modBC, vBC, pRedBC, pICMS, vICMS, modBCST, pMVAST, pRedBCST, vBCST, pICMSST, vICMSST, vBCFCPST, pFCPST, vFCPST, pCredSN, vCredICMSSN)

def InformaICMSUFDest(nItem, vBCUFDest, vBCFCPUFDest, pFCPUFDest, pICMSUFDest, pICMSInter, pICMSInterPart, vFCPUFDest, vICMSUFDest, vICMSUFRemet):
    fn = ffi.InformaICMSUFDest

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBCUFDest       = ctypes.c_char_p(bytes(vBCUFDest,       "utf-8"))
    vBCFCPUFDest    = ctypes.c_char_p(bytes(vBCFCPUFDest,    "utf-8"))
    pFCPUFDest      = ctypes.c_char_p(bytes(pFCPUFDest,      "utf-8"))
    pICMSUFDest     = ctypes.c_char_p(bytes(pICMSUFDest,     "utf-8"))
    pICMSInter      = ctypes.c_char_p(bytes(pICMSInter,      "utf-8"))
    pICMSInterPart  = ctypes.c_char_p(bytes(pICMSInterPart,  "utf-8"))
    vFCPUFDest      = ctypes.c_char_p(bytes(vFCPUFDest,      "utf-8"))
    vICMSUFDest     = ctypes.c_char_p(bytes(vICMSUFDest,     "utf-8"))
    vICMSUFRemet    = ctypes.c_char_p(bytes(vICMSUFRemet,    "utf-8"))

    return fn(nItem, vBCUFDest, vBCFCPUFDest, pFCPUFDest, pICMSUFDest, pICMSInter, pICMSInterPart, vFCPUFDest, vICMSUFDest, vICMSUFRemet)

def InformaIPITrib(nItem, CNPJProd, cSelo, qSelo, cEnq, CST, vBC, pIPI, qUnid, vUnid, vIPI):
    fn = ffi.InformaIPITrib

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJProd = ctypes.c_char_p(bytes(CNPJProd, "utf-8"))
    cSelo    = ctypes.c_char_p(bytes(cSelo,    "utf-8"))
    qSelo    = ctypes.c_char_p(bytes(qSelo,    "utf-8"))
    cEnq     = ctypes.c_char_p(bytes(cEnq,     "utf-8"))
    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))
    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    pIPI     = ctypes.c_char_p(bytes(pIPI,     "utf-8"))
    qUnid    = ctypes.c_char_p(bytes(qUnid,    "utf-8"))
    vUnid    = ctypes.c_char_p(bytes(vUnid,    "utf-8"))
    vIPI     = ctypes.c_char_p(bytes(vIPI,     "utf-8"))

    return fn(nItem, CNPJProd, cSelo, qSelo, cEnq, CST, vBC, pIPI, qUnid, vUnid, vIPI)

def InformaIPINT(nItem, CNPJProd, cSelo, qSelo, cEnq, CST):
    fn = ffi.InformaIPINT

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CNPJProd = ctypes.c_char_p(bytes(CNPJProd, "utf-8"))
    cSelo    = ctypes.c_char_p(bytes(cSelo,    "utf-8"))
    qSelo    = ctypes.c_char_p(bytes(qSelo,    "utf-8"))
    cEnq     = ctypes.c_char_p(bytes(cEnq,     "utf-8"))
    CST      = ctypes.c_char_p(bytes(CST,      "utf-8"))

    return fn(nItem, CNPJProd, cSelo, qSelo, cEnq, CST)

def InformaII(nItem, vBC, vDespAdu, vII, vIOF):
    fn = ffi.InformaII

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBC      = ctypes.c_char_p(bytes(vBC,      "utf-8"))
    vDespAdu = ctypes.c_char_p(bytes(vDespAdu, "utf-8"))
    vII      = ctypes.c_char_p(bytes(vII,      "utf-8"))
    vIOF     = ctypes.c_char_p(bytes(vIOF,     "utf-8"))

    return fn(nItem, vBC, vDespAdu, vII, vIOF)

def InformaPISQtde(nItem, CST, qBCProd, vAliqProd, vPIS):
    fn = ffi.InformaPISQtde

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST        = ctypes.c_char_p(bytes(CST,        "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vPIS       = ctypes.c_char_p(bytes(vPIS,       "utf-8"))

    return fn(nItem, CST, qBCProd, vAliqProd, vPIS)

def InformaPISNT(nItem, CST):
    fn = ffi.InformaPISNT

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p
    ]

    CST = ctypes.c_char_p(bytes(CST, "utf-8"))

    return fn(nItem, CST)

def InformaPISST(nItem, vBC, pPIS, qBCProd, vAliqProd, vPIS):
    fn = ffi.InformaPISST

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBC        = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pPIS       = ctypes.c_char_p(bytes(pPIS,       "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vPIS       = ctypes.c_char_p(bytes(vPIS,       "utf-8"))

    return fn(nItem, vBC, pPIS, qBCProd, vAliqProd, vPIS)

def InformaCOFINSQtde(nItem, CST, qBCProd, vAliqProd, vCOFINS):
    fn = ffi.InformaCOFINSQtde

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST        = ctypes.c_char_p(bytes(CST,        "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vCOFINS    = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, qBCProd, vAliqProd, vCOFINS)

def InformaCOFINSNT(nItem, CST):
    fn = ffi.InformaCOFINSNT

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p
    ]

    CST = ctypes.c_char_p(bytes(CST, "utf-8"))

    return fn(nItem, CST)

def InformaCOFINSOutr(nItem, CST, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS):
    fn = ffi.InformaCOFINSOutr

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST        = ctypes.c_char_p(bytes(CST,        "utf-8"))
    vBC        = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS    = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vCOFINS    = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, CST, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS)

def InformaCOFINSST(nItem, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS):
    fn = ffi.InformaCOFINSST

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    vBC        = ctypes.c_char_p(bytes(vBC,        "utf-8"))
    pCOFINS    = ctypes.c_char_p(bytes(pCOFINS,    "utf-8"))
    qBCProd    = ctypes.c_char_p(bytes(qBCProd,    "utf-8"))
    vAliqProd  = ctypes.c_char_p(bytes(vAliqProd,  "utf-8"))
    vCOFINS    = ctypes.c_char_p(bytes(vCOFINS,    "utf-8"))

    return fn(nItem, vBC, pCOFINS, qBCProd, vAliqProd, vCOFINS)

def InformaISSQN(nItem, vBC, vAliq, vISSQN, cMunFG, cListServ, vDeducao, vOutro, vDescIncond, vDescCond, 
                 vISSRet, indISS, cServico, cMun, cPais, nProcesso, indIncentivo):
    fn = ffi.InformaISSQN

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    vBC          = ctypes.c_char_p(bytes(vBC,          "utf-8"))
    vAliq        = ctypes.c_char_p(bytes(vAliq,        "utf-8"))
    vISSQN       = ctypes.c_char_p(bytes(vISSQN,       "utf-8"))
    cMunFG       = ctypes.c_char_p(bytes(cMunFG,       "utf-8"))
    cListServ    = ctypes.c_char_p(bytes(cListServ,    "utf-8"))
    vDeducao     = ctypes.c_char_p(bytes(vDeducao,     "utf-8"))
    vOutro       = ctypes.c_char_p(bytes(vOutro,       "utf-8"))
    vDescIncond  = ctypes.c_char_p(bytes(vDescIncond,  "utf-8"))
    vDescCond    = ctypes.c_char_p(bytes(vDescCond,    "utf-8"))
    vISSRet      = ctypes.c_char_p(bytes(vISSRet,      "utf-8"))
    cServico     = ctypes.c_char_p(bytes(cServico,     "utf-8"))
    cMun         = ctypes.c_char_p(bytes(cMun,         "utf-8"))
    cPais        = ctypes.c_char_p(bytes(cPais,        "utf-8"))
    nProcesso    = ctypes.c_char_p(bytes(nProcesso,    "utf-8"))

    return fn(nItem, vBC, vAliq, vISSQN, cMunFG, cListServ, vDeducao, vOutro, vDescIncond, vDescCond, 
              vISSRet, indISS, cServico, cMun, cPais, nProcesso, indIncentivo)

# Adicionar estas funções ao final do arquivo e1_notas.py

def InformaCombustivel(nItem, cProdANP, descANP, pGLPOp, pGNnOp, pGNiOp, vPartOp, CODIFOp, qTempOp, UFCons, pBioOp):
    fn = ffi.InformaCombustivel

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    cProdANP = ctypes.c_char_p(bytes(cProdANP, "utf-8"))
    descANP  = ctypes.c_char_p(bytes(descANP,  "utf-8"))
    pGLPOp   = ctypes.c_char_p(bytes(pGLPOp,   "utf-8"))
    pGNnOp   = ctypes.c_char_p(bytes(pGNnOp,   "utf-8"))
    pGNiOp   = ctypes.c_char_p(bytes(pGNiOp,   "utf-8"))
    vPartOp  = ctypes.c_char_p(bytes(vPartOp,  "utf-8"))
    CODIFOp  = ctypes.c_char_p(bytes(CODIFOp,  "utf-8"))
    qTempOp  = ctypes.c_char_p(bytes(qTempOp,  "utf-8"))
    UFCons   = ctypes.c_char_p(bytes(UFCons,   "utf-8"))
    pBioOp   = ctypes.c_char_p(bytes(pBioOp,   "utf-8"))

    return fn(nItem, cProdANP, descANP, pGLPOp, pGNnOp, pGNiOp, vPartOp, CODIFOp, qTempOp, UFCons, pBioOp)

def InformaCombustivelCIDE(nItem, qBCProd, vAliqProd, vCIDE):
    fn = ffi.InformaCombustivelCIDE

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    qBCProd   = ctypes.c_char_p(bytes(qBCProd,   "utf-8"))
    vAliqProd = ctypes.c_char_p(bytes(vAliqProd, "utf-8"))
    vCIDE     = ctypes.c_char_p(bytes(vCIDE,     "utf-8"))

    return fn(nItem, qBCProd, vAliqProd, vCIDE)

def InformaCombustivelEncerrante(nItem, nBico, nBombaOp, nTanque, vEncIni, vEncFin):
    fn = ffi.InformaCombustivelEncerrante

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    nBico    = ctypes.c_char_p(bytes(nBico,    "utf-8"))
    nBombaOp = ctypes.c_char_p(bytes(nBombaOp, "utf-8"))
    nTanque  = ctypes.c_char_p(bytes(nTanque,  "utf-8"))
    vEncIni  = ctypes.c_char_p(bytes(vEncIni,  "utf-8"))
    vEncFin  = ctypes.c_char_p(bytes(vEncFin,  "utf-8"))

    return fn(nItem, nBico, nBombaOp, nTanque, vEncIni, vEncFin)

def InformaCombustivelOrigem(nItem, indImport, cUFOrig, pOrig):
    fn = ffi.InformaCombustivelOrigem

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    cUFOrig = ctypes.c_char_p(bytes(cUFOrig, "utf-8"))
    pOrig   = ctypes.c_char_p(bytes(pOrig,   "utf-8"))

    return fn(nItem, indImport, cUFOrig, pOrig)

def InformaICMS02(nItem, orig, CST, qBCMonoOp, adRemICMS, vICMSMono):
    fn = ffi.InformaICMS02

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST       = ctypes.c_char_p(bytes(CST,       "utf-8"))
    qBCMonoOp = ctypes.c_char_p(bytes(qBCMonoOp, "utf-8"))
    adRemICMS = ctypes.c_char_p(bytes(adRemICMS, "utf-8"))
    vICMSMono = ctypes.c_char_p(bytes(vICMSMono, "utf-8"))

    return fn(nItem, orig, CST, qBCMonoOp, adRemICMS, vICMSMono)

def InformaICMS15(nItem, orig, CST, qBCMonoOp, adRemICMS, vICMSMono, qBCMonoRetenOp, adRemICMSReten, vICMSMonoReten, pRedAdRem_a, motRedAdRem_a):
    fn = ffi.InformaICMS15

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    qBCMonoOp        = ctypes.c_char_p(bytes(qBCMonoOp,        "utf-8"))
    adRemICMS        = ctypes.c_char_p(bytes(adRemICMS,        "utf-8"))
    vICMSMono        = ctypes.c_char_p(bytes(vICMSMono,        "utf-8"))
    qBCMonoRetenOp   = ctypes.c_char_p(bytes(qBCMonoRetenOp,   "utf-8"))
    adRemICMSReten   = ctypes.c_char_p(bytes(adRemICMSReten,   "utf-8"))
    vICMSMonoReten   = ctypes.c_char_p(bytes(vICMSMonoReten,   "utf-8"))
    pRedAdRem_a      = ctypes.c_char_p(bytes(pRedAdRem_a,      "utf-8"))

    return fn(nItem, orig, CST, qBCMonoOp, adRemICMS, vICMSMono, qBCMonoRetenOp, adRemICMSReten, vICMSMonoReten, pRedAdRem_a, motRedAdRem_a)

def InformaICMS53(nItem, orig, CST, qBCMonoOp, adRemICMSOp, vICMSMonoOperOp, pDifOp, vICMSMonoDifOp, vICMSMonoOp):
    fn = ffi.InformaICMS53

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST              = ctypes.c_char_p(bytes(CST,              "utf-8"))
    qBCMonoOp        = ctypes.c_char_p(bytes(qBCMonoOp,        "utf-8"))
    adRemICMSOp      = ctypes.c_char_p(bytes(adRemICMSOp,      "utf-8"))
    vICMSMonoOperOp  = ctypes.c_char_p(bytes(vICMSMonoOperOp,  "utf-8"))
    pDifOp           = ctypes.c_char_p(bytes(pDifOp,           "utf-8"))
    vICMSMonoDifOp   = ctypes.c_char_p(bytes(vICMSMonoDifOp,   "utf-8"))
    vICMSMonoOp      = ctypes.c_char_p(bytes(vICMSMonoOp,      "utf-8"))

    return fn(nItem, orig, CST, qBCMonoOp, adRemICMSOp, vICMSMonoOperOp, pDifOp, vICMSMonoDifOp, vICMSMonoOp)

def InformaICMS61(nItem, orig, CST, qBCMonoRetOp, adRemICMSRet, vICMSMonoRet):
    fn = ffi.InformaICMS61

    fn.restype = ctypes.c_int
    fn.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    CST           = ctypes.c_char_p(bytes(CST,           "utf-8"))
    qBCMonoRetOp  = ctypes.c_char_p(bytes(qBCMonoRetOp,  "utf-8"))
    adRemICMSRet  = ctypes.c_char_p(bytes(adRemICMSRet,  "utf-8"))
    vICMSMonoRet  = ctypes.c_char_p(bytes(vICMSMonoRet,  "utf-8"))

    return fn(nItem, orig, CST, qBCMonoRetOp, adRemICMSRet, vICMSMonoRet)

def CartaDeCorrecao(chCFe, xCorrecao):
    fn = ffi.CartaDeCorrecao

    fn.restype = ctypes.c_char_p
    fn.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p
    ]

    chCFe     = ctypes.c_char_p(bytes(chCFe,     "utf-8"))
    xCorrecao = ctypes.c_char_p(bytes(xCorrecao, "utf-8"))

    return fn(chCFe, xCorrecao).decode("utf-8")
    
def InformaDocumentoReferenciadoNFe(refNFeEx, refNFeSigEx):
    fn = ffi.InformaDocumentoReferenciadoNFe
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    refNFeEx = ctypes.c_char_p(bytes(refNFeEx, "utf-8"))
    refNFeSigEx = ctypes.c_char_p(bytes(refNFeSigEx, "utf-8"))
    return fn(refNFeEx, refNFeSigEx)

def InformaDocumentoReferenciadoNF(cUF, AAMM, CNPJ, mod, serie, nNF):
    fn = ffi.InformaDocumentoReferenciadoNF
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    cUF = ctypes.c_char_p(bytes(cUF, "utf-8"))
    AAMM = ctypes.c_char_p(bytes(AAMM, "utf-8"))
    CNPJ = ctypes.c_char_p(bytes(CNPJ, "utf-8"))
    mod = ctypes.c_char_p(bytes(mod, "utf-8"))
    serie = ctypes.c_char_p(bytes(serie, "utf-8"))
    nNF = ctypes.c_char_p(bytes(nNF, "utf-8"))
    return fn(cUF, AAMM, CNPJ, mod, serie, nNF)

def InformaDocumentoReferenciadoNFP(cUF, AAMM, CNPJEx, CPFEx, IE, mod, serie, nNF):
    fn = ffi.InformaDocumentoReferenciadoNFP
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    cUF = ctypes.c_char_p(bytes(cUF, "utf-8"))
    AAMM = ctypes.c_char_p(bytes(AAMM, "utf-8"))
    CNPJEx = ctypes.c_char_p(bytes(CNPJEx, "utf-8"))
    CPFEx = ctypes.c_char_p(bytes(CPFEx, "utf-8"))
    IE = ctypes.c_char_p(bytes(IE, "utf-8"))
    mod = ctypes.c_char_p(bytes(mod, "utf-8"))
    serie = ctypes.c_char_p(bytes(serie, "utf-8"))
    nNF = ctypes.c_char_p(bytes(nNF, "utf-8"))
    return fn(cUF, AAMM, CNPJEx, CPFEx, IE, mod, serie, nNF)

def InformaDocumentoReferenciadoCTe(refCTeEx):
    fn = ffi.InformaDocumentoReferenciadoCTe
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p]
    refCTeEx = ctypes.c_char_p(bytes(refCTeEx, "utf-8"))
    return fn(refCTeEx)

def InformaDocumentoReferenciadoECF(mod, nECF, nCOO):
    fn = ffi.InformaDocumentoReferenciadoECF
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    mod = ctypes.c_char_p(bytes(mod, "utf-8"))
    nECF = ctypes.c_char_p(bytes(nECF, "utf-8"))
    nCOO = ctypes.c_char_p(bytes(nCOO, "utf-8"))
    return fn(mod, nECF, nCOO)

def InformaInformacoesAdicionaisProduto(nItem, infAdProd):
    fn = ffi.InformaInformacoesAdicionaisProduto
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p]
    infAdProd = ctypes.c_char_p(bytes(infAdProd, "utf-8"))
    return fn(nItem, infAdProd)

def InformaDeclaracaoImportacao(nItem, nDI, dDI, xLocDesemb, UFDesemb, dDesemb, tpViaTransp, vAFRMMOp, tpIntermedio, CNPJEx, CPFEx, UFTerceiroOp, cExportador):
    fn = ffi.InformaDeclaracaoImportacao
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    nDI = ctypes.c_char_p(bytes(nDI, "utf-8"))
    dDI = ctypes.c_char_p(bytes(dDI, "utf-8"))
    xLocDesemb = ctypes.c_char_p(bytes(xLocDesemb, "utf-8"))
    UFDesemb = ctypes.c_char_p(bytes(UFDesemb, "utf-8"))
    dDesemb = ctypes.c_char_p(bytes(dDesemb, "utf-8"))
    vAFRMMOp = ctypes.c_char_p(bytes(vAFRMMOp, "utf-8"))
    CNPJEx = ctypes.c_char_p(bytes(CNPJEx, "utf-8"))
    CPFEx = ctypes.c_char_p(bytes(CPFEx, "utf-8"))
    UFTerceiroOp = ctypes.c_char_p(bytes(UFTerceiroOp, "utf-8"))
    cExportador = ctypes.c_char_p(bytes(cExportador, "utf-8"))
    return fn(nItem, nDI, dDI, xLocDesemb, UFDesemb, dDesemb, tpViaTransp, vAFRMMOp, tpIntermedio, CNPJEx, CPFEx, UFTerceiroOp, cExportador)

def InformaAdicaoDeclaracaoImportacao(nItem, nDI, nAdicaoOp, nSeqAdic, cFabricante, vDescDIOp, nDrawOp):
    fn = ffi.InformaAdicaoDeclaracaoImportacao
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    nAdicaoOp = ctypes.c_char_p(bytes(nAdicaoOp, "utf-8"))
    nSeqAdic = ctypes.c_char_p(bytes(nSeqAdic, "utf-8"))
    cFabricante = ctypes.c_char_p(bytes(cFabricante, "utf-8"))
    vDescDIOp = ctypes.c_char_p(bytes(vDescDIOp, "utf-8"))
    nDrawOp = ctypes.c_char_p(bytes(nDrawOp, "utf-8"))
    return fn(nItem, nDI, nAdicaoOp, nSeqAdic, cFabricante, vDescDIOp, nDrawOp)

def InformaDetalhamentoExportacao(nItem, nDrawOp):
    fn = ffi.InformaDetalhamentoExportacao
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p]
    nDrawOp = ctypes.c_char_p(bytes(nDrawOp, "utf-8"))
    return fn(nItem, nDrawOp)

def InformaRastreabilidade(nItem, nLote, qLote, dFab, dVal, cAgregOp):
    fn = ffi.InformaRastreabilidade
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    nLote = ctypes.c_char_p(bytes(nLote, "utf-8"))
    qLote = ctypes.c_char_p(bytes(qLote, "utf-8"))
    dFab = ctypes.c_char_p(bytes(dFab, "utf-8"))
    dVal = ctypes.c_char_p(bytes(dVal, "utf-8"))
    cAgregOp = ctypes.c_char_p(bytes(cAgregOp, "utf-8"))
    return fn(nItem, nLote, qLote, dFab, dVal, cAgregOp)

def InformaVeiculoNovo(nItem, tpOp, chassi, cCor, xCor, pot, cilin, pesoL, pesoB, nSerie, tpComb, nMotor, CMT, dist, anoMod, anoFab, tpPint, tpVeic, espVeic, VIN, condVeic, cMod, cCorDENATRAN, lota, tpRest):
    fn = ffi.InformaVeiculoNovo
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
    chassi = ctypes.c_char_p(bytes(chassi, "utf-8"))
    cCor = ctypes.c_char_p(bytes(cCor, "utf-8"))
    xCor = ctypes.c_char_p(bytes(xCor, "utf-8"))
    pot = ctypes.c_char_p(bytes(pot, "utf-8"))
    cilin = ctypes.c_char_p(bytes(cilin, "utf-8"))
    pesoL = ctypes.c_char_p(bytes(pesoL, "utf-8"))
    pesoB = ctypes.c_char_p(bytes(pesoB, "utf-8"))
    nSerie = ctypes.c_char_p(bytes(nSerie, "utf-8"))
    tpComb = ctypes.c_char_p(bytes(tpComb, "utf-8"))
    nMotor = ctypes.c_char_p(bytes(nMotor, "utf-8"))
    CMT = ctypes.c_char_p(bytes(CMT, "utf-8"))
    dist = ctypes.c_char_p(bytes(dist, "utf-8"))
    anoMod = ctypes.c_char_p(bytes(anoMod, "utf-8"))
    anoFab = ctypes.c_char_p(bytes(anoFab, "utf-8"))
    tpPint = ctypes.c_char_p(bytes(tpPint, "utf-8"))
    tpVeic = ctypes.c_char_p(bytes(tpVeic, "utf-8"))
    VIN = ctypes.c_char_p(bytes(VIN, "utf-8"))
    cMod = ctypes.c_char_p(bytes(cMod, "utf-8"))
    cCorDENATRAN = ctypes.c_char_p(bytes(cCorDENATRAN, "utf-8"))
    lota = ctypes.c_char_p(bytes(lota, "utf-8"))
    return fn(nItem, tpOp, chassi, cCor, xCor, pot, cilin, pesoL, pesoB, nSerie, tpComb, nMotor, CMT, dist, anoMod, anoFab, tpPint, tpVeic, espVeic, VIN, condVeic, cMod, cCorDENATRAN, lota, tpRest)

def InformaMedicamento(nItem, cProdANVISA, xMotivoIsencaoOp, vPMC):
    fn = ffi.InformaMedicamento
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    cProdANVISA = ctypes.c_char_p(bytes(cProdANVISA, "utf-8"))
    xMotivoIsencaoOp = ctypes.c_char_p(bytes(xMotivoIsencaoOp, "utf-8"))
    vPMC = ctypes.c_char_p(bytes(vPMC, "utf-8"))
    return fn(nItem, cProdANVISA, xMotivoIsencaoOp, vPMC)

def InformaArmamento(nItem, tpArma, nSerie, nCano, descr):
    fn = ffi.InformaArmamento
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    nSerie = ctypes.c_char_p(bytes(nSerie, "utf-8"))
    nCano = ctypes.c_char_p(bytes(nCano, "utf-8"))
    descr = ctypes.c_char_p(bytes(descr, "utf-8"))
    return fn(nItem, tpArma, nSerie, nCano, descr)

def InformaIPIDevolvido(nItem, pDevol, vIPIDevol):
    fn = ffi.InformaIPIDevolvido
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p]
    pDevol = ctypes.c_char_p(bytes(pDevol, "utf-8"))
    vIPIDevol = ctypes.c_char_p(bytes(vIPIDevol, "utf-8"))
    return fn(nItem, pDevol, vIPIDevol)

def InformaObservacaoContribuinteItem(nItem, xCampo, xTexto):
    fn = ffi.InformaObservacaoContribuinteItem
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p]
    xCampo = ctypes.c_char_p(bytes(xCampo, "utf-8"))
    xTexto = ctypes.c_char_p(bytes(xTexto, "utf-8"))
    return fn(nItem, xCampo, xTexto)

def InformaObservacaoFiscoItem(nItem, xCampo, xTexto):
    fn = ffi.InformaObservacaoFiscoItem
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p]
    xCampo = ctypes.c_char_p(bytes(xCampo, "utf-8"))
    xTexto = ctypes.c_char_p(bytes(xTexto, "utf-8"))
    return fn(nItem, xCampo, xTexto)

def InformaTransporte(modFrete, vagaoEx, balsaEx):
    fn = ffi.InformaTransporte
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p]
    vagaoEx = ctypes.c_char_p(bytes(vagaoEx, "utf-8"))
    balsaEx = ctypes.c_char_p(bytes(balsaEx, "utf-8"))
    return fn(modFrete, vagaoEx, balsaEx)

def InformaTransportador(CNPJEx, CPFEx, xNomeOp, IEOp, xEnderOp, xMunOp, UFOp):
    fn = ffi.InformaTransportador
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    CNPJEx = ctypes.c_char_p(bytes(CNPJEx, "utf-8"))
    CPFEx = ctypes.c_char_p(bytes(CPFEx, "utf-8"))
    xNomeOp = ctypes.c_char_p(bytes(xNomeOp, "utf-8"))
    IEOp = ctypes.c_char_p(bytes(IEOp, "utf-8"))
    xEnderOp = ctypes.c_char_p(bytes(xEnderOp, "utf-8"))
    xMunOp = ctypes.c_char_p(bytes(xMunOp, "utf-8"))
    UFOp = ctypes.c_char_p(bytes(UFOp, "utf-8"))
    return fn(CNPJEx, CPFEx, xNomeOp, IEOp, xEnderOp, xMunOp, UFOp)

def InformaRetencaoTransporte(vServ, vBCRet, pICMSRet, vICMSRet, CFOP, cMunFG):
    fn = ffi.InformaRetencaoTransporte
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    vServ = ctypes.c_char_p(bytes(vServ, "utf-8"))
    vBCRet = ctypes.c_char_p(bytes(vBCRet, "utf-8"))
    pICMSRet = ctypes.c_char_p(bytes(pICMSRet, "utf-8"))
    vICMSRet = ctypes.c_char_p(bytes(vICMSRet, "utf-8"))
    CFOP = ctypes.c_char_p(bytes(CFOP, "utf-8"))
    cMunFG = ctypes.c_char_p(bytes(cMunFG, "utf-8"))
    return fn(vServ, vBCRet, pICMSRet, vICMSRet, CFOP, cMunFG)

def InformaVeiculoTransporte(placa, UF, RNTCOp):
    fn = ffi.InformaVeiculoTransporte
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    placa = ctypes.c_char_p(bytes(placa, "utf-8"))
    UF = ctypes.c_char_p(bytes(UF, "utf-8"))
    RNTCOp = ctypes.c_char_p(bytes(RNTCOp, "utf-8"))
    return fn(placa, UF, RNTCOp)

def InformaReboque(placa, UF, RNTCOp):
    fn = ffi.InformaReboque
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    placa = ctypes.c_char_p(bytes(placa, "utf-8"))
    UF = ctypes.c_char_p(bytes(UF, "utf-8"))
    RNTCOp = ctypes.c_char_p(bytes(RNTCOp, "utf-8"))
    return fn(placa, UF, RNTCOp)

def InformaVolume(qVolOp, espOp, marcaOp, nVolOp, pesoLOp, pesoBOp):
    fn = ffi.InformaVolume
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    qVolOp = ctypes.c_char_p(bytes(qVolOp, "utf-8"))
    espOp = ctypes.c_char_p(bytes(espOp, "utf-8"))
    marcaOp = ctypes.c_char_p(bytes(marcaOp, "utf-8"))
    nVolOp = ctypes.c_char_p(bytes(nVolOp, "utf-8"))
    pesoLOp = ctypes.c_char_p(bytes(pesoLOp, "utf-8"))
    pesoBOp = ctypes.c_char_p(bytes(pesoBOp, "utf-8"))
    return fn(qVolOp, espOp, marcaOp, nVolOp, pesoLOp, pesoBOp)

def InformaLacre(nVolume, nLacre):
    fn = ffi.InformaLacre
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p]
    nLacre = ctypes.c_char_p(bytes(nLacre, "utf-8"))
    return fn(nVolume, nLacre)

def InformaFatura(nFatOp, vOrigOp, vDescOp, vLiqOp):
    fn = ffi.InformaFatura
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    nFatOp = ctypes.c_char_p(bytes(nFatOp, "utf-8"))
    vOrigOp = ctypes.c_char_p(bytes(vOrigOp, "utf-8"))
    vDescOp = ctypes.c_char_p(bytes(vDescOp, "utf-8"))
    vLiqOp = ctypes.c_char_p(bytes(vLiqOp, "utf-8"))
    return fn(nFatOp, vOrigOp, vDescOp, vLiqOp)

def InformaParcela(nDupOp, dVencOp, vDup):
    fn = ffi.InformaParcela
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    nDupOp = ctypes.c_char_p(bytes(nDupOp, "utf-8"))
    dVencOp = ctypes.c_char_p(bytes(dVencOp, "utf-8"))
    vDup = ctypes.c_char_p(bytes(vDup, "utf-8"))
    return fn(nDupOp, dVencOp, vDup)

def InformaIntermediador(CNPJ, idCadIntTran):
    fn = ffi.InformaIntermediador
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    CNPJ = ctypes.c_char_p(bytes(CNPJ, "utf-8"))
    idCadIntTran = ctypes.c_char_p(bytes(idCadIntTran, "utf-8"))
    return fn(CNPJ, idCadIntTran)

def InformaExportacao(UFSaidaPais, xLocExporta, xLocDespachoOp):
    fn = ffi.InformaExportacao
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    UFSaidaPais = ctypes.c_char_p(bytes(UFSaidaPais, "utf-8"))
    xLocExporta = ctypes.c_char_p(bytes(xLocExporta, "utf-8"))
    xLocDespachoOp = ctypes.c_char_p(bytes(xLocDespachoOp, "utf-8"))
    return fn(UFSaidaPais, xLocExporta, xLocDespachoOp)

def InformaCompra(xNEmpOp, xPedOp, xContOp):
    fn = ffi.InformaCompra
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    xNEmpOp = ctypes.c_char_p(bytes(xNEmpOp, "utf-8"))
    xPedOp = ctypes.c_char_p(bytes(xPedOp, "utf-8"))
    xContOp = ctypes.c_char_p(bytes(xContOp, "utf-8"))
    return fn(xNEmpOp, xPedOp, xContOp)

def InformaCana(safra, ref, qTotMes, qTotAnt, qTotGer, vFor, vTotDed, vLiqFor):
    fn = ffi.InformaCana
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    safra = ctypes.c_char_p(bytes(safra, "utf-8"))
    ref = ctypes.c_char_p(bytes(ref, "utf-8"))
    qTotMes = ctypes.c_char_p(bytes(qTotMes, "utf-8"))
    qTotAnt = ctypes.c_char_p(bytes(qTotAnt, "utf-8"))
    qTotGer = ctypes.c_char_p(bytes(qTotGer, "utf-8"))
    vFor = ctypes.c_char_p(bytes(vFor, "utf-8"))
    vTotDed = ctypes.c_char_p(bytes(vTotDed, "utf-8"))
    vLiqFor = ctypes.c_char_p(bytes(vLiqFor, "utf-8"))
    return fn(safra, ref, qTotMes, qTotAnt, qTotGer, vFor, vTotDed, vLiqFor)

def InformaFornecimentoDiarioCana(dia, qtde):
    fn = ffi.InformaFornecimentoDiarioCana
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    dia = ctypes.c_char_p(bytes(dia, "utf-8"))
    qtde = ctypes.c_char_p(bytes(qtde, "utf-8"))
    return fn(dia, qtde)

def InformaDeducaoCana(xDed, vDed):
    fn = ffi.InformaDeducaoCana
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    xDed = ctypes.c_char_p(bytes(xDed, "utf-8"))
    vDed = ctypes.c_char_p(bytes(vDed, "utf-8"))
    return fn(xDed, vDed)

def InformaResponsavelTecnico(CNPJ, xContato, email, fone, idCSRT_a, hashCSRT_a):
    fn = ffi.InformaResponsavelTecnico
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    CNPJ = ctypes.c_char_p(bytes(CNPJ, "utf-8"))
    xContato = ctypes.c_char_p(bytes(xContato, "utf-8"))
    email = ctypes.c_char_p(bytes(email, "utf-8"))
    fone = ctypes.c_char_p(bytes(fone, "utf-8"))
    idCSRT_a = ctypes.c_char_p(bytes(idCSRT_a, "utf-8"))
    hashCSRT_a = ctypes.c_char_p(bytes(hashCSRT_a, "utf-8"))
    return fn(CNPJ, xContato, email, fone, idCSRT_a, hashCSRT_a)

def InformaInformacoesSuplementares(qrCode, urlChave):
    fn = ffi.InformaInformacoesSuplementares
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    qrCode = ctypes.c_char_p(bytes(qrCode, "utf-8"))
    urlChave = ctypes.c_char_p(bytes(urlChave, "utf-8"))
    return fn(qrCode, urlChave)

if platform.system() == "Windows":
    ffimp = ctypes.WinDLL("./E1_Impressora01.dll")
else:
    ffimp = ctypes.cdll.LoadLibrary("./libE1_Impressora.so")
    
def AbreConexaoImpressora(tipo, modelo, conexao, param):
    fn = ffimp.AbreConexaoImpressora
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]

    modelo = ctypes.c_char_p(bytes(modelo, "utf-8"))
    conexao = ctypes.c_char_p(bytes(conexao, "utf-8"))

    return fn(tipo, modelo, conexao, param)


def FechaConexaoImpressora():
    fn = ffimp.FechaConexaoImpressora
    fn.restype = ctypes.c_int
    fn.argtypes = []

    return fn()
    
def Corte(avanco):
    fn = ffimp.Corte
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int]

    return fn(avanco)
    
def ImprimeXMLNFCe(dados, indexcsc, csc, param):
    fn = ffimp.ImprimeXMLNFCe
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]

    dados = ctypes.c_char_p(bytes(dados, "utf-8"))
    csc = ctypes.c_char_p(bytes(csc, "utf-8"))

    return fn(dados, indexcsc, csc, param)    
    
def ImprimeXMLCancelamentoNFCe(dados, param):
    fn = ffimp.ImprimeXMLCancelamentoNFCe
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_char_p, ctypes.c_int]

    dados = ctypes.c_char_p(bytes(dados, "utf-8"))

    return fn(dados, param)
