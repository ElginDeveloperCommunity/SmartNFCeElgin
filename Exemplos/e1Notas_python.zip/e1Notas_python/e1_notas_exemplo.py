import ctypes
import configparser
import base64
import json
import os

# Import the e1_notas library
import e1_notas

def deseja_gravar_xml():
    """Pergunta ao usuário se deseja salvar o XML."""
    resposta = input('Deseja salvar o XML? (S/N): ')
    return resposta.upper() == 'S'

def salvar_xml_retorno(json_retorno_str):
    """Salva o XML de retorno em um arquivo."""
    if not json_retorno_str:
        print('Retorno vazio, não é possível salvar o XML.')
        return
    
    try:
        # Parse do JSON
        json_retorno = json.loads(json_retorno_str)
        status = json_retorno.get('status', 0)
        print(f'Status do retorno: {status}')
        
        if status != 200:
            print('Erro na operação. XML não disponível para salvamento.')
            motivo = json_retorno.get('motivo', '')
            if motivo:
                print(f'Motivo: {motivo}')
            return
            
        if not deseja_gravar_xml():
            print('Operação de salvamento do XML cancelada pelo usuário.')
            return
            
        body_str = json_retorno.get('body', '')
        if not body_str:
            print('Corpo da resposta vazio.')
            return
            
        body = json.loads(body_str)
        xml_base64 = body.get('data', '')
        ch_nfe = body.get('chNFe', '')
        
        if not xml_base64 or not ch_nfe:
            print('Dados insuficientes para salvar o XML.')
            return
            
        # Decodifica o base64
        xml_bytes = base64.b64decode(xml_base64)
        
        # Salva o arquivo
        xml_filename = f'{ch_nfe}.xml'
        with open(xml_filename, 'wb') as f:
            f.write(xml_bytes)
        print(f'XML salvo como: {xml_filename}')
        
    except Exception as e:
        print(f'Erro ao salvar XML: {e}')

def emitir_nfce():
    """Emite uma NFCe."""
    # Carrega o arquivo INI
    if not os.path.exists('dados.ini'):
        print('Arquivo dados.ini não encontrado!')
        return
        
    config = configparser.ConfigParser()
    config.read('dados.ini')
    
    try:
        ret = e1_notas.AbreCupomVenda('12345678901234567890123456789012345678901234')
        print(f'Retorno AbreCupomVenda: {ret}')

        codigo_municipio = config.get('IDENTIFICACAO', 'CodigoMunicipio', fallback='')
        cuf = config.get('IDENTIFICACAO', 'cUF', fallback='')
        ret = e1_notas.InformaIdentificacao(
            cUF=cuf,
            cNF="",
            natOp="venda",
            mod=65,  # NFCe
            serie="",
            nNF="",
            dhEmi="",
            dhSaiEnt="",
            tpNF=1,
            idDest=1,
            cMunFG=codigo_municipio,
            tpImp=5,  # DANFE NFC-e em mensagem eletrônica
            tpEmis=0,
            cDV=0,
            tpAmb=0,  # 0 para ambiente de homologação, 1 para produção
            finNFe=1,
            indFinal=1,
            indPres=1,
            indIntermed=0,
            procEmi=0,
            verProc="",
            dhCont="",
            xJust=""
        )
        print(f'Retorno InformaIdentificacao: {ret}')

        # Lê todos os valores do INI
        cnpj = config.get('EMITENTE', 'CNPJ', fallback='')
        ie = config.get('EMITENTE', 'IE', fallback='')
        razao_social = config.get('EMITENTE', 'RazaoSocial', fallback='')
        nome_fantasia = config.get('EMITENTE', 'NomeFantasia', fallback='')
        logradouro = config.get('EMITENTE', 'Logradouro', fallback='')
        numero = config.get('EMITENTE', 'Numero', fallback='')
        complemento = config.get('EMITENTE', 'Complemento', fallback='')
        bairro = config.get('EMITENTE', 'Bairro', fallback='')
        cod_municipio = config.get('EMITENTE', 'CodigoMunicipio', fallback='')
        municipio = config.get('EMITENTE', 'Municipio', fallback='')
        uf = config.get('EMITENTE', 'UF', fallback='')
        cep = config.get('EMITENTE', 'CEP', fallback='')
        codigo_pais = config.get('EMITENTE', 'CodigoPais', fallback='')
        pais = config.get('EMITENTE', 'Pais', fallback='')
        fone = config.get('EMITENTE', 'Fone', fallback='')
        im = config.get('EMITENTE', 'IM', fallback='')
        cnae = config.get('EMITENTE', 'CNAE', fallback='')
        crt = config.getint('EMITENTE', 'CRT', fallback=1)

        ret = e1_notas.InformaEmitente(
            cnpj, "", razao_social, nome_fantasia,
            logradouro, numero, complemento, bairro,
            cod_municipio, municipio, uf, cep,
            codigo_pais, pais, fone, ie, "",
            im, cnae, crt
        )
        
        print(f'Retorno InformaEmitente: {ret}')

        # Produto e impostos (exemplo fixo)
        ret = e1_notas.InformaProduto(
            '123', 'SEM GTIN', 'NFCe - Homologacao', '22030000', '', '0302100', 'S', '', '', '', '5102', 'UN',
            '1.0000', '1.00', '', 'SEM GTIN', 'UN', '1.0000', '1.00', '', '', '', '', 1
        )
        print(f'Retorno InformaProduto: {ret}')

        ret = e1_notas.InformaICMSSN102(1, 0, '102')
        print(f'Retorno InformaICMSSN102: {ret}')

        #ret = e1_notas.InformaPISAliq(1, '99', '1.00', '1.65', '0.02')
        #print(f'Retorno InformaPISAliq: {ret}')

        #ret = e1_notas.InformaCOFINSAliq(1, '01', '1.00', '7.60', '0.08')
        #print(f'Retorno InformaCOFINSAliq: {ret}')

        ret = e1_notas.InformaPagamento(0, '01', '10000.00', 0, '', '', '')
        print(f'Retorno InformaPagamento: {ret}')

        ret = e1_notas.InformaValorTroco('0.00')
        print(f'Retorno InformaValorTroco: {ret}')

        ret = e1_notas.FechaCupomVenda('./venda_nfce.xml')
        print(f'Retorno FechaCupomVenda: {ret}')

        # Transmissão
        result_str = e1_notas.EmitirNota('./venda_nfce.xml')
        print(f'Retorno EmitirNota: {result_str}')
        
        salvar_xml_retorno(result_str)
        
    except Exception as e:
        print(f'Erro ao emitir NFCe: {e}')

def emitir_nfe():
    """Emite uma NFe."""
    # Carrega o arquivo INI
    if not os.path.exists('dados.ini'):
        print('Arquivo dados.ini não encontrado!')
        return
        
    config = configparser.ConfigParser()
    config.read('dados.ini')
    
    try:
        ret = e1_notas.AbreCupomVenda('12345678901234567890123456789012345678901234')
        print(f'Retorno AbreCupomVenda: {ret}')

        codigo_municipio = config.get('IDENTIFICACAO', 'CodigoMunicipio', fallback='')
        cuf = config.get('IDENTIFICACAO', 'cUF', fallback='')
        ret = e1_notas.InformaIdentificacao(
            cUF=cuf,
            cNF="",
            natOp="venda",
            mod=55,  # NFe
            serie="",
            nNF="",
            dhEmi="",
            dhSaiEnt="",
            tpNF=1,
            idDest=1,
            cMunFG=codigo_municipio,
            tpImp=0,  # Sem DANFE
            tpEmis=0,
            cDV=0,
            tpAmb=0,  # 0 para ambiente de homologação, 1 para produção
            finNFe=1,
            indFinal=1,
            indPres=1,
            indIntermed=0,
            procEmi=0,
            verProc="",
            dhCont="",
            xJust=""
        )
        print(f'Retorno InformaIdentificacao: {ret}')

        # Lê todos os valores do INI
        cnpj = config.get('EMITENTE', 'CNPJ', fallback='')
        ie = config.get('EMITENTE', 'IE', fallback='')
        razao_social = config.get('EMITENTE', 'RazaoSocial', fallback='')
        nome_fantasia = config.get('EMITENTE', 'NomeFantasia', fallback='')
        logradouro = config.get('EMITENTE', 'Logradouro', fallback='')
        numero = config.get('EMITENTE', 'Numero', fallback='')
        complemento = config.get('EMITENTE', 'Complemento', fallback='')
        bairro = config.get('EMITENTE', 'Bairro', fallback='')
        cod_municipio = config.get('EMITENTE', 'CodigoMunicipio', fallback='')
        municipio = config.get('EMITENTE', 'Municipio', fallback='')
        uf = config.get('EMITENTE', 'UF', fallback='')
        cep = config.get('EMITENTE', 'CEP', fallback='')
        codigo_pais = config.get('EMITENTE', 'CodigoPais', fallback='')
        pais = config.get('EMITENTE', 'Pais', fallback='')
        fone = config.get('EMITENTE', 'Fone', fallback='')
        im = config.get('EMITENTE', 'IM', fallback='')
        cnae = config.get('EMITENTE', 'CNAE', fallback='')
        crt = config.getint('EMITENTE', 'CRT', fallback=1)
        
        ret = e1_notas.InformaEmitente(
            cnpj, "", razao_social, nome_fantasia,
            logradouro, numero, complemento, bairro,
            cod_municipio, municipio, uf, cep,
            codigo_pais, pais, fone, ie, "",
            im, cnae, crt
        )
        
        print(f'Retorno InformaEmitente: {ret}')
        
        # Destinatário (exemplo fixo)
        ret = e1_notas.InformaDestinatario(
            '',                # CNPJ
            '45762835880',     # CPF
            '',                # idEstrangeiro
            'NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL', # xNome
            'Rua das Flores',  # xLgr
            '123',             # nro
            '',                # xCpl
            'Centro',          # xBairro
            '3550308',         # cMun
            'São Paulo',       # xMun
            'SP',              # UF
            '01001000',        # CEP
            '1058',            # cPais
            'Brasil',          # xPais
            '',                # fone
            9,                 # indIEDest
            '',                # IE
            '',                # ISUF
            '',                # IM
            ''                 # email
        )
        print(f'Retorno InformaDestinatario: {ret}')

        # Produto e impostos (exemplo fixo)
        ret = e1_notas.InformaProduto(
            '123', 'SEM GTIN', 'NFCe - Homologacao', '22030000', '', '0302100', 'S', '', '', '', '5102', 'UN',
            '1.0000', '1.00', '', 'SEM GTIN', 'UN', '1.0000', '1.00', '', '', '', '', 1
        )
        print(f'Retorno InformaProduto: {ret}')

        ret = e1_notas.InformaICMSSN102(1, 0, '102')
        print(f'Retorno InformaICMSSN102: {ret}')

        ret = e1_notas.InformaPISAliq(1, '99', '1.00', '1.65', '0.02')
        print(f'Retorno InformaPISAliq: {ret}')

        ret = e1_notas.InformaCOFINSAliq(1, '01', '1.00', '7.60', '0.08')
        print(f'Retorno InformaCOFINSAliq: {ret}')

        ret = e1_notas.InformaPagamento(0, '01', '10000.00', 0, '', '', '')
        print(f'Retorno InformaPagamento: {ret}')

        ret = e1_notas.InformaValorTroco('0.00')
        print(f'Retorno InformaValorTroco: {ret}')

        ret = e1_notas.FechaCupomVenda('./venda_nfe.xml')
        print(f'Retorno FechaCupomVenda: {ret}')

        # Transmissão
        result_str = e1_notas.EmitirNota('./venda_nfe.xml')
        print(f'Retorno EmitirNota: {result_str}')
        
        salvar_xml_retorno(result_str)
        
    except Exception as e:
        print(f'Erro ao emitir NFe: {e}')

def cancelar_nfce():
    """Cancela uma NFCe."""
    try:
        chave_nfce = input('Digite a chave da NFCe que deseja cancelar: ')
        protocolo = input('Digite o protocolo de autorização: ')
        justificativa = input('Digite a justificativa do cancelamento (mínimo 15 caracteres): ')
        
        if len(justificativa) < 15:
            print('A justificativa deve ter no mínimo 15 caracteres!')
            return
            
        result_str = e1_notas.CancelarNota(chave_nfce, protocolo, justificativa)
        print(f'Retorno CancelarNota: {result_str}')
        
    except Exception as e:
        print(f'Erro ao cancelar NFCe: {e}')

def gerar_pdf_nfce_personalizado():
    """Gera PDF personalizado de uma NFCe."""
    try:
        caminho_xml = input('Digite o caminho do arquivo XML da NFCe: ')
        
        if not os.path.exists(caminho_xml):
            print('Arquivo XML não encontrado!')
            return
            
        diretorio_saida = input('Digite o diretório de saída para o PDF (ou pressione ENTER para padrão): ')
        index_csc = int(input('Digite o índice do CSC: '))
        csc = input('Digite o CSC: ')
        layout = int(input('Digite o layout (0=Padrão, 1=Personalizado): '))
        parametro = int(input('Digite o parâmetro adicional: '))
        
        # Inicializar o módulo PDF
        ret = e1_notas.LoadPDF()
        print(f'Retorno LoadPDF: {ret}')
        
        if ret != 0:
            print('Erro ao inicializar o módulo PDF!')
            return
            
        try:
            # Configurar diretório de saída se especificado
            if diretorio_saida:
                result_str = e1_notas.ConfigurarDiretorioSaidaPDF(diretorio_saida)
                print(f'Retorno ConfigurarDiretorioSaidaPDF: {result_str}')
                
            # Gerar o PDF personalizado
            result_str = e1_notas.GerarDanfeNFCePersonalizadoPDF(caminho_xml, index_csc, csc, parametro)
            print(f'Retorno GerarDanfeNFCePersonalizadoPDF: {result_str}')
            
        finally:
            # Finalizar o módulo PDF
            ret = e1_notas.UnloadPDF()
            print(f'Retorno UnloadPDF: {ret}')
            
    except Exception as e:
        print(f'Erro ao gerar PDF NFCe: {e}')

def gerar_pdf_nfe_personalizado():
    """Gera PDF personalizado de uma NFe."""
    try:
        caminho_xml = input('Digite o caminho do arquivo XML da NFe: ')
        
        if not os.path.exists(caminho_xml):
            print('Arquivo XML não encontrado!')
            return
            
        caminho_logo = input('Digite o caminho do logo (ou pressione ENTER para não usar logo): ')
        
        # Verificar se o logo existe (se foi informado)
        if caminho_logo and not os.path.exists(caminho_logo):
            print('Arquivo de logo não encontrado! Continuando sem logo...')
            caminho_logo = ''
            
        layout = int(input('Digite o layout (0=Retrato, 1=Paisagem): '))
        parametro = int(input('Digite o parâmetro adicional: '))
        
        # Gerar o PDF personalizado da NFe
        result_str = e1_notas.GerarDanfeNFePersonalizadoPDF(caminho_xml, caminho_logo, layout, parametro)
        print(f'Retorno GerarDanfeNFePersonalizadoPDF: {result_str}')
        
    except Exception as e:
        print(f'Erro ao gerar PDF NFe: {e}')

def imprimir_nfce():
    """Imprime uma NFCe."""
    try:
        print('=== IMPRESSÃO DE NFCe ===')
        print('1 - Imprimir NFCe de Venda')
        print('2 - Imprimir NFCe de Cancelamento')
        tipo_operacao = int(input('Escolha o tipo de operação: '))
        
        if tipo_operacao not in [1, 2]:
            print('Opção inválida!')
            return
            
        # Solicitar o caminho do XML
        caminho_xml = input('Digite o caminho do arquivo XML da NFCe: ')
        
        if not os.path.exists(caminho_xml):
            print('Arquivo XML não encontrado!')
            return
            
        # Ler o conteúdo do arquivo XML
        try:
            with open(caminho_xml, 'r', encoding='utf-8') as f:
                xml_content = f.read()
        except Exception as e:
            print(f'Erro ao ler o arquivo XML: {e}')
            return
            
        # Configuração da impressora
        print('\n=== CONFIGURAÇÃO DA IMPRESSORA ===')
        print('Tipos de conexão:')
        print('1 - USB')
        print('2 - RS232')
        print('3 - TCP/IP')
        print('4 - Bluetooth')
        print('5 - Impressoras acopladas (Android)')
        tipo_impressora = int(input('Digite o tipo de conexão: '))
        
        if tipo_impressora not in range(1, 6):
            print('Tipo de impressora inválido!')
            return
            
        if tipo_impressora == 5:
            # Para impressoras acopladas (Android), modelo e conexão são vazios
            modelo = ''
            conexao = ''
            parametro = 0
        else:
            print('\nModelos disponíveis:')
            print('i7, i7 Plus, i8, i9, ix, Fitpos, BK-T681, MP-4200, MP-4200 HS, MP-2800')
            modelo = input('Digite o modelo da impressora: ')
            conexao = input('Digite a conexão (ex: USB, COM2, 192.168.0.20, AA:BB:CC:DD:EE:FF): ')
            
            if tipo_impressora == 1 or tipo_impressora == 4:
                parametro = 0  # USB e Bluetooth não precisam de parâmetro
            elif tipo_impressora == 2:
                parametro = int(input('Digite o baudrate para RS232: '))
            elif tipo_impressora == 3:
                parametro = int(input('Digite a porta TCP/IP: '))
                
        # Abrir conexão com a impressora
        print('\nAbrindo conexão com a impressora...')
        ret = e1_notas.AbreConexaoImpressora(tipo_impressora, modelo, conexao, parametro)
        print(f'Retorno AbreConexaoImpressora: {ret}')
        
        if ret != 0:
            print('Erro ao conectar com a impressora!')
            return
            
        try:
            # Imprimir conforme o tipo de operação
            if tipo_operacao == 1:
                # Impressão de NFCe de venda
                index_csc = int(input('Digite o índice do CSC: '))
                csc = input('Digite o CSC: ')
                parametro = int(input('Digite o parâmetro adicional (ou 0 para padrão): '))
                
                print('Imprimindo NFCe de venda...')
                ret = e1_notas.ImprimeXMLNFCe(xml_content, index_csc, csc, parametro)
                print(f'Retorno ImprimeXMLNFCe: {ret}')
            else:
                # Impressão de NFCe de cancelamento
                parametro = int(input('Digite o parâmetro adicional (ou 0 para padrão): '))
                
                print('Imprimindo NFCe de cancelamento...')
                ret = e1_notas.ImprimeXMLCancelamentoNFCe(xml_content, parametro)
                print(f'Retorno ImprimeXMLCancelamentoNFCe: {ret}')
                
            if ret == 0:
                print('Impressão realizada com sucesso!')
                
                # Realizar o corte do papel
                print('Realizando corte do papel...')
                ret = e1_notas.Corte(5)
                print(f'Retorno Corte: {ret}')
            else:
                print('Erro na impressão!')
                
        finally:
            # Fechar conexão com a impressora
            print('Fechando conexão com a impressora...')
            ret = e1_notas.FechaConexaoImpressora()
            print(f'Retorno FechaConexaoImpressora: {ret}')
            
    except Exception as e:
        print(f'Erro ao imprimir NFCe: {e}')

def exibir_menu():
    """Exibe o menu principal."""
    print('\n========================================')
    print('            MENU PRINCIPAL              ')
    print('========================================')
    print('1 - Emitir NFCe')
    print('2 - Emitir NFe')
    print('3 - Cancelar NFCe')
    print('4 - Gerar PDF NFCe Personalizado')
    print('5 - Gerar PDF NFe Personalizado')
    print('6 - Imprimir NFCe')
    print('7 - Sair')
    print('========================================')
    opcao = input('Escolha uma opção: ')
    return opcao

def main():
    """Função principal do programa."""
    while True:
        opcao = exibir_menu()
        print()
        
        if opcao == '1':
            print('=== EMISSÃO DE NFCe ===')
            emitir_nfce()
            print('=======================')
            input('Pressione ENTER para voltar ao menu...')
        elif opcao == '2':
            print('=== EMISSÃO DE NFe ===')
            emitir_nfe()
            print('=======================')
            input('Pressione ENTER para voltar ao menu...')
        elif opcao == '3':
            print('=== CANCELAMENTO DE NFCe ===')
            cancelar_nfce()
            print('===========================')
            input('Pressione ENTER para voltar ao menu...')
        elif opcao == '4':
            print('=== GERAÇÃO DE PDF NFCe PERSONALIZADO ===')
            gerar_pdf_nfce_personalizado()
            print('=========================================')
            input('Pressione ENTER para voltar ao menu...')
        elif opcao == '5':
            print('=== GERAÇÃO DE PDF NFe PERSONALIZADO ===')
            gerar_pdf_nfe_personalizado()
            print('========================================')
            input('Pressione ENTER para voltar ao menu...')
        elif opcao == '6':
            print('=== Imprimir NFCe ===')
            imprimir_nfce()
            print('========================================')
            input('Pressione ENTER para voltar ao menu...')
        elif opcao == '7':
            print('Saindo do programa...')
            break
        else:
            print('Opção inválida!')
            input('Pressione ENTER para voltar ao menu...')

if __name__ == '__main__':
    main()
