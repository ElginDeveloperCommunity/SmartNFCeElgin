import ctypes
import E1_NFCe

###
### CONSTROI XML NOTA
###

ret = E1_NFCe.AbreCupomVenda("12345678901234567890123456789012345678901234")
print("Retorno AbreCupomVenda: ", ret)

ret = E1_NFCe.InformaIdentificacao("35",          #UF
                                   "",            #cNF
                                   "venda",       #natOp
                                   65,             #mod
                                   "",            #serie
                                   "",            #nNF
                                   "",            #dhEmi
                                   "",            #dhSaiEnt
                                   0,             #tpNF
                                   0,             #idDest
                                   "3550308",            #cMunFG
                                   4,             #tpImp
                                   0,             #tpEmis
                                   0,             #cDV
                                   0,             #tpAmb
                                   0,             #finNFe
                                   1,             #indFinal
                                   1,             #indPres
                                   0,             #indIntermed
                                   0,             #procEmi
                                   "",            #verProc
                                   "",            #Data e Hora da entrada em contingência
                                   "")            #Justificativa da entrada em contingência

print("Retorno InformaIdentificacao: ", ret)


print("Retorno InformaIdentificacao: ", ret)
ret = E1_NFCe.InformaEmitente(
	                  "29720473000145", # CNPJ
                          "",               # CPF
                          "29.720.473 FERNANDA SERAFIM ABRANTES",               # Razão social
                          "29.720.473 FERNANDA SERAFIM ABRANTES",               # nome fantasia
                          "RUA JOAO JOSE DE QUEIROZ",               # logradouro
                          "111",               # número
                          "333",               # complemento
                          "xyz",               # bairro
                          "3550308",                # código do municipio
                          "SAO PAULO",               # nome municio
                          "SP",               # sigla uf
                          "03.679-000",               # CEP
                          "1058",                # codigo pais
                          "Brasil",               # nome do pais
                          "",               # telefone
                          "128237060114",               # IE
                          "",               # IEST
                          "",               # IM
                          "",               # CNAE
                          1)                # CRT

 
print("Retorno informaEmitente: ", ret)

for i in range(1):
    ret = E1_NFCe.InformaProduto("123",                 # cProd
                                 "SEM GTIN",            # cEAN
                                 "NFCe - Homologacão",  # xProd
                                 "22030000",            # NCM
                                 "",                    # NVE
                                 "0302100",             # CEST
                                 "S",                   # indEscala
                                 "",                    # CNPJFab
                                 "",                    # cBenef
                                 "",                    # EXTIPI
                                 "5102",                # CFOP
                                 "UN",                  # uCom
                                 "1.0000",              # qCo990
                                 "1.00",                # vUnCom
                                 "",                    # vProd
                                 "SEM GTIN",       # cEANTrib
                                 "UN",                  # uTrib
                                 "1.0000",              # qTrib
                                 "1.00",                # vUnTrib
                                 "",                    # vFrete
                                 "",                    # vSeg
                                 "",                    # vDesc
                                 "",                    # vOutro
                                 1)                     # indtot
    print("Retorno InformaProduto: ", ret)

    ret = E1_NFCe.InformaICMSSN102(i+1, 0, "102");
 
    print("Retorno InformaICMSSN102: ", ret)

    ret = E1_NFCe.InformaPISAliq(i+1,       # nItem
                                "99",      # CST
                                 "1.00",    # vBC
                                 "1.65",    # pPIS
                                 "0.02")    # vPIS
    print("Retorno InformaPISAliq: ", ret)


    

    ret = E1_NFCe.InformaCOFINSAliq(i+1,    # nItem
                                    "01",   # CST
                                    "1.00", # vBC
                                    "7.60", # pCofins
                                    "0.08") # vCofins
    print("Retorno InformaCOFINSAliq: ", ret)

ret = E1_NFCe.InformaPagamento(0,       # Indicador da Forma de pagamento
                               "01",    # Meio de pagamento
                               "10000.00",  # valor pago
                               0,       # Tipo integração
                               "",      # cnpj
                               "",    # bandeira
                               "")      # codigo aut
print("Retorno informaPagamento: ", ret)

ret = E1_NFCe.InformaValorTroco("0.00")
print("Retorno InformaValorTroco: ", ret)

ret = E1_NFCe.FechaCupomVenda("./venda_990.xml")
print("Retorno FechaCupomVenda: ", ret)

###
### TRANSMITE NOTA
###

result = E1_NFCe.EmitirNota("./venda_990.xml")
print("Retorno EmitirNota: ", result)
