#include <windows.h>
#include <string.h>

// Tipos de funções da DLL original
typedef char* (__cdecl *PFN_EmitirNota)(char*, char*);
typedef char* (__cdecl *PFN_ConsultarStatus)(char*);
typedef char* (__cdecl *PFN_ConsultarNota)(char*);
typedef char* (__cdecl *PFN_CancelarNota)(char*, char*, char*);
typedef char* (__cdecl *PFN_InutilizarNumeracao)(char*, char*, char*, char*, int, int, int, int);
typedef char* (__cdecl *PFN_ProcessamentoContingencia)();
typedef char* (__cdecl *PFN_CancelamentoPorSubstituicao)(char*, char*, char*, int);
typedef char* (__cdecl *PFN_CartaDeCorrecao)(char*, char*);
typedef int (__cdecl *PFN_AbreCupomVenda)(char*);
typedef int (__cdecl *PFN_InformaIdentificacao)(char*, char*, char*, int, char*, char*, char*, char*, int, int, char*, int, int, int, int, int, int, int, int, int, char*, char*, char*);
typedef int (__cdecl *PFN_InformaDocumentoReferenciadoNFe)(char*, char*);
typedef int (__cdecl *PFN_InformaDocumentoReferenciadoNF)(char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaDocumentoReferenciadoNFP)(char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaDocumentoReferenciadoCTe)(char*);
typedef int (__cdecl *PFN_InformaDocumentoReferenciadoECF)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaEmitente)(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, int);
typedef int (__cdecl *PFN_InformaAvulsa)(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaDestinatario)(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaRetirada)(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaEntrega)(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaAutorizacaoXML)(char*, char*);
typedef int (__cdecl *PFN_InformaProduto)(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, int);
typedef int (__cdecl *PFN_InformaInformacoesAdicionaisProduto)(int, char*);
typedef int (__cdecl *PFN_InformaDeclaracaoImportacao)(int, char*, char*, char*, char*, char*, int, char*, int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaAdicaoDeclaracaoImportacao)(int, int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaDetalhamentoExportacao)(int, char*);
typedef int (__cdecl *PFN_InformaRastreabilidade)(int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaVeiculoNovo)(int, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, int, char*, int, char*, char*, char*, int);
typedef int (__cdecl *PFN_InformaMedicamento)(int, char*, char*, char*);
typedef int (__cdecl *PFN_InformaArmamento)(int, int, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCombustivel)(int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCombustivelCIDE)(int, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCombustivelEncerrante)(int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCombustivelOrigem)(int, int, char*, char*);
typedef int (__cdecl *PFN_InformaValorTotalTributos)(int, char*);
typedef int (__cdecl *PFN_InformaICMS00)(int, int, char*, int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS02)(int, int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS10)(int, int, char*, int, char*, char*, char*, char*, char*, char*, int, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS15)(int, int, char*, char*, char*, char*, char*, char*, char*, char*, int);
typedef int (__cdecl *PFN_InformaICMS20)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, int, int);
typedef int (__cdecl *PFN_InformaICMS30)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, int, int);
typedef int (__cdecl *PFN_InformaICMS40)(int, int, char*, char*, int, int);
typedef int (__cdecl *PFN_InformaICMS51)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS53)(int, int, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS60)(int, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS61)(int, int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMS70)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, int, int);
typedef int (__cdecl *PFN_InformaICMS90)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, int, int);
typedef int (__cdecl *PFN_InformaICMSPart)(int, int, char*, int, char*, char*, char*, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSST)(int, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSSN101)(int, int, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSSN102)(int, int, char*);
typedef int (__cdecl *PFN_InformaICMSSN201)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSSN202)(int, int, char*, int, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSSN500)(int, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSSN900)(int, int, char*, int, char*, char*, char*, char*, int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaICMSUFDest)(int, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaIPITrib)(int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaIPINT)(int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaII)(int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaPISAliq)(int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaPISQtde)(int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaPISNT)(int, char*);
typedef int (__cdecl *PFN_InformaPISOutr)(int, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaPISST)(int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCOFINSAliq)(int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCOFINSQtde)(int, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCOFINSNT)(int, char*);
typedef int (__cdecl *PFN_InformaCOFINSOutr)(int, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaCOFINSST)(int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaISSQN)(int, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, int, char*, char*, char*, char*, int);
typedef int (__cdecl *PFN_InformaIPIDevolvido)(int, char*, char*);
typedef int (__cdecl *PFN_InformaObservacaoContribuinteItem)(int, char*, char*);
typedef int (__cdecl *PFN_InformaObservacaoFiscoItem)(int, char*, char*);
typedef int (__cdecl *PFN_InformaTransporte)(int, char*, char*);
typedef int (__cdecl *PFN_InformaTransportador)(char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaRetencaoTransporte)(char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaVeiculoTransporte)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaReboque)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaVolume)(char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaLacre)(int, char*);
typedef int (__cdecl *PFN_InformaFatura)(char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaParcela)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaInformacoesPagamento)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaPagamento)(int, char*, char*, char*, char*, int, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaIntermediador)(char*, char*);
typedef int (__cdecl *PFN_InformaInformacoesAdicionais)(char*, char*);
typedef int (__cdecl *PFN_InformaObservacoesContribuinte)(char*, char*);
typedef int (__cdecl *PFN_InformaObservacoesFisco)(char*, char*);
typedef int (__cdecl *PFN_InformaProcessoReferenciado)(char*, int, char*);
typedef int (__cdecl *PFN_InformaExportacao)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaCompra)(char*, char*, char*);
typedef int (__cdecl *PFN_InformaCana)(char*, char*, char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaFornecimentoDiarioCana)(char*, char*);
typedef int (__cdecl *PFN_InformaDeducaoCana)(char*, char*);
typedef int (__cdecl *PFN_InformaResponsavelTecnico)(char*, char*, char*, char*, char*, char*);
typedef int (__cdecl *PFN_InformaInformacoesSuplementares)(char*, char*);
typedef int (__cdecl *PFN_FechaCupomVenda)(char*);
typedef int (__cdecl *PFN_LoadPDF)();
typedef char* (__cdecl *PFN_ConfigurarDiretorioSaidaPDF)(char*);
typedef char* (__cdecl *PFN_GerarDanfeNFCePDF)(char*, int, char*);
typedef char* (__cdecl *PFN_GerarDanfeNFCePersonalizadoPDF)(char*, int, char*, int);
typedef char* (__cdecl *PFN_GerarDanfeNFePDF)(char*, char*);
typedef char* (__cdecl *PFN_GerarDanfeNFePersonalizadoPDF)(char*, char*, int, int);
typedef int (__cdecl *PFN_UnloadPDF)();

static HMODULE hDLL = NULL;

// Ponteiros para funções
static PFN_EmitirNota f_EmitirNota = NULL;
static PFN_ConsultarStatus f_ConsultarStatus = NULL;
static PFN_ConsultarNota f_ConsultarNota = NULL;
static PFN_CancelarNota f_CancelarNota = NULL;
static PFN_InutilizarNumeracao f_InutilizarNumeracao = NULL;
static PFN_ProcessamentoContingencia f_ProcessamentoContingencia = NULL;
static PFN_CancelamentoPorSubstituicao f_CancelamentoPorSubstituicao = NULL;
static PFN_CartaDeCorrecao f_CartaDeCorrecao = NULL;
static PFN_AbreCupomVenda f_AbreCupomVenda = NULL;
static PFN_InformaIdentificacao f_InformaIdentificacao = NULL;
static PFN_InformaDocumentoReferenciadoNFe f_InformaDocumentoReferenciadoNFe = NULL;
static PFN_InformaDocumentoReferenciadoNF f_InformaDocumentoReferenciadoNF = NULL;
static PFN_InformaDocumentoReferenciadoNFP f_InformaDocumentoReferenciadoNFP = NULL;
static PFN_InformaDocumentoReferenciadoCTe f_InformaDocumentoReferenciadoCTe = NULL;
static PFN_InformaDocumentoReferenciadoECF f_InformaDocumentoReferenciadoECF = NULL;
static PFN_InformaEmitente f_InformaEmitente = NULL;
static PFN_InformaAvulsa f_InformaAvulsa = NULL;
static PFN_InformaDestinatario f_InformaDestinatario = NULL;
static PFN_InformaRetirada f_InformaRetirada = NULL;
static PFN_InformaEntrega f_InformaEntrega = NULL;
static PFN_InformaAutorizacaoXML f_InformaAutorizacaoXML = NULL;
static PFN_InformaProduto f_InformaProduto = NULL;
static PFN_InformaInformacoesAdicionaisProduto f_InformaInformacoesAdicionaisProduto = NULL;
static PFN_InformaDeclaracaoImportacao f_InformaDeclaracaoImportacao = NULL;
static PFN_InformaAdicaoDeclaracaoImportacao f_InformaAdicaoDeclaracaoImportacao = NULL;
static PFN_InformaDetalhamentoExportacao f_InformaDetalhamentoExportacao = NULL;
static PFN_InformaRastreabilidade f_InformaRastreabilidade = NULL;
static PFN_InformaVeiculoNovo f_InformaVeiculoNovo = NULL;
static PFN_InformaMedicamento f_InformaMedicamento = NULL;
static PFN_InformaArmamento f_InformaArmamento = NULL;
static PFN_InformaCombustivel f_InformaCombustivel = NULL;
static PFN_InformaCombustivelCIDE f_InformaCombustivelCIDE = NULL;
static PFN_InformaCombustivelEncerrante f_InformaCombustivelEncerrante = NULL;
static PFN_InformaCombustivelOrigem f_InformaCombustivelOrigem = NULL;
static PFN_InformaValorTotalTributos f_InformaValorTotalTributos = NULL;
static PFN_InformaICMS00 f_InformaICMS00 = NULL;
static PFN_InformaICMS02 f_InformaICMS02 = NULL;
static PFN_InformaICMS10 f_InformaICMS10 = NULL;
static PFN_InformaICMS15 f_InformaICMS15 = NULL;
static PFN_InformaICMS20 f_InformaICMS20 = NULL;
static PFN_InformaICMS30 f_InformaICMS30 = NULL;
static PFN_InformaICMS40 f_InformaICMS40 = NULL;
static PFN_InformaICMS51 f_InformaICMS51 = NULL;
static PFN_InformaICMS53 f_InformaICMS53 = NULL;
static PFN_InformaICMS60 f_InformaICMS60 = NULL;
static PFN_InformaICMS61 f_InformaICMS61 = NULL;
static PFN_InformaICMS70 f_InformaICMS70 = NULL;
static PFN_InformaICMS90 f_InformaICMS90 = NULL;
static PFN_InformaICMSPart f_InformaICMSPart = NULL;
static PFN_InformaICMSST f_InformaICMSST = NULL;
static PFN_InformaICMSSN101 f_InformaICMSSN101 = NULL;
static PFN_InformaICMSSN102 f_InformaICMSSN102 = NULL;
static PFN_InformaICMSSN201 f_InformaICMSSN201 = NULL;
static PFN_InformaICMSSN202 f_InformaICMSSN202 = NULL;
static PFN_InformaICMSSN500 f_InformaICMSSN500 = NULL;
static PFN_InformaICMSSN900 f_InformaICMSSN900 = NULL;
static PFN_InformaICMSUFDest f_InformaICMSUFDest = NULL;
static PFN_InformaIPITrib f_InformaIPITrib = NULL;
static PFN_InformaIPINT f_InformaIPINT = NULL;
static PFN_InformaII f_InformaII = NULL;
static PFN_InformaPISAliq f_InformaPISAliq = NULL;
static PFN_InformaPISQtde f_InformaPISQtde = NULL;
static PFN_InformaPISNT f_InformaPISNT = NULL;
static PFN_InformaPISOutr f_InformaPISOutr = NULL;
static PFN_InformaPISST f_InformaPISST = NULL;
static PFN_InformaCOFINSAliq f_InformaCOFINSAliq = NULL;
static PFN_InformaCOFINSQtde f_InformaCOFINSQtde = NULL;
static PFN_InformaCOFINSNT f_InformaCOFINSNT = NULL;
static PFN_InformaCOFINSOutr f_InformaCOFINSOutr = NULL;
static PFN_InformaCOFINSST f_InformaCOFINSST = NULL;
static PFN_InformaISSQN f_InformaISSQN = NULL;
static PFN_InformaIPIDevolvido f_InformaIPIDevolvido = NULL;
static PFN_InformaObservacaoContribuinteItem f_InformaObservacaoContribuinteItem = NULL;
static PFN_InformaObservacaoFiscoItem f_InformaObservacaoFiscoItem = NULL;
static PFN_InformaTransporte f_InformaTransporte = NULL;
static PFN_InformaTransportador f_InformaTransportador = NULL;
static PFN_InformaRetencaoTransporte f_InformaRetencaoTransporte = NULL;
static PFN_InformaVeiculoTransporte f_InformaVeiculoTransporte = NULL;
static PFN_InformaReboque f_InformaReboque = NULL;
static PFN_InformaVolume f_InformaVolume = NULL;
static PFN_InformaLacre f_InformaLacre = NULL;
static PFN_InformaFatura f_InformaFatura = NULL;
static PFN_InformaParcela f_InformaParcela = NULL;
static PFN_InformaInformacoesPagamento f_InformaInformacoesPagamento = NULL;
static PFN_InformaPagamento f_InformaPagamento = NULL;
static PFN_InformaIntermediador f_InformaIntermediador = NULL;
static PFN_InformaInformacoesAdicionais f_InformaInformacoesAdicionais = NULL;
static PFN_InformaObservacoesContribuinte f_InformaObservacoesContribuinte = NULL;
static PFN_InformaObservacoesFisco f_InformaObservacoesFisco = NULL;
static PFN_InformaProcessoReferenciado f_InformaProcessoReferenciado = NULL;
static PFN_InformaExportacao f_InformaExportacao = NULL;
static PFN_InformaCompra f_InformaCompra = NULL;
static PFN_InformaCana f_InformaCana = NULL;
static PFN_InformaFornecimentoDiarioCana f_InformaFornecimentoDiarioCana = NULL;
static PFN_InformaDeducaoCana f_InformaDeducaoCana = NULL;
static PFN_InformaResponsavelTecnico f_InformaResponsavelTecnico = NULL;
static PFN_InformaInformacoesSuplementares f_InformaInformacoesSuplementares = NULL;
static PFN_FechaCupomVenda f_FechaCupomVenda = NULL;
static PFN_LoadPDF f_LoadPDF = NULL;
static PFN_ConfigurarDiretorioSaidaPDF f_ConfigurarDiretorioSaidaPDF = NULL;
static PFN_GerarDanfeNFCePDF f_GerarDanfeNFCePDF = NULL;
static PFN_GerarDanfeNFCePersonalizadoPDF f_GerarDanfeNFCePersonalizadoPDF = NULL;
static PFN_GerarDanfeNFePDF f_GerarDanfeNFePDF = NULL;
static PFN_GerarDanfeNFePersonalizadoPDF f_GerarDanfeNFePersonalizadoPDF = NULL;
static PFN_UnloadPDF f_UnloadPDF = NULL;

BOOL LoadOriginalDLL()
{
    if (hDLL) return TRUE;
    hDLL = LoadLibraryA("E1_Notas.dll");
    if (!hDLL) return FALSE;

    f_EmitirNota = (PFN_EmitirNota)GetProcAddress(hDLL, "EmitirNota");
    f_ConsultarStatus = (PFN_ConsultarStatus)GetProcAddress(hDLL, "ConsultarStatus");
    f_ConsultarNota = (PFN_ConsultarNota)GetProcAddress(hDLL, "ConsultarNota");
    f_CancelarNota = (PFN_CancelarNota)GetProcAddress(hDLL, "CancelarNota");
    f_InutilizarNumeracao = (PFN_InutilizarNumeracao)GetProcAddress(hDLL, "InutilizarNumeracao");
    f_ProcessamentoContingencia = (PFN_ProcessamentoContingencia)GetProcAddress(hDLL, "ProcessamentoContingencia");
    f_CancelamentoPorSubstituicao = (PFN_CancelamentoPorSubstituicao)GetProcAddress(hDLL, "CancelamentoPorSubstituicao");
    f_CartaDeCorrecao = (PFN_CartaDeCorrecao)GetProcAddress(hDLL, "CartaDeCorrecao");
    f_AbreCupomVenda = (PFN_AbreCupomVenda)GetProcAddress(hDLL, "AbreCupomVenda");
    f_InformaIdentificacao = (PFN_InformaIdentificacao)GetProcAddress(hDLL, "InformaIdentificacao");
    f_InformaDocumentoReferenciadoNFe = (PFN_InformaDocumentoReferenciadoNFe)GetProcAddress(hDLL, "InformaDocumentoReferenciadoNFe");
    f_InformaDocumentoReferenciadoNF = (PFN_InformaDocumentoReferenciadoNF)GetProcAddress(hDLL, "InformaDocumentoReferenciadoNF");
    f_InformaDocumentoReferenciadoNFP = (PFN_InformaDocumentoReferenciadoNFP)GetProcAddress(hDLL, "InformaDocumentoReferenciadoNFP");
    f_InformaDocumentoReferenciadoCTe = (PFN_InformaDocumentoReferenciadoCTe)GetProcAddress(hDLL, "InformaDocumentoReferenciadoCTe");
    f_InformaDocumentoReferenciadoECF = (PFN_InformaDocumentoReferenciadoECF)GetProcAddress(hDLL, "InformaDocumentoReferenciadoECF");
    f_InformaEmitente = (PFN_InformaEmitente)GetProcAddress(hDLL, "InformaEmitente");
    f_InformaAvulsa = (PFN_InformaAvulsa)GetProcAddress(hDLL, "InformaAvulsa");
    f_InformaDestinatario = (PFN_InformaDestinatario)GetProcAddress(hDLL, "InformaDestinatario");
    f_InformaRetirada = (PFN_InformaRetirada)GetProcAddress(hDLL, "InformaRetirada");
    f_InformaEntrega = (PFN_InformaEntrega)GetProcAddress(hDLL, "InformaEntrega");
    f_InformaAutorizacaoXML = (PFN_InformaAutorizacaoXML)GetProcAddress(hDLL, "InformaAutorizacaoXML");
    f_InformaProduto = (PFN_InformaProduto)GetProcAddress(hDLL, "InformaProduto");
    f_InformaInformacoesAdicionaisProduto = (PFN_InformaInformacoesAdicionaisProduto)GetProcAddress(hDLL, "InformaInformacoesAdicionaisProduto");
    f_InformaDeclaracaoImportacao = (PFN_InformaDeclaracaoImportacao)GetProcAddress(hDLL, "InformaDeclaracaoImportacao");
    f_InformaAdicaoDeclaracaoImportacao = (PFN_InformaAdicaoDeclaracaoImportacao)GetProcAddress(hDLL, "InformaAdicaoDeclaracaoImportacao");
    f_InformaDetalhamentoExportacao = (PFN_InformaDetalhamentoExportacao)GetProcAddress(hDLL, "InformaDetalhamentoExportacao");
    f_InformaRastreabilidade = (PFN_InformaRastreabilidade)GetProcAddress(hDLL, "InformaRastreabilidade");
    f_InformaVeiculoNovo = (PFN_InformaVeiculoNovo)GetProcAddress(hDLL, "InformaVeiculoNovo");
    f_InformaMedicamento = (PFN_InformaMedicamento)GetProcAddress(hDLL, "InformaMedicamento");
    f_InformaArmamento = (PFN_InformaArmamento)GetProcAddress(hDLL, "InformaArmamento");
    f_InformaCombustivel = (PFN_InformaCombustivel)GetProcAddress(hDLL, "InformaCombustivel");
    f_InformaCombustivelCIDE = (PFN_InformaCombustivelCIDE)GetProcAddress(hDLL, "InformaCombustivelCIDE");
    f_InformaCombustivelEncerrante = (PFN_InformaCombustivelEncerrante)GetProcAddress(hDLL, "InformaCombustivelEncerrante");
    f_InformaCombustivelOrigem = (PFN_InformaCombustivelOrigem)GetProcAddress(hDLL, "InformaCombustivelOrigem");
    f_InformaValorTotalTributos = (PFN_InformaValorTotalTributos)GetProcAddress(hDLL, "InformaValorTotalTributos");
    f_InformaICMS00 = (PFN_InformaICMS00)GetProcAddress(hDLL, "InformaICMS00");
    f_InformaICMS02 = (PFN_InformaICMS02)GetProcAddress(hDLL, "InformaICMS02");
    f_InformaICMS10 = (PFN_InformaICMS10)GetProcAddress(hDLL, "InformaICMS10");
    f_InformaICMS15 = (PFN_InformaICMS15)GetProcAddress(hDLL, "InformaICMS15");
    f_InformaICMS20 = (PFN_InformaICMS20)GetProcAddress(hDLL, "InformaICMS20");
    f_InformaICMS30 = (PFN_InformaICMS30)GetProcAddress(hDLL, "InformaICMS30");
    f_InformaICMS40 = (PFN_InformaICMS40)GetProcAddress(hDLL, "InformaICMS40");
    f_InformaICMS51 = (PFN_InformaICMS51)GetProcAddress(hDLL, "InformaICMS51");
    f_InformaICMS53 = (PFN_InformaICMS53)GetProcAddress(hDLL, "InformaICMS53");
    f_InformaICMS60 = (PFN_InformaICMS60)GetProcAddress(hDLL, "InformaICMS60");
    f_InformaICMS61 = (PFN_InformaICMS61)GetProcAddress(hDLL, "InformaICMS61");
    f_InformaICMS70 = (PFN_InformaICMS70)GetProcAddress(hDLL, "InformaICMS70");
    f_InformaICMS90 = (PFN_InformaICMS90)GetProcAddress(hDLL, "InformaICMS90");
    f_InformaICMSPart = (PFN_InformaICMSPart)GetProcAddress(hDLL, "InformaICMSPart");
    f_InformaICMSST = (PFN_InformaICMSST)GetProcAddress(hDLL, "InformaICMSST");
    f_InformaICMSSN101 = (PFN_InformaICMSSN101)GetProcAddress(hDLL, "InformaICMSSN101");
    f_InformaICMSSN102 = (PFN_InformaICMSSN102)GetProcAddress(hDLL, "InformaICMSSN102");
    f_InformaICMSSN201 = (PFN_InformaICMSSN201)GetProcAddress(hDLL, "InformaICMSSN201");
    f_InformaICMSSN202 = (PFN_InformaICMSSN202)GetProcAddress(hDLL, "InformaICMSSN202");
    f_InformaICMSSN500 = (PFN_InformaICMSSN500)GetProcAddress(hDLL, "InformaICMSSN500");
    f_InformaICMSSN900 = (PFN_InformaICMSSN900)GetProcAddress(hDLL, "InformaICMSSN900");
    f_InformaICMSUFDest = (PFN_InformaICMSUFDest)GetProcAddress(hDLL, "InformaICMSUFDest");
    f_InformaIPITrib = (PFN_InformaIPITrib)GetProcAddress(hDLL, "InformaIPITrib");
    f_InformaIPINT = (PFN_InformaIPINT)GetProcAddress(hDLL, "InformaIPINT");
    f_InformaII = (PFN_InformaII)GetProcAddress(hDLL, "InformaII");
    f_InformaPISAliq = (PFN_InformaPISAliq)GetProcAddress(hDLL, "InformaPISAliq");
    f_InformaPISQtde = (PFN_InformaPISQtde)GetProcAddress(hDLL, "InformaPISQtde");
    f_InformaPISNT = (PFN_InformaPISNT)GetProcAddress(hDLL, "InformaPISNT");
    f_InformaPISOutr = (PFN_InformaPISOutr)GetProcAddress(hDLL, "InformaPISOutr");
    f_InformaPISST = (PFN_InformaPISST)GetProcAddress(hDLL, "InformaPISST");
    f_InformaCOFINSAliq = (PFN_InformaCOFINSAliq)GetProcAddress(hDLL, "InformaCOFINSAliq");
    f_InformaCOFINSQtde = (PFN_InformaCOFINSQtde)GetProcAddress(hDLL, "InformaCOFINSQtde");
    f_InformaCOFINSNT = (PFN_InformaCOFINSNT)GetProcAddress(hDLL, "InformaCOFINSNT");
    f_InformaCOFINSOutr = (PFN_InformaCOFINSOutr)GetProcAddress(hDLL, "InformaCOFINSOutr");
    f_InformaCOFINSST = (PFN_InformaCOFINSST)GetProcAddress(hDLL, "InformaCOFINSST");
    f_InformaISSQN = (PFN_InformaISSQN)GetProcAddress(hDLL, "InformaISSQN");
    f_InformaIPIDevolvido = (PFN_InformaIPIDevolvido)GetProcAddress(hDLL, "InformaIPIDevolvido");
    f_InformaObservacaoContribuinteItem = (PFN_InformaObservacaoContribuinteItem)GetProcAddress(hDLL, "InformaObservacaoContribuinteItem");
    f_InformaObservacaoFiscoItem = (PFN_InformaObservacaoFiscoItem)GetProcAddress(hDLL, "InformaObservacaoFiscoItem");
    f_InformaTransporte = (PFN_InformaTransporte)GetProcAddress(hDLL, "InformaTransporte");
    f_InformaTransportador = (PFN_InformaTransportador)GetProcAddress(hDLL, "InformaTransportador");
    f_InformaRetencaoTransporte = (PFN_InformaRetencaoTransporte)GetProcAddress(hDLL, "InformaRetencaoTransporte");
    f_InformaVeiculoTransporte = (PFN_InformaVeiculoTransporte)GetProcAddress(hDLL, "InformaVeiculoTransporte");
    f_InformaReboque = (PFN_InformaReboque)GetProcAddress(hDLL, "InformaReboque");
    f_InformaVolume = (PFN_InformaVolume)GetProcAddress(hDLL, "InformaVolume");
    f_InformaLacre = (PFN_InformaLacre)GetProcAddress(hDLL, "InformaLacre");
    f_InformaFatura = (PFN_InformaFatura)GetProcAddress(hDLL, "InformaFatura");
    f_InformaParcela = (PFN_InformaParcela)GetProcAddress(hDLL, "InformaParcela");
    f_InformaInformacoesPagamento = (PFN_InformaInformacoesPagamento)GetProcAddress(hDLL, "InformaInformacoesPagamento");
    f_InformaPagamento = (PFN_InformaPagamento)GetProcAddress(hDLL, "InformaPagamento");
    f_InformaIntermediador = (PFN_InformaIntermediador)GetProcAddress(hDLL, "InformaIntermediador");
    f_InformaInformacoesAdicionais = (PFN_InformaInformacoesAdicionais)GetProcAddress(hDLL, "InformaInformacoesAdicionais");
    f_InformaObservacoesContribuinte = (PFN_InformaObservacoesContribuinte)GetProcAddress(hDLL, "InformaObservacoesContribuinte");
    f_InformaObservacoesFisco = (PFN_InformaObservacoesFisco)GetProcAddress(hDLL, "InformaObservacoesFisco");
    f_InformaProcessoReferenciado = (PFN_InformaProcessoReferenciado)GetProcAddress(hDLL, "InformaProcessoReferenciado");
    f_InformaExportacao = (PFN_InformaExportacao)GetProcAddress(hDLL, "InformaExportacao");
    f_InformaCompra = (PFN_InformaCompra)GetProcAddress(hDLL, "InformaCompra");
    f_InformaCana = (PFN_InformaCana)GetProcAddress(hDLL, "InformaCana");
    f_InformaFornecimentoDiarioCana = (PFN_InformaFornecimentoDiarioCana)GetProcAddress(hDLL, "InformaFornecimentoDiarioCana");
    f_InformaDeducaoCana = (PFN_InformaDeducaoCana)GetProcAddress(hDLL, "InformaDeducaoCana");
    f_InformaResponsavelTecnico = (PFN_InformaResponsavelTecnico)GetProcAddress(hDLL, "InformaResponsavelTecnico");
    f_InformaInformacoesSuplementares = (PFN_InformaInformacoesSuplementares)GetProcAddress(hDLL, "InformaInformacoesSuplementares");
    f_FechaCupomVenda = (PFN_FechaCupomVenda)GetProcAddress(hDLL, "FechaCupomVenda");
    f_LoadPDF = (PFN_LoadPDF)GetProcAddress(hDLL, "LoadPDF");
    f_ConfigurarDiretorioSaidaPDF = (PFN_ConfigurarDiretorioSaidaPDF)GetProcAddress(hDLL, "ConfigurarDiretorioSaidaPDF");
    f_GerarDanfeNFCePDF = (PFN_GerarDanfeNFCePDF)GetProcAddress(hDLL, "GerarDanfeNFCePDF");
    f_GerarDanfeNFCePersonalizadoPDF = (PFN_GerarDanfeNFCePersonalizadoPDF)GetProcAddress(hDLL, "GerarDanfeNFCePersonalizadoPDF");
    f_GerarDanfeNFePDF = (PFN_GerarDanfeNFePDF)GetProcAddress(hDLL, "GerarDanfeNFePDF");
    f_GerarDanfeNFePersonalizadoPDF = (PFN_GerarDanfeNFePersonalizadoPDF)GetProcAddress(hDLL, "GerarDanfeNFePersonalizadoPDF");
    f_UnloadPDF = (PFN_UnloadPDF)GetProcAddress(hDLL, "UnloadPDF");

    return TRUE;
}

// Helper for char* functions
void CallCharFunction(char* (*func)(), char* buffer, int bufSize) {
    if (LoadOriginalDLL() && func) {
        char* result = func();
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

// Wrappers stdcall para VB6
__declspec(dllexport) void __stdcall EmitirNota(char* path, char* uuid, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_EmitirNota) {
        char* result = f_EmitirNota(path, uuid);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall ConsultarStatus(char* uuid, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_ConsultarStatus) {
        char* result = f_ConsultarStatus(uuid);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall ConsultarNota(char* chave, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_ConsultarNota) {
        char* result = f_ConsultarNota(chave);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall CancelarNota(char* chave, char* protocolo, char* justificativa, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_CancelarNota) {
        char* result = f_CancelarNota(chave, protocolo, justificativa);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall InutilizarNumeracao(char* cnpj, char* ano, char* justificativa, char* uf, int tpAmb, int serie, int numeroInicial, int numeroFinal, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_InutilizarNumeracao) {
        char* result = f_InutilizarNumeracao(cnpj, ano, justificativa, uf, tpAmb, serie, numeroInicial, numeroFinal);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall ProcessamentoContingencia(char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_ProcessamentoContingencia) {
        char* result = f_ProcessamentoContingencia();
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall CancelamentoPorSubstituicao(char* chCFe, char* chCFeRef, char* xJust, int tpAutor, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_CancelamentoPorSubstituicao) {
        char* result = f_CancelamentoPorSubstituicao(chCFe, chCFeRef, xJust, tpAutor);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall CartaDeCorrecao(char* chCFe, char* xCorrecao, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_CartaDeCorrecao) {
        char* result = f_CartaDeCorrecao(chCFe, xCorrecao);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) int __stdcall AbreCupomVenda(char* chaveDeAcesso) {
    return LoadOriginalDLL() && f_AbreCupomVenda ? f_AbreCupomVenda(chaveDeAcesso) : -1;
}

__declspec(dllexport) int __stdcall InformaIdentificacao(char* cUF, char* cNF, char* natOper, int mod, char* serie, char* nNF, char* dhEmi, char* dhSaiEntOp, int tpNF, int idDest, char* cMunFG, int tpImp, int tpEmis, int cDV, int tpAmb, int finNFe, int indFinal, int indPres, int indIntermedOp, int procEmi, char* verProc, char* dhCont_a, char* xJust_a) {
    return LoadOriginalDLL() && f_InformaIdentificacao ? f_InformaIdentificacao(cUF, cNF, natOper, mod, serie, nNF, dhEmi, dhSaiEntOp, tpNF, idDest, cMunFG, tpImp, tpEmis, cDV, tpAmb, finNFe, indFinal, indPres, indIntermedOp, procEmi, verProc, dhCont_a, xJust_a) : -1;
}

__declspec(dllexport) int __stdcall InformaDocumentoReferenciadoNFe(char* refNFeEx, char* refNFeSigEx) {
    return LoadOriginalDLL() && f_InformaDocumentoReferenciadoNFe ? f_InformaDocumentoReferenciadoNFe(refNFeEx, refNFeSigEx) : -1;
}

__declspec(dllexport) int __stdcall InformaDocumentoReferenciadoNF(char* cUF, char* AAMM, char* CNPJ, char* mod, char* serie, char* nNF) {
    return LoadOriginalDLL() && f_InformaDocumentoReferenciadoNF ? f_InformaDocumentoReferenciadoNF(cUF, AAMM, CNPJ, mod, serie, nNF) : -1;
}

__declspec(dllexport) int __stdcall InformaDocumentoReferenciadoNFP(char* cUF, char* AAMM, char* CNPJEx, char* CPFEx, char* IE, char* mod, char* serie, char* nNF) {
    return LoadOriginalDLL() && f_InformaDocumentoReferenciadoNFP ? f_InformaDocumentoReferenciadoNFP(cUF, AAMM, CNPJEx, CPFEx, IE, mod, serie, nNF) : -1;
}

__declspec(dllexport) int __stdcall InformaDocumentoReferenciadoCTe(char* refCTeEx) {
    return LoadOriginalDLL() && f_InformaDocumentoReferenciadoCTe ? f_InformaDocumentoReferenciadoCTe(refCTeEx) : -1;
}

__declspec(dllexport) int __stdcall InformaDocumentoReferenciadoECF(char* mod, char* nECF, char* nCOO) {
    return LoadOriginalDLL() && f_InformaDocumentoReferenciadoECF ? f_InformaDocumentoReferenciadoECF(mod, nECF, nCOO) : -1;
}

__declspec(dllexport) int __stdcall InformaEmitente(char* CNPJex, char* CPFex, char* xNome, char* xFantOp, char* xLgr, char* nro, char* xCplOp, char* xBairro, char* cMun, char* xMun, char* UF, char* CEP, char* cPaisOp, char* xPaisOp, char* foneOp, char* IE, char* IESTop, char* IM_a, char* CNAEop_a, int CRT) {
    return LoadOriginalDLL() && f_InformaEmitente ? f_InformaEmitente(CNPJex, CPFex, xNome, xFantOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEP, cPaisOp, xPaisOp, foneOp, IE, IESTop, IM_a, CNAEop_a, CRT) : -1;
}

__declspec(dllexport) int __stdcall InformaAvulsa(char* CNPJ, char* xOrgao, char* matr, char* xAgente, char* foneOp, char* UF, char* nDARop, char* dEmiOp, char* vDARop, char* repEmi, char* dPagOp) {
    return LoadOriginalDLL() && f_InformaAvulsa ? f_InformaAvulsa(CNPJ, xOrgao, matr, xAgente, foneOp, UF, nDARop, dEmiOp, vDARop, repEmi, dPagOp) : -1;
}

__declspec(dllexport) int __stdcall InformaDestinatario(char* CNPJex, char* CPFex, char* idEstrangeiroEx, char* xNomeOp, char* xLgr, char* nro, char* xCplOp, char* xBairro, char* cMun, char* xMun, char* UF, char* CEPop, char* cPaisOp, char* xPaisOp, char* foneOp, int indIEDest, char* IEop, char* ISUFop, char* IMop, char* emailOp) {
    return LoadOriginalDLL() && f_InformaDestinatario ? f_InformaDestinatario(CNPJex, CPFex, idEstrangeiroEx, xNomeOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEPop, cPaisOp, xPaisOp, foneOp, indIEDest, IEop, ISUFop, IMop, emailOp) : -1;
}

__declspec(dllexport) int __stdcall InformaRetirada(char* CNPJex, char* CPFex, char* xNomeOp, char* xLgr, char* nro, char* xCplOp, char* xBairro, char* cMun, char* xMun, char* UF, char* CEPop, char* cPaisOp, char* xPaisOp, char* foneOp, char* emailOp, char* IEop) {
    return LoadOriginalDLL() && f_InformaRetirada ? f_InformaRetirada(CNPJex, CPFex, xNomeOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEPop, cPaisOp, xPaisOp, foneOp, emailOp, IEop) : -1;
}

__declspec(dllexport) int __stdcall InformaEntrega(char* CNPJex, char* CPFex, char* xNomeOp, char* xLgr, char* nro, char* xCplOp, char* xBairro, char* cMun, char* xMun, char* UF, char* CEPop, char* cPaisOp, char* xPaisOp, char* foneOp, char* emailOp, char* IEop) {
    return LoadOriginalDLL() && f_InformaEntrega ? f_InformaEntrega(CNPJex, CPFex, xNomeOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEPop, cPaisOp, xPaisOp, foneOp, emailOp, IEop) : -1;
}

__declspec(dllexport) int __stdcall InformaAutorizacaoXML(char* CNPJex, char* CPFex) {
    return LoadOriginalDLL() && f_InformaAutorizacaoXML ? f_InformaAutorizacaoXML(CNPJex, CPFex) : -1;
}

__declspec(dllexport) int __stdcall InformaProduto(char* cProd, char* cEAN, char* xProd, char* NCM, char* NVE, char* CEST_a, char* indEscalaOp_a, char* CNPJFabOp_a, char* cBenefOp, char* EXTIPIop, char* CFOP, char* uCom, char* qCom, char* vUnCom, char* vProd, char* cEANTrib, char* uTrib, char* qTrib, char* vUnTrib, char* vFreteOp, char* vSegOp, char* vDescOp, char* vOutroOp, int indTot) {
    return LoadOriginalDLL() && f_InformaProduto ? f_InformaProduto(cProd, cEAN, xProd, NCM, NVE, CEST_a, indEscalaOp_a, CNPJFabOp_a, cBenefOp, EXTIPIop, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib, uTrib, qTrib, vUnTrib, vFreteOp, vSegOp, vDescOp, vOutroOp, indTot) : -1;
}

__declspec(dllexport) int __stdcall InformaInformacoesAdicionaisProduto(int nItem, char* infAdProd) {
    return LoadOriginalDLL() && f_InformaInformacoesAdicionaisProduto ? f_InformaInformacoesAdicionaisProduto(nItem, infAdProd) : -1;
}

__declspec(dllexport) int __stdcall InformaDeclaracaoImportacao(int nItem, char* nDI, char* dDI, char* xLocDesemb, char* UFDesemb, char* dDesemb, int tpViaTransp, char* vAFRMMOp, int tpIntermedio, char* CNPJEx, char* CPFEx, char* UFTerceiroOp, char* cExportador) {
    return LoadOriginalDLL() && f_InformaDeclaracaoImportacao ? f_InformaDeclaracaoImportacao(nItem, nDI, dDI, xLocDesemb, UFDesemb, dDesemb, tpViaTransp, vAFRMMOp, tpIntermedio, CNPJEx, CPFEx, UFTerceiroOp, cExportador) : -1;
}

__declspec(dllexport) int __stdcall InformaAdicaoDeclaracaoImportacao(int nItem, int nDI, char* nAdicaoOp, char* nSeqAdic, char* cFabricante, char* vDescDIOp, char* nDrawOp) {
    return LoadOriginalDLL() && f_InformaAdicaoDeclaracaoImportacao ? f_InformaAdicaoDeclaracaoImportacao(nItem, nDI, nAdicaoOp, nSeqAdic, cFabricante, vDescDIOp, nDrawOp) : -1;
}

__declspec(dllexport) int __stdcall InformaDetalhamentoExportacao(int nItem, char* nDrawOp) {
    return LoadOriginalDLL() && f_InformaDetalhamentoExportacao ? f_InformaDetalhamentoExportacao(nItem, nDrawOp) : -1;
}

__declspec(dllexport) int __stdcall InformaRastreabilidade(int nItem, char* nLote, char* qLote, char* dFab, char* dVal, char* cAgregOp) {
    return LoadOriginalDLL() && f_InformaRastreabilidade ? f_InformaRastreabilidade(nItem, nLote, qLote, dFab, dVal, cAgregOp) : -1;
}

__declspec(dllexport) int __stdcall InformaVeiculoNovo(int nItem, int tpOp, char* chassi, char* cCor, char* xCor, char* pot, char* cilin, char* pesoL, char* pesoB, char* nSerie, char* tpComb, char* nMotor, char* CMT, char* dist, char* anoMod, char* anoFab, char* tpPint, char* tpVeic, int espVeic, char* VIN, int condVeic, char* cMod, char* cCorDENATRAN, char* lota, int tpRest) {
    return LoadOriginalDLL() && f_InformaVeiculoNovo ? f_InformaVeiculoNovo(nItem, tpOp, chassi, cCor, xCor, pot, cilin, pesoL, pesoB, nSerie, tpComb, nMotor, CMT, dist, anoMod, anoFab, tpPint, tpVeic, espVeic, VIN, condVeic, cMod, cCorDENATRAN, lota, tpRest) : -1;
}

__declspec(dllexport) int __stdcall InformaMedicamento(int nItem, char* cProdANVISA, char* xMotivoIsencaoOp, char* vPMC) {
    return LoadOriginalDLL() && f_InformaMedicamento ? f_InformaMedicamento(nItem, cProdANVISA, xMotivoIsencaoOp, vPMC) : -1;
}

__declspec(dllexport) int __stdcall InformaArmamento(int nItem, int tpArma, char* nSerie, char* nCano, char* descr) {
    return LoadOriginalDLL() && f_InformaArmamento ? f_InformaArmamento(nItem, tpArma, nSerie, nCano, descr) : -1;
}

__declspec(dllexport) int __stdcall InformaCombustivel(int nItem, char* cProdANP, char* descANP, char* pGLPOp, char* pGNnOp, char* pGNiOp, char* vPartOp, char* CODIFOp, char* qTempOp, char* UFCons, char* pBioOp) {
    return LoadOriginalDLL() && f_InformaCombustivel ? f_InformaCombustivel(nItem, cProdANP, descANP, pGLPOp, pGNnOp, pGNiOp, vPartOp, CODIFOp, qTempOp, UFCons, pBioOp) : -1;
}

__declspec(dllexport) int __stdcall InformaCombustivelCIDE(int nItem, char* qBCProd, char* vAliqProd, char* vCIDE) {
    return LoadOriginalDLL() && f_InformaCombustivelCIDE ? f_InformaCombustivelCIDE(nItem, qBCProd, vAliqProd, vCIDE) : -1;
}

__declspec(dllexport) int __stdcall InformaCombustivelEncerrante(int nItem, char* nBico, char* nBombaOp, char* nTanque, char* vEncIni, char* vEncFin) {
    return LoadOriginalDLL() && f_InformaCombustivelEncerrante ? f_InformaCombustivelEncerrante(nItem, nBico, nBombaOp, nTanque, vEncIni, vEncFin) : -1;
}

__declspec(dllexport) int __stdcall InformaCombustivelOrigem(int nItem, int indImport, char* cUFOrig, char* pOrig) {
    return LoadOriginalDLL() && f_InformaCombustivelOrigem ? f_InformaCombustivelOrigem(nItem, indImport, cUFOrig, pOrig) : -1;
}

__declspec(dllexport) int __stdcall InformaValorTotalTributos(int nItem, char* vTotTrib) {
    return LoadOriginalDLL() && f_InformaValorTotalTributos ? f_InformaValorTotalTributos(nItem, vTotTrib) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS00(int nItem, int orig, char* CST, int modBC, char* vBC, char* pICMS, char* vICMS, char* pFCP_a, char* vFCP_a) {
    return LoadOriginalDLL() && f_InformaICMS00 ? f_InformaICMS00(nItem, orig, CST, modBC, vBC, pICMS, vICMS, pFCP_a, vFCP_a) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS02(int nItem, int orig, char* CST, char* qBCMonoOp, char* adRemICMS, char* vICMSMono) {
    return LoadOriginalDLL() && f_InformaICMS02 ? f_InformaICMS02(nItem, orig, CST, qBCMonoOp, adRemICMS, vICMSMono) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS10(int nItem, int orig, char* CST, int modBC, char* vBC, char* pICMS, char* vICMS, char* vBCFCP_a, char* pFCP_a, char* vFCP_a, int modBCST, char* pMVASTop, char* pRedBCSTop, char* vBCST, char* pICMSST, char* vICMSST, char* vBCFCPST_b, char* pFCPST_b, char* vFCPST_b) {
    return LoadOriginalDLL() && f_InformaICMS10 ? f_InformaICMS10(nItem, orig, CST, modBC, vBC, pICMS, vICMS, vBCFCP_a, pFCP_a, vFCP_a, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_b, pFCPST_b, vFCPST_b) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS15(int nItem, int orig, char* CST, char* qBCMonoOp, char* adRemICMS, char* vICMSMono, char* qBCMonoRetenOp, char* adRemICMSReten, char* vICMSMonoReten, char* pRedAdRem_a, int motRedAdRem_a) {
    return LoadOriginalDLL() && f_InformaICMS15 ? f_InformaICMS15(nItem, orig, CST, qBCMonoOp, adRemICMS, vICMSMono, qBCMonoRetenOp, adRemICMSReten, vICMSMonoReten, pRedAdRem_a, motRedAdRem_a) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS20(int nItem, int orig, char* CST, int modBC, char* pRedBC, char* vBC, char* pICMS, char* vICMS, char* vBCFCP_a, char* pFCP_a, char* vFCP_a, char* vICMSDeson_b, int motDesICMS_b, int indDeduzDesonOp) {
    return LoadOriginalDLL() && f_InformaICMS20 ? f_InformaICMS20(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP_a, pFCP_a, vFCP_a, vICMSDeson_b, motDesICMS_b, indDeduzDesonOp) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS30(int nItem, int orig, char* CST, int modBCST, char* pMVASTop, char* pRedBCSTop, char* vBCST, char* pICMSST, char* vICMSST, char* vBCFCPST_a, char* pFCPST_a, char* vFCPST_a, char* vICMSDeson_b, int motDesICMS_b, int indDeduzDesonOp) {
    return LoadOriginalDLL() && f_InformaICMS30 ? f_InformaICMS30(nItem, orig, CST, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, vICMSDeson_b, motDesICMS_b, indDeduzDesonOp) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS40(int nItem, int orig, char* CST, char* vICMSDeson_a, int motDesICMS_a, int indDeduzDesonOp) {
    return LoadOriginalDLL() && f_InformaICMS40 ? f_InformaICMS40(nItem, orig, CST, vICMSDeson_a, motDesICMS_a, indDeduzDesonOp) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS51(int nItem, int orig, char* CST, int modBCop, char* pRedBCop, char* vBCop, char* pICMSop, char* vICMSOpOp, char* pDifOp, char* vICMSDifOp, char* vICMSop, char* vBCFCP_a, char* pFCP_a, char* vFCP_a) {
    return LoadOriginalDLL() && f_InformaICMS51 ? f_InformaICMS51(nItem, orig, CST, modBCop, pRedBCop, vBCop, pICMSop, vICMSOpOp, pDifOp, vICMSDifOp, vICMSop, vBCFCP_a, pFCP_a, vFCP_a) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS53(int nItem, int orig, char* CST, char* qBCMonoOp, char* adRemICMSOp, char* vICMSMonoOperOp, char* pDifOp, char* vICMSMonoDifOp, char* vICMSMonoOp) {
    return LoadOriginalDLL() && f_InformaICMS53 ? f_InformaICMS53(nItem, orig, CST, qBCMonoOp, adRemICMSOp, vICMSMonoOperOp, pDifOp, vICMSMonoDifOp, vICMSMonoOp) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS60(int nItem, int orig, char* CST, char* vBCSTRet_a, char* pST_a, char* vICMSSubstitutoOp_a, char* vICMSSTRet_a, char* vBCFCPSTRet_b, char* pFCPSTRet_b, char* vFCPSTRet_b, char* pRedBCEfet_c, char* vBCEfet_c, char* pICMSEfet_c, char* vICMSEfet_c) {
    return LoadOriginalDLL() && f_InformaICMS60 ? f_InformaICMS60(nItem, orig, CST, vBCSTRet_a, pST_a, vICMSSubstitutoOp_a, vICMSSTRet_a, vBCFCPSTRet_b, pFCPSTRet_b, vFCPSTRet_b, pRedBCEfet_c, vBCEfet_c, pICMSEfet_c, vICMSEfet_c) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS61(int nItem, int orig, char* CST, char* qBCMonoRetOp, char* adRemICMSRet, char* vICMSMonoRet) {
    return LoadOriginalDLL() && f_InformaICMS61 ? f_InformaICMS61(nItem, orig, CST, qBCMonoRetOp, adRemICMSRet, vICMSMonoRet) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS70(int nItem, int orig, char* CST, int modBC, char* pRedBC, char* vBC, char* pICMS, char* vICMS, char* vBCFCP_a, char* pFCP_a, char* vFCP_a, int modBCST, char* pMVASTop, char* pRedBCSTop, char* vBCST, char* pICMSST, char* vICMSST, char* vBCFCPST_b, char* pFCPST_b, char* vFCPST_b, char* vICMSDeson_c, int motDesICMS_c, int indDeduzDesonOp) {
    return LoadOriginalDLL() && f_InformaICMS70 ? f_InformaICMS70(nItem, orig, CST, modBC, pRedBC, vBC, pICMS, vICMS, vBCFCP_a, pFCP_a, vFCP_a, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_b, pFCPST_b, vFCPST_b, vICMSDeson_c, motDesICMS_c, indDeduzDesonOp) : -1;
}

__declspec(dllexport) int __stdcall InformaICMS90(int nItem, int orig, char* CST, int modBC_a, char* vBC_a, char* pRedBCop_a, char* pICMS_a, char* vICMS_a, char* vBCFCP_aa, char* pFCP_aa, char* vFCP_aa, int modBCST_b, char* pMVASTop_b, char* pRedBCSTop_b, char* vBCST_b, char* pICMSST_b, char* vICMSST_b, char* vBCFCPST_bb, char* pFCPST_bb, char* vFCPST_bb, char* vICMSDeson_c, int motDesICMS_c, int indDeduzDesonOp) {
    return LoadOriginalDLL() && f_InformaICMS90 ? f_InformaICMS90(nItem, orig, CST, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c, motDesICMS_c, indDeduzDesonOp) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSPart(int nItem, int orig, char* CST, int modBC, char* vBC, char* pRedBCop, char* pICMS, char* vICMS, int modBCST, char* pMVASTop, char* pRedBCSTop, char* vBCST, char* pICMSST, char* vICMSST, char* vBCFCPST_a, char* pFCPST_a, char* vFCPST_a, char* pBCOper, char* UFST) {
    return LoadOriginalDLL() && f_InformaICMSPart ? f_InformaICMSPart(nItem, orig, CST, modBC, vBC, pRedBCop, pICMS, vICMS, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, pBCOper, UFST) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSST(int nItem, int orig, char* CST, char* vBCSTRet, char* pSTop, char* vICMSSubstitutoOp, char* vICMSSTRet, char* vBCFCPSTRet_a, char* pFCPSTRet_a, char* vFCPSTRet_a, char* vBCSTDest, char* vICMSSTDest, char* pRedBCEfet_b, char* vBCEfet_b, char* pICMSEfet_b, char* vICMSEfet_b) {
    return LoadOriginalDLL() && f_InformaICMSST ? f_InformaICMSST(nItem, orig, CST, vBCSTRet, pSTop, vICMSSubstitutoOp, vICMSSTRet, vBCFCPSTRet_a, pFCPSTRet_a, vFCPSTRet_a, vBCSTDest, vICMSSTDest, pRedBCEfet_b, vBCEfet_b, pICMSEfet_b, vICMSEfet_b) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSSN101(int nItem, int orig, char* CSOSN, char* pCredSN, char* vCredICMSSN) {
    return LoadOriginalDLL() && f_InformaICMSSN101 ? f_InformaICMSSN101(nItem, orig, CSOSN, pCredSN, vCredICMSSN) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSSN102(int nItem, int orig, char* CSOSN) {
    return LoadOriginalDLL() && f_InformaICMSSN102 ? f_InformaICMSSN102(nItem, orig, CSOSN) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSSN201(int nItem, int orig, char* CSOSN, int modBCST, char* pMVASTop, char* pRedBCSTop, char* vBCST, char* pICMSST, char* vICMSST, char* vBCFCPST_a, char* pFCPST_a, char* vFCPST_a, char* pCredSN, char* vCredICMSSN) {
    return LoadOriginalDLL() && f_InformaICMSSN201 ? f_InformaICMSSN201(nItem, orig, CSOSN, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, pCredSN, vCredICMSSN) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSSN202(int nItem, int orig, char* CSOSN, int modBCST, char* pMVASTop, char* pRedBCSTop, char* vBCST, char* pICMSST, char* vICMSST, char* vBCFCPST_a, char* pFCPST_a, char* vFCPST_a) {
    return LoadOriginalDLL() && f_InformaICMSSN202 ? f_InformaICMSSN202(nItem, orig, CSOSN, modBCST, pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSSN500(int nItem, int orig, char* CSOSN, char* vBCSTRet_a, char* pST_a, char* vICMSSubstitutoOp_a, char* vICMSSTRet_a, char* vBCFCPSTRet_b, char* pFCPSTRet_b, char* vFCPSTRet_b, char* pRedBCEfet_c, char* vBCEfet_c, char* pICMSEfet_c, char* vICMSEfet_c) {
    return LoadOriginalDLL() && f_InformaICMSSN500 ? f_InformaICMSSN500(nItem, orig, CSOSN, vBCSTRet_a, pST_a, vICMSSubstitutoOp_a, vICMSSTRet_a, vBCFCPSTRet_b, pFCPSTRet_b, vFCPSTRet_b, pRedBCEfet_c, vBCEfet_c, pICMSEfet_c, vICMSEfet_c) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSSN900(int nItem, int orig, char* CSOSN, int modBC_a, char* vBC_a, char* pRedBCop_a, char* pICMS_a, char* vICMS_a, int modBCST_b, char* pMVASTop_b, char* pRedBCSTop_b, char* vBCST_b, char* pICMSST_b, char* vICMSST_b, char* vBCFCPST_c, char* pFCPST_c, char* vFCPST_c, char* pCredSN_d, char* vCredICMSSN_d) {
    return LoadOriginalDLL() && f_InformaICMSSN900 ? f_InformaICMSSN900(nItem, orig, CSOSN, modBC_a, vBC_a, pRedBCop_a, pICMS_a, vICMS_a, modBCST_b, pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_c, pFCPST_c, vFCPST_c, pCredSN_d, vCredICMSSN_d) : -1;
}

__declspec(dllexport) int __stdcall InformaICMSUFDest(int nItem, char* vBCUFDest, char* vBCFCPUFDest, char* pFCPUFDestOp, char* pICMSUFDest, char* pICMSInter, char* pICMSInterPart, char* vFCPUFDestOp, char* vICMSUFDest, char* vICMSUFRemet) {
    return LoadOriginalDLL() && f_InformaICMSUFDest ? f_InformaICMSUFDest(nItem, vBCUFDest, vBCFCPUFDest, pFCPUFDestOp, pICMSUFDest, pICMSInter, pICMSInterPart, vFCPUFDestOp, vICMSUFDest, vICMSUFRemet) : -1;
}

__declspec(dllexport) int __stdcall InformaIPITrib(int nItem, char* CNPJProdOp, char* cSeloOp, char* qSeloOp, char* cEnq, char* CST, char* vBC_aEx, char* pIPI_aEx, char* qUnid_bEx, char* vUnid_bEx, char* vIPI) {
    return LoadOriginalDLL() && f_InformaIPITrib ? f_InformaIPITrib(nItem, CNPJProdOp, cSeloOp, qSeloOp, cEnq, CST, vBC_aEx, pIPI_aEx, qUnid_bEx, vUnid_bEx, vIPI) : -1;
}

__declspec(dllexport) int __stdcall InformaIPINT(int nItem, char* CNPJProdOp, char* cSeloOp, char* qSeloOp, char* cEnq, char* CST) {
    return LoadOriginalDLL() && f_InformaIPINT ? f_InformaIPINT(nItem, CNPJProdOp, cSeloOp, qSeloOp, cEnq, CST) : -1;
}

__declspec(dllexport) int __stdcall InformaII(int nItem, char* vBC, char* vDespAdu, char* vII, char* vIOF) {
    return LoadOriginalDLL() && f_InformaII ? f_InformaII(nItem, vBC, vDespAdu, vII, vIOF) : -1;
}

__declspec(dllexport) int __stdcall InformaPISAliq(int nItem, char* CST, char* vBC, char* pPIS, char* vPIS) {
    return LoadOriginalDLL() && f_InformaPISAliq ? f_InformaPISAliq(nItem, CST, vBC, pPIS, vPIS) : -1;
}

__declspec(dllexport) int __stdcall InformaPISQtde(int nItem, char* CST, char* qBCProd, char* vAliqProd, char* vPIS) {
    return LoadOriginalDLL() && f_InformaPISQtde ? f_InformaPISQtde(nItem, CST, qBCProd, vAliqProd, vPIS) : -1;
}

__declspec(dllexport) int __stdcall InformaPISNT(int nItem, char* CST) {
    return LoadOriginalDLL() && f_InformaPISNT ? f_InformaPISNT(nItem, CST) : -1;
}

__declspec(dllexport) int __stdcall InformaPISOutr(int nItem, char* CST, char* vBC_aEx, char* pPIS_aEx, char* qBCProd_bEx, char* vAliqProd_bEx, char* vPIS) {
    return LoadOriginalDLL() && f_InformaPISOutr ? f_InformaPISOutr(nItem, CST, vBC_aEx, pPIS_aEx, qBCProd_bEx, vAliqProd_bEx, vPIS) : -1;
}

__declspec(dllexport) int __stdcall InformaPISST(int nItem, char* vBC_aEx, char* pPIS_aEx, char* qBCProd_bEx, char* vAliqProd_bEx, char* vPIS) {
    return LoadOriginalDLL() && f_InformaPISST ? f_InformaPISST(nItem, vBC_aEx, pPIS_aEx, qBCProd_bEx, vAliqProd_bEx, vPIS) : -1;
}

__declspec(dllexport) int __stdcall InformaCOFINSAliq(int nItem, char* CST, char* vBC, char* pCOFINS, char* vCOFINS) {
    return LoadOriginalDLL() && f_InformaCOFINSAliq ? f_InformaCOFINSAliq(nItem, CST, vBC, pCOFINS, vCOFINS) : -1;
}

__declspec(dllexport) int __stdcall InformaCOFINSQtde(int nItem, char* CST, char* qBCProd, char* vAliqProd, char* vCOFINS) {
    return LoadOriginalDLL() && f_InformaCOFINSQtde ? f_InformaCOFINSQtde(nItem, CST, qBCProd, vAliqProd, vCOFINS) : -1;
}

__declspec(dllexport) int __stdcall InformaCOFINSNT(int nItem, char* CST) {
    return LoadOriginalDLL() && f_InformaCOFINSNT ? f_InformaCOFINSNT(nItem, CST) : -1;
}

__declspec(dllexport) int __stdcall InformaCOFINSOutr(int nItem, char* CST, char* vBC_aEx, char* pCOFINS_aEx, char* qBCProd_bEx, char* vAliqProd_bEx, char* vCOFINS) {
    return LoadOriginalDLL() && f_InformaCOFINSOutr ? f_InformaCOFINSOutr(nItem, CST, vBC_aEx, pCOFINS_aEx, qBCProd_bEx, vAliqProd_bEx, vCOFINS) : -1;
}

__declspec(dllexport) int __stdcall InformaCOFINSST(int nItem, char* vBC_aEx, char* pCOFINS_aEx, char* qBCProd_bEx, char* vAliqProd_bEx, char* vCOFINS) {
    return LoadOriginalDLL() && f_InformaCOFINSST ? f_InformaCOFINSST(nItem, vBC_aEx, pCOFINS_aEx, qBCProd_bEx, vAliqProd_bEx, vCOFINS) : -1;
}

__declspec(dllexport) int __stdcall InformaISSQN(int nItem, char* vBC, char* vAliq, char* vISSQN, char* cMunFG, char* cListServ, char* vDeducaoOp, char* vOutroOp, char* vDescIncondOp, char* vDescCondOp, char* vISSRetOp, int indISS, char* cServicoOp, char* cMunOp, char* cPaisOp, char* nProcessoOp, int indIncentivo) {
    return LoadOriginalDLL() && f_InformaISSQN ? f_InformaISSQN(nItem, vBC, vAliq, vISSQN, cMunFG, cListServ, vDeducaoOp, vOutroOp, vDescIncondOp, vDescCondOp, vISSRetOp, indISS, cServicoOp, cMunOp, cPaisOp, nProcessoOp, indIncentivo) : -1;
}

__declspec(dllexport) int __stdcall InformaIPIDevolvido(int nItem, char* pDevol, char* vIPIDevol) {
    return LoadOriginalDLL() && f_InformaIPIDevolvido ? f_InformaIPIDevolvido(nItem, pDevol, vIPIDevol) : -1;
}

__declspec(dllexport) int __stdcall InformaObservacaoContribuinteItem(int nItem, char* xCampo, char* xTexto) {
    return LoadOriginalDLL() && f_InformaObservacaoContribuinteItem ? f_InformaObservacaoContribuinteItem(nItem, xCampo, xTexto) : -1;
}

__declspec(dllexport) int __stdcall InformaObservacaoFiscoItem(int nItem, char* xCampo, char* xTexto) {
    return LoadOriginalDLL() && f_InformaObservacaoFiscoItem ? f_InformaObservacaoFiscoItem(nItem, xCampo, xTexto) : -1;
}

__declspec(dllexport) int __stdcall InformaTransporte(int modFrete, char* vagaoEx, char* balsaEx) {
    return LoadOriginalDLL() && f_InformaTransporte ? f_InformaTransporte(modFrete, vagaoEx, balsaEx) : -1;
}

__declspec(dllexport) int __stdcall InformaTransportador(char* CNPJEx, char* CPFEx, char* xNomeOp, char* IEOp, char* xEnderOp, char* xMunOp, char* UFOp) {
    return LoadOriginalDLL() && f_InformaTransportador ? f_InformaTransportador(CNPJEx, CPFEx, xNomeOp, IEOp, xEnderOp, xMunOp, UFOp) : -1;
}

__declspec(dllexport) int __stdcall InformaRetencaoTransporte(char* vServ, char* vBCRet, char* pICMSRet, char* vICMSRet, char* CFOP, char* cMunFG) {
    return LoadOriginalDLL() && f_InformaRetencaoTransporte ? f_InformaRetencaoTransporte(vServ, vBCRet, pICMSRet, vICMSRet, CFOP, cMunFG) : -1;
}

__declspec(dllexport) int __stdcall InformaVeiculoTransporte(char* placa, char* UF, char* RNTCOp) {
    return LoadOriginalDLL() && f_InformaVeiculoTransporte ? f_InformaVeiculoTransporte(placa, UF, RNTCOp) : -1;
}

__declspec(dllexport) int __stdcall InformaReboque(char* placa, char* UF, char* RNTCOp) {
    return LoadOriginalDLL() && f_InformaReboque ? f_InformaReboque(placa, UF, RNTCOp) : -1;
}

__declspec(dllexport) int __stdcall InformaVolume(char* qVolOp, char* espOp, char* marcaOp, char* nVolOp, char* pesoLOp, char* pesoBOp) {
    return LoadOriginalDLL() && f_InformaVolume ? f_InformaVolume(qVolOp, espOp, marcaOp, nVolOp, pesoLOp, pesoBOp) : -1;
}

__declspec(dllexport) int __stdcall InformaLacre(int nVolume, char* nLacre) {
    return LoadOriginalDLL() && f_InformaLacre ? f_InformaLacre(nVolume, nLacre) : -1;
}

__declspec(dllexport) int __stdcall InformaFatura(char* nFatOp, char* vOrigOp, char* vDescOp, char* vLiqOp) {
    return LoadOriginalDLL() && f_InformaFatura ? f_InformaFatura(nFatOp, vOrigOp, vDescOp, vLiqOp) : -1;
}

__declspec(dllexport) int __stdcall InformaParcela(char* nDupOp, char* dVencOp, char* vDup) {
    return LoadOriginalDLL() && f_InformaParcela ? f_InformaParcela(nDupOp, dVencOp, vDup) : -1;
}

__declspec(dllexport) int __stdcall InformaInformacoesPagamento(char* vTrocoOp, char* CNPJPag_a, char* UFPag_a) {
    return LoadOriginalDLL() && f_InformaInformacoesPagamento ? f_InformaInformacoesPagamento(vTrocoOp, CNPJPag_a, UFPag_a) : -1;
}

__declspec(dllexport) int __stdcall InformaPagamento(int indPagOp, char* tPag, char* xPagOp, char* vPag, char* dPagOp, int tpIntegra, char* CNPJOp, char* tBandOp, char* cAutOp, char* CNPJRecebOp, char* idTermPagOp) {
    return LoadOriginalDLL() && f_InformaPagamento ? f_InformaPagamento(indPagOp, tPag, xPagOp, vPag, dPagOp, tpIntegra, CNPJOp, tBandOp, cAutOp, CNPJRecebOp, idTermPagOp) : -1;
}

__declspec(dllexport) int __stdcall InformaIntermediador(char* CNPJ, char* idCadIntTran) {
    return LoadOriginalDLL() && f_InformaIntermediador ? f_InformaIntermediador(CNPJ, idCadIntTran) : -1;
}

__declspec(dllexport) int __stdcall InformaInformacoesAdicionais(char* infAdFiscoOp, char* infCplOp) {
    return LoadOriginalDLL() && f_InformaInformacoesAdicionais ? f_InformaInformacoesAdicionais(infAdFiscoOp, infCplOp) : -1;
}

__declspec(dllexport) int __stdcall InformaObservacoesContribuinte(char* xCampo, char* xTexto) {
    return LoadOriginalDLL() && f_InformaObservacoesContribuinte ? f_InformaObservacoesContribuinte(xCampo, xTexto) : -1;
}

__declspec(dllexport) int __stdcall InformaObservacoesFisco(char* xCampo, char* xTexto) {
    return LoadOriginalDLL() && f_InformaObservacoesFisco ? f_InformaObservacoesFisco(xCampo, xTexto) : -1;
}

__declspec(dllexport) int __stdcall InformaProcessoReferenciado(char* nProc, int indProc, char* tpAtoOp) {
    return LoadOriginalDLL() && f_InformaProcessoReferenciado ? f_InformaProcessoReferenciado(nProc, indProc, tpAtoOp) : -1;
}

__declspec(dllexport) int __stdcall InformaExportacao(char* UFSaidaPais, char* xLocExporta, char* xLocDespachoOp) {
    return LoadOriginalDLL() && f_InformaExportacao ? f_InformaExportacao(UFSaidaPais, xLocExporta, xLocDespachoOp) : -1;
}

__declspec(dllexport) int __stdcall InformaCompra(char* xNEmpOp, char* xPedOp, char* xContOp) {
    return LoadOriginalDLL() && f_InformaCompra ? f_InformaCompra(xNEmpOp, xPedOp, xContOp) : -1;
}

__declspec(dllexport) int __stdcall InformaCana(char* safra, char* ref, char* qTotMes, char* qTotAnt, char* qTotGer, char* vFor, char* vTotDed, char* vLiqFor) {
    return LoadOriginalDLL() && f_InformaCana ? f_InformaCana(safra, ref, qTotMes, qTotAnt, qTotGer, vFor, vTotDed, vLiqFor) : -1;
}

__declspec(dllexport) int __stdcall InformaFornecimentoDiarioCana(char* dia, char* qtde) {
    return LoadOriginalDLL() && f_InformaFornecimentoDiarioCana ? f_InformaFornecimentoDiarioCana(dia, qtde) : -1;
}

__declspec(dllexport) int __stdcall InformaDeducaoCana(char* xDed, char* vDed) {
    return LoadOriginalDLL() && f_InformaDeducaoCana ? f_InformaDeducaoCana(xDed, vDed) : -1;
}

__declspec(dllexport) int __stdcall InformaResponsavelTecnico(char* CNPJ, char* xContato, char* email, char* fone, char* idCSRT_a, char* hashCSRT_a) {
    return LoadOriginalDLL() && f_InformaResponsavelTecnico ? f_InformaResponsavelTecnico(CNPJ, xContato, email, fone, idCSRT_a, hashCSRT_a) : -1;
}

__declspec(dllexport) int __stdcall InformaInformacoesSuplementares(char* qrCode, char* urlChave) {
    return LoadOriginalDLL() && f_InformaInformacoesSuplementares ? f_InformaInformacoesSuplementares(qrCode, urlChave) : -1;
}

__declspec(dllexport) int __stdcall FechaCupomVenda(char* path) {
    return LoadOriginalDLL() && f_FechaCupomVenda ? f_FechaCupomVenda(path) : -1;
}

__declspec(dllexport) int __stdcall LoadPDF() {
    return LoadOriginalDLL() && f_LoadPDF ? f_LoadPDF() : -1;
}

__declspec(dllexport) void __stdcall ConfigurarDiretorioSaidaPDF(char* path, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_ConfigurarDiretorioSaidaPDF) {
        char* result = f_ConfigurarDiretorioSaidaPDF(path);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall GerarDanfeNFCePDF(char* path, int indexcsc, char* csc, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_GerarDanfeNFCePDF) {
        char* result = f_GerarDanfeNFCePDF(path, indexcsc, csc);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall GerarDanfeNFCePersonalizadoPDF(char* path, int indexcsc, char* csc, int param, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_GerarDanfeNFCePersonalizadoPDF) {
        char* result = f_GerarDanfeNFCePersonalizadoPDF(path, indexcsc, csc, param);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall GerarDanfeNFePDF(char* path, char* logoPath, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_GerarDanfeNFePDF) {
        char* result = f_GerarDanfeNFePDF(path, logoPath);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) void __stdcall GerarDanfeNFePersonalizadoPDF(char* path, char* logoPath, int layout, int param, char* buffer, int bufSize) {
    if (LoadOriginalDLL() && f_GerarDanfeNFePersonalizadoPDF) {
        char* result = f_GerarDanfeNFePersonalizadoPDF(path, logoPath, layout, param);
        if (result && buffer && bufSize > 0) {
            strncpy(buffer, result, bufSize - 1);
            buffer[bufSize - 1] = 0;
        }
    }
}

__declspec(dllexport) int __stdcall UnloadPDF() {
    return LoadOriginalDLL() && f_UnloadPDF ? f_UnloadPDF() : -1;
}