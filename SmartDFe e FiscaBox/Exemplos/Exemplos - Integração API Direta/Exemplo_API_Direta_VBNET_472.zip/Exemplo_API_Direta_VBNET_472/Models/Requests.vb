Imports System.Text.Json.Serialization

Namespace Models
    Public Class CancelarNotaRequest
        <JsonPropertyName("justificativa")>
        Public Property Justificativa As String

        <JsonPropertyName("protocolo")>
        Public Property Protocolo As String
    End Class

    Public Class CancelamentoPorSubstituicaoRequest
        <JsonPropertyName("chCFeRef")>
        Public Property ChCFeRef As String

        <JsonPropertyName("tpAutor")>
        Public Property TpAutor As Integer

        <JsonPropertyName("xJust")>
        Public Property XJust As String
    End Class

    Public Class CartaCorrecaoRequest
        <JsonPropertyName("xCorrecao")>
        Public Property XCorrecao As String
    End Class

    Public Class InutilizarNumeracaoRequest
        <JsonPropertyName("ano")>
        Public Property Ano As String

        <JsonPropertyName("cnpj")>
        Public Property Cnpj As String

        <JsonPropertyName("justificativa")>
        Public Property Justificativa As String

        <JsonPropertyName("numeroFinal")>
        Public Property NumeroFinal As Integer

        <JsonPropertyName("numeroInicial")>
        Public Property NumeroInicial As Integer

        <JsonPropertyName("serie")>
        Public Property Serie As Integer

        <JsonPropertyName("tpAmb")>
        Public Property TpAmb As Integer

        <JsonPropertyName("uf")>
        Public Property Uf As String
    End Class
End Namespace
