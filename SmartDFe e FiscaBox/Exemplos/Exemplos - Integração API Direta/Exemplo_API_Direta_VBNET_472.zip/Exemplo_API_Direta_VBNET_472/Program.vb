Imports System
Imports System.Threading.Tasks
Imports SmartNFCeAppVBNET.Services
Imports SmartNFCeAppVBNET.Models

Public Module Program
    Public Sub Main(args As String())
        MainAsync(args).GetAwaiter().GetResult()
    End Sub

    Public Async Function MainAsync(args As String()) As Task
        Console.Clear()
        Console.WriteLine("========================================")
        Console.WriteLine("    SMARTNFCE CLI - CLIENTE VB.NET")
        Console.WriteLine("========================================")

        ' Configurações Iniciais
        Dim baseUrl As String = "http://localhost:3001"
        Console.Write($"Informe a URL da API (Padrão: {baseUrl}): ")
        Dim inputUrl As String = Console.ReadLine()
        If Not String.IsNullOrWhiteSpace(inputUrl) Then baseUrl = inputUrl

        Using client As New SmartNFCeClient(baseUrl)
            Dim exitApp As Boolean = False
            While Not exitApp
                Console.WriteLine("\n----------------------------------------")
                Console.WriteLine("MENU DE OPERAÇÕES:")
                Console.WriteLine("1. Emitir Nota (XML UUID)")
                Console.WriteLine("2. Cancelar Nota")
                Console.WriteLine("3. Cancelamento por Substituição")
                Console.WriteLine("4. Carta de Correção (Substituição)")
                Console.WriteLine("5. Inutilizar Numeração")
                Console.WriteLine("6. Processamento em Contingência")
                Console.WriteLine("7. Consultar Nota (Chave)")
                Console.WriteLine("8. Consultar Status por UUID")
                Console.WriteLine("0. Sair")
                Console.WriteLine("----------------------------------------")
                Console.Write("Escolha uma opção: ")

                Dim optionStr As String = Console.ReadLine()
                Console.WriteLine()

                Try
                    Select Case optionStr
                        Case "1"
                            Await MenuEmitirNota(client)
                        Case "2"
                            Await MenuCancelarNota(client)
                        Case "3"
                            Await MenuCancelamentoSubstituicao(client)
                        Case "4"
                            Await MenuCartaCorrecao(client)
                        Case "5"
                            Await MenuInutilizar(client)
                        Case "6"
                            Console.WriteLine("Processando contingência...")
                            Console.WriteLine(Await client.ProcessamentoContingenciaAsync())
                        Case "7"
                            Await MenuConsultarNota(client)
                        Case "8"
                            Await MenuConsultarStatusUUID(client)
                        Case "0"
                            exitApp = True
                        Case Else
                            Console.WriteLine("Opção inválida!")
                    End Select
                Catch ex As Exception
                    Console.WriteLine($"\n[ERRO]: {ex.Message}")
                End Try

                If Not exitApp Then
                    Console.WriteLine("\nPressione qualquer tecla para voltar ao menu...")
                    Console.ReadKey()
                End If
            End While
        End Using

        Console.WriteLine("\nEncerrando aplicação...")
    End Function

    Async Function MenuEmitirNota(client As SmartNFCeClient) As Task
        Console.Write("Informe o UUID: ")
        Dim uuid As String = Console.ReadLine()
        Console.Write("Informe o caminho completo do arquivo XML: ")
        Dim path As String = Console.ReadLine()

        If System.IO.File.Exists(path) Then
            Console.WriteLine("Enviando...")
            Console.WriteLine(Await client.EmitirNotaUUIDAsync(uuid, path))
        Else
            Console.WriteLine("Arquivo não encontrado!")
        End If
    End Function

    Async Function MenuCancelarNota(client As SmartNFCeClient) As Task
        Console.Write("Informe a Chave da Nota: ")
        Dim chave As String = Console.ReadLine()
        Console.Write("Justificativa: ")
        Dim just As String = Console.ReadLine()
        Console.Write("Protocolo: ")
        Dim prot As String = Console.ReadLine()

        Dim req As New CancelarNotaRequest With {.Justificativa = just, .Protocolo = prot}
        Console.WriteLine(Await client.CancelarNotaAsync(chave, req))
    End Function

    Async Function MenuCancelamentoSubstituicao(client As SmartNFCeClient) As Task
        Console.Write("Informe a Chave da Nota: ")
        Dim chave As String = Console.ReadLine()
        Console.Write("Chave Ref: ")
        Dim chRef As String = Console.ReadLine()
        Console.Write("Tipo Autor (ex: 3): ")
        Dim tpAutor As Integer
        Integer.TryParse(Console.ReadLine(), tpAutor)
        Console.Write("Justificativa: ")
        Dim just As String = Console.ReadLine()

        Dim req As New CancelamentoPorSubstituicaoRequest With {.ChCFeRef = chRef, .TpAutor = tpAutor, .XJust = just}
        Console.WriteLine(Await client.CancelamentoPorSubstituicaoAsync(chave, req))
    End Function

    Async Function MenuCartaCorrecao(client As SmartNFCeClient) As Task
        Console.Write("Informe a Chave da Nota: ")
        Dim chave As String = Console.ReadLine()
        Console.Write("Correção: ")
        Dim corr As String = Console.ReadLine()

        Dim req As New CartaCorrecaoRequest With {.XCorrecao = corr}
        Console.WriteLine(Await client.CartaDeSubstituicaoAsync(chave, req))
    End Function

    Async Function MenuInutilizar(client As SmartNFCeClient) As Task
        Dim req As New InutilizarNumeracaoRequest()
        Console.Write("Ano (ex: 25): ")
        req.Ano = Console.ReadLine()
        Console.Write("CNPJ: ")
        req.Cnpj = Console.ReadLine()
        Console.Write("Justificativa: ")
        req.Justificativa = Console.ReadLine()
        Console.Write("Número Inicial: ")
        Dim ni As Integer
        Integer.TryParse(Console.ReadLine(), ni)
        req.NumeroInicial = ni
        Console.Write("Número Final: ")
        Dim nf As Integer
        Integer.TryParse(Console.ReadLine(), nf)
        req.NumeroFinal = nf
        Console.Write("Série: ")
        Dim s As Integer
        Integer.TryParse(Console.ReadLine(), s)
        req.Serie = s
        Console.Write("Ambiente (1/2): ")
        Dim amb As Integer
        Integer.TryParse(Console.ReadLine(), amb)
        req.TpAmb = amb
        Console.Write("UF (Código): ")
        req.Uf = Console.ReadLine()

        Console.WriteLine(Await client.InutilizarNumeracaoAsync(req))
    End Function

    Async Function MenuConsultarNota(client As SmartNFCeClient) As Task
        Console.Write("Informe a Chave da Nota: ")
        Dim chave As String = Console.ReadLine()
        Console.WriteLine(Await client.ConsultaNotaAsync(chave))
    End Function

    Async Function MenuConsultarStatusUUID(client As SmartNFCeClient) As Task
        Console.Write("Informe o UUID: ")
        Dim uuid As String = Console.ReadLine()
        Console.WriteLine(Await client.ConsultaStatusUUIDAsync(uuid))
    End Function
End Module
