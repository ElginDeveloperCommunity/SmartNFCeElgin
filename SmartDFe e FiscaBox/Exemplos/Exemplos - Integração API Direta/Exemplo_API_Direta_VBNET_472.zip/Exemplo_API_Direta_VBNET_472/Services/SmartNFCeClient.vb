Imports System
Imports System.IO
Imports System.Net.Http
Imports System.Net.Http.Headers
Imports System.Text
Imports System.Text.Json
Imports System.Threading.Tasks
Imports SmartNFCeAppVBNET.Models

Namespace Services
    Public Class SmartNFCeClient
        Implements IDisposable

        Private ReadOnly _httpClient As HttpClient
        Private ReadOnly _baseUrl As String

        Public Sub New(baseUrl As String)
            _baseUrl = baseUrl.TrimEnd("/"c)

            ' Configurações de segurança para .NET 4.7.2
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12
            System.Net.ServicePointManager.Expect100Continue = False

            _httpClient = New HttpClient()
            _httpClient.DefaultRequestHeaders.Accept.Add(New MediaTypeWithQualityHeaderValue("application/json"))
        End Sub

        Public Async Function EmitirNotaUUIDAsync(uuid As String, xmlPath As String) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/xml/{uuid}"

            Using content As New MultipartFormDataContent()
                ' Usar ByteArrayContent é mais seguro no .NET 4.7.2 para evitar erros de fluxo
                Dim fileBytes = File.ReadAllBytes(xmlPath)
                Dim fileContent As New ByteArrayContent(fileBytes)
                fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/xml")
                
                content.Add(fileContent, "xml", Path.GetFileName(xmlPath))

                Dim response = Await _httpClient.PostAsync(url, content)
                Return Await response.Content.ReadAsStringAsync()
            End Using
        End Function

        Public Async Function CancelarNotaAsync(chave As String, request As CancelarNotaRequest) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/{chave}/cancel"
            Dim json = JsonSerializer.Serialize(request)
            Dim content As New StringContent(json, Encoding.UTF8, "application/json")

            Dim response = Await _httpClient.PostAsync(url, content)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Async Function CancelamentoPorSubstituicaoAsync(chave As String, request As CancelamentoPorSubstituicaoRequest) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/{chave}/cancellationBySubstitution"
            Dim json = JsonSerializer.Serialize(request)
            Dim content As New StringContent(json, Encoding.UTF8, "application/json")

            Dim response = Await _httpClient.PostAsync(url, content)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Async Function CartaDeSubstituicaoAsync(chave As String, request As CartaCorrecaoRequest) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfe/{chave}/electronicCorrectionLetter"
            Dim json = JsonSerializer.Serialize(request)
            Dim content As New StringContent(json, Encoding.UTF8, "application/json")

            Dim response = Await _httpClient.PostAsync(url, content)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Async Function InutilizarNumeracaoAsync(request As InutilizarNumeracaoRequest) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/discard"
            Dim json = JsonSerializer.Serialize(request)
            Dim content As New StringContent(json, Encoding.UTF8, "application/json")

            Dim response = Await _httpClient.PostAsync(url, content)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Async Function ProcessamentoContingenciaAsync() As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/processamentocontigencia"
            Dim response = Await _httpClient.GetAsync(url)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Async Function ConsultaNotaAsync(chave As String) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/{chave}"
            Dim response = Await _httpClient.GetAsync(url)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Async Function ConsultaStatusUUIDAsync(uuid As String) As Task(Of String)
            Dim url = $"{_baseUrl}/api/v1/nfce/authorization/status/{uuid}"
            Dim response = Await _httpClient.GetAsync(url)
            Return Await response.Content.ReadAsStringAsync()
        End Function

        Public Sub Dispose() Implements IDisposable.Dispose
            _httpClient?.Dispose()
        End Sub
    End Class
End Namespace
