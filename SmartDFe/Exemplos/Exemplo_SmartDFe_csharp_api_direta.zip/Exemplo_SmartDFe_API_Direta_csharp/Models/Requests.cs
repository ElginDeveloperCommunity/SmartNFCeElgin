using System.Text.Json.Serialization;

namespace SmartNFCeApp.Models
{
    public class CancelarNotaRequest
    {
        [JsonPropertyName("justificativa")]
        public string Justificativa { get; set; }

        [JsonPropertyName("protocolo")]
        public string Protocolo { get; set; }
    }

    public class CancelamentoPorSubstituicaoRequest
    {
        [JsonPropertyName("chCFeRef")]
        public string ChCFeRef { get; set; }

        [JsonPropertyName("tpAutor")]
        public int TpAutor { get; set; }

        [JsonPropertyName("xJust")]
        public string XJust { get; set; }
    }

    public class CartaCorrecaoRequest
    {
        [JsonPropertyName("xCorrecao")]
        public string XCorrecao { get; set; }
    }

    public class InutilizarNumeracaoRequest
    {
        [JsonPropertyName("ano")]
        public string Ano { get; set; }

        [JsonPropertyName("cnpj")]
        public string Cnpj { get; set; }

        [JsonPropertyName("justificativa")]
        public string Justificativa { get; set; }

        [JsonPropertyName("numeroFinal")]
        public int NumeroFinal { get; set; }

        [JsonPropertyName("numeroInicial")]
        public int NumeroInicial { get; set; }

        [JsonPropertyName("serie")]
        public int Serie { get; set; }

        [JsonPropertyName("tpAmb")]
        public int TpAmb { get; set; }

        [JsonPropertyName("uf")]
        public string Uf { get; set; }
    }
}
