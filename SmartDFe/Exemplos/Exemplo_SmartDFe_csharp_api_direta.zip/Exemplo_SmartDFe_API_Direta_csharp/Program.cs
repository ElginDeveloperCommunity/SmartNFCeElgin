using System;
using System.Threading.Tasks;
using SmartNFCeApp.Services;
using SmartNFCeApp.Models;

namespace SmartNFCeApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("========================================");
            Console.WriteLine("    SMARTNFCE CLI - CLIENTE C#");
            Console.WriteLine("========================================");

            // Configurações Iniciais
            string baseUrl = "http://localhost:3001";
            Console.Write($"Informe a URL da API (Padrão: {baseUrl}): ");
            string inputUrl = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(inputUrl)) baseUrl = inputUrl;

            using var client = new SmartNFCeClient(baseUrl);

            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n----------------------------------------");
                Console.WriteLine("MENU DE OPERAÇÕES:");
                Console.WriteLine("1. Emitir Nota (XML UUID)");
                Console.WriteLine("2. Cancelar Nota");
                Console.WriteLine("3. Cancelamento por Substituição");
                Console.WriteLine("4. Carta de Correção (Substituição)");
                Console.WriteLine("5. Inutilizar Numeração");
                Console.WriteLine("6. Processamento em Contingência");
                Console.WriteLine("7. Consultar Nota (Chave)");
                Console.WriteLine("8. Consultar Status por UUID");
                Console.WriteLine("0. Sair");
                Console.WriteLine("----------------------------------------");
                Console.Write("Escolha uma opção: ");

                string option = Console.ReadLine();
                Console.WriteLine();

                try
                {
                    switch (option)
                    {
                        case "1":
                            await MenuEmitirNota(client);
                            break;
                        case "2":
                            await MenuCancelarNota(client);
                            break;
                        case "3":
                            await MenuCancelamentoSubstituicao(client);
                            break;
                        case "4":
                            await MenuCartaCorrecao(client);
                            break;
                        case "5":
                            await MenuInutilizar(client);
                            break;
                        case "6":
                            Console.WriteLine("Processando contingência...");
                            Console.WriteLine(await client.ProcessamentoContingenciaAsync());
                            break;
                        case "7":
                            await MenuConsultarNota(client);
                            break;
                        case "8":
                            await MenuConsultarStatusUUID(client);
                            break;
                        case "0":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"\n[ERRO]: {ex.Message}");
                }

                if (!exit)
                {
                    Console.WriteLine("\nPressione qualquer tecla para voltar ao menu...");
                    Console.ReadKey();
                }
            }

            Console.WriteLine("\nEncerrando aplicação...");
        }

        static async Task MenuEmitirNota(SmartNFCeClient client)
        {
            Console.Write("Informe o UUID: ");
            string uuid = Console.ReadLine();
            Console.Write("Informe o caminho completo do arquivo XML: ");
            string path = Console.ReadLine();
            
            if (System.IO.File.Exists(path))
            {
                Console.WriteLine("Enviando...");
                Console.WriteLine(await client.EmitirNotaUUIDAsync(uuid, path));
            }
            else
            {
                Console.WriteLine("Arquivo não encontrado!");
            }
        }

        static async Task MenuCancelarNota(SmartNFCeClient client)
        {
            Console.Write("Informe a Chave da Nota: ");
            string chave = Console.ReadLine();
            Console.Write("Justificativa: ");
            string just = Console.ReadLine();
            Console.Write("Protocolo: ");
            string prot = Console.ReadLine();

            var req = new CancelarNotaRequest { Justificativa = just, Protocolo = prot };
            Console.WriteLine(await client.CancelarNotaAsync(chave, req));
        }

        static async Task MenuCancelamentoSubstituicao(SmartNFCeClient client)
        {
            Console.Write("Informe a Chave da Nota: ");
            string chave = Console.ReadLine();
            Console.Write("Chave Ref: ");
            string chRef = Console.ReadLine();
            Console.Write("Tipo Autor (ex: 3): ");
            int.TryParse(Console.ReadLine(), out int tpAutor);
            Console.Write("Justificativa: ");
            string just = Console.ReadLine();

            var req = new CancelamentoPorSubstituicaoRequest { ChCFeRef = chRef, TpAutor = tpAutor, XJust = just };
            Console.WriteLine(await client.CancelamentoPorSubstituicaoAsync(chave, req));
        }

        static async Task MenuCartaCorrecao(SmartNFCeClient client)
        {
            Console.Write("Informe a Chave da Nota: ");
            string chave = Console.ReadLine();
            Console.Write("Correção: ");
            string corr = Console.ReadLine();

            var req = new CartaCorrecaoRequest { XCorrecao = corr };
            Console.WriteLine(await client.CartaDeSubstituicaoAsync(chave, req));
        }

        static async Task MenuInutilizar(SmartNFCeClient client)
        {
            var req = new InutilizarNumeracaoRequest();
            Console.Write("Ano (ex: 25): "); req.Ano = Console.ReadLine();
            Console.Write("CNPJ: "); req.Cnpj = Console.ReadLine();
            Console.Write("Justificativa: "); req.Justificativa = Console.ReadLine();
            Console.Write("Número Inicial: "); int.TryParse(Console.ReadLine(), out int ni); req.NumeroInicial = ni;
            Console.Write("Número Final: "); int.TryParse(Console.ReadLine(), out int nf); req.NumeroFinal = nf;
            Console.Write("Série: "); int.TryParse(Console.ReadLine(), out int s); req.Serie = s;
            Console.Write("Ambiente (1/2): "); int.TryParse(Console.ReadLine(), out int amb); req.TpAmb = amb;
            Console.Write("UF (Código): "); req.Uf = Console.ReadLine();

            Console.WriteLine(await client.InutilizarNumeracaoAsync(req));
        }

        static async Task MenuConsultarNota(SmartNFCeClient client)
        {
            Console.Write("Informe a Chave da Nota: ");
            string chave = Console.ReadLine();
            Console.WriteLine(await client.ConsultaNotaAsync(chave));
        }

        static async Task MenuConsultarStatusUUID(SmartNFCeClient client)
        {
            Console.Write("Informe o UUID: ");
            string uuid = Console.ReadLine();
            Console.WriteLine(await client.ConsultaStatusUUIDAsync(uuid));
        }
    }
}
