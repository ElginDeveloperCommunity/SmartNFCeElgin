using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using SmartNFCeApp.Models;

namespace SmartNFCeApp.Services
{
    public class SmartNFCeClient : IDisposable
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;

        public SmartNFCeClient(string baseUrl)
        {
            _baseUrl = baseUrl.TrimEnd('/');
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<string> EmitirNotaUUIDAsync(string uuid, string xmlPath)
        {
            var url = $"{_baseUrl}/api/v1/nfce/xml/{uuid}";
            
            using var content = new MultipartFormDataContent();
            var fileContent = new ByteArrayContent(await File.ReadAllBytesAsync(xmlPath));
            fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/octet-stream");
            content.Add(fileContent, "xml", Path.GetFileName(xmlPath));

            var response = await _httpClient.PostAsync(url, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> CancelarNotaAsync(string chave, CancelarNotaRequest request)
        {
            var url = $"{_baseUrl}/api/v1/nfce/{chave}/cancel";
            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(url, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> CancelamentoPorSubstituicaoAsync(string chave, CancelamentoPorSubstituicaoRequest request)
        {
            var url = $"{_baseUrl}/api/v1/nfce/{chave}/cancellationBySubstitution";
            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(url, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> CartaDeSubstituicaoAsync(string chave, CartaCorrecaoRequest request)
        {
            var url = $"{_baseUrl}/api/v1/nfe/{chave}/electronicCorrectionLetter";
            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(url, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> InutilizarNumeracaoAsync(InutilizarNumeracaoRequest request)
        {
            var url = $"{_baseUrl}/api/v1/nfce/discard";
            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(url, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> ProcessamentoContingenciaAsync()
        {
            var url = $"{_baseUrl}/api/v1/nfce/processamentocontigencia";
            var response = await _httpClient.GetAsync(url);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> ConsultaNotaAsync(string chave)
        {
            var url = $"{_baseUrl}/api/v1/nfce/{chave}";
            var response = await _httpClient.GetAsync(url);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> ConsultaStatusUUIDAsync(string uuid)
        {
            var url = $"{_baseUrl}/api/v1/nfce/authorization/status/{uuid}";
            var response = await _httpClient.GetAsync(url);
            return await response.Content.ReadAsStringAsync();
        }

        public void Dispose()
        {
            _httpClient?.Dispose();
        }
    }
}
