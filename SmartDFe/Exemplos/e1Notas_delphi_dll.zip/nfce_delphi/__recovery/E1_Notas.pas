unit E1_Notas;

interface

const
  LIB_NAME = 'E1_Notas.dll';


function EmitirNota(path: PAnsiChar): PAnsiChar; cdecl; external LIB_NAME;
function ConsultarNota(chave: PAnsiChar): PAnsiChar; cdecl; external LIB_NAME;
function CancelarNota(chave, protocolo, justificativa: PAnsiChar): PAnsiChar; cdecl; external LIB_NAME;
function AbreCupomVenda(chaveDeAcesso: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaIdentificacao(cUF, cNF, natOper: PAnsiChar; mod_: Integer; serie, nNF, dhEmi, dhSaiEntOp: PAnsiChar; tpNF, idDest: Integer; cMunFG: PAnsiChar; tpImp, tpEmis, cDV, tpAmb, finNFe, indFinal, indPres, indIntermedOp, procEmi: Integer; verProc, dhCont_a, xJust_a: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaEmitente(CNPJex, CPFex, xNome, xFantOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEP, cPaisOp, xPaisOp, foneOp, IE, IESTop, IM_a, CNAEop_a: PAnsiChar; CRT: Integer): Integer; cdecl; external LIB_NAME;
function InformaAvulsa(CNPJ, xOrgao, matr, xAgente, foneOp, UF, nDARop, dEmiOp, vDARop, repEmi, dPagOp: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaDestinatario(CNPJex, CPFex, idEstrangeiroEx, xNomeOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEPop, cPaisOp, xPaisOp, foneOp: PAnsiChar; indIEDest: Integer; IEop, ISUFop, IMop, emailOp: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaRetirada(CNPJex, CPFex, xNomeOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEPop, cPaisOp, xPaisOp, foneOp, emailOp, IEop: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaEntrega(CNPJex, CPFex, xNomeOp, xLgr, nro, xCplOp, xBairro, cMun, xMun, UF, CEPop, cPaisOp, xPaisOp, foneOp, emailOp, IEop: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaAutorizacaoXML(CNPJex, CPFex: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaProduto(cProd, cEAN, xProd, NCM, NVE, CEST_a, indEscalaOp_a, CNPJFabOp_a, cBenefOp, EXTIPIop, CFOP, uCom, qCom, vUnCom, vProd, cEANTrib, uTrib, qTrib, vUnTrib, vFreteOp, vSegOp, vDescOp, vOutroOp: PAnsiChar; indTot: Integer): Integer; cdecl; external LIB_NAME;
function InformaICMS00(nItem, orig: Integer; CST: PAnsiChar; modBC: Integer; vBC, pICMS, vICMS, pFCP_a, vFCP_a: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMS10(nItem, orig: Integer; CST: PAnsiChar; modBC: Integer; vBC, pICMS, vICMS, vBCFCP_a, pFCP_a, vFCP_a: PAnsiChar; modBCST: Integer; pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_b, pFCPST_b, vFCPST_b: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMS20(nItem, orig: Integer; CST: PAnsiChar; modBC: Integer; pRedBC, vBC, pICMS, vICMS, vBCFCP_a, pFCP_a, vFCP_a, vICMSDeson_b: PAnsiChar; motDesICMS_b: Integer): Integer; cdecl; external LIB_NAME;
function InformaICMS30(nItem, orig: Integer; CST: PAnsiChar; modBCST: Integer; pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, vICMSDeson_b: PAnsiChar; motDesICMS_b: Integer): Integer; cdecl; external LIB_NAME;
function InformaICMS40(nItem, orig: Integer; CST, vICMSDeson_a: PAnsiChar; motDesICMS_a: Integer): Integer; cdecl; external LIB_NAME;
function InformaICMS51(nItem, orig: Integer; CST: PAnsiChar; modBCop: Integer; pRedBCop, vBCop, pICMSop, vICMSOpOp, pDifOp, vICMSDifOp, vICMSop, vBCFCP_a, pFCP_a, vFCP_a: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMS60(nItem, orig: Integer; CST, vBCSTRet_a, pST_a, vICMSSubstitutoOp_a, vICMSSTRet_a, vBCFCPSTRet_b, pFCPSTRet_b, vFCPSTRet_b, pRedBCEfet_c, vBCEfet_c, pICMSEfet_c, vICMSEfet_c: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMS70(nItem, orig: Integer; CST: PAnsiChar; modBC: Integer; pRedBC, vBC, pICMS, vICMS, vBCFCP_a, pFCP_a, vFCP_a: PAnsiChar; modBCST: Integer; pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_b, pFCPST_b, vFCPST_b, vICMSDeson_c: PAnsiChar; motDesICMS_c: Integer): Integer; cdecl; external LIB_NAME;
function InformaICMS90(nItem, orig: Integer; CST: PAnsiChar; modBC_a: Integer; vBC_a, pRedBCop_a, pICMS_a, vICMS_a, vBCFCP_aa, pFCP_aa, vFCP_aa: PAnsiChar; modBCST_b: Integer; pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_bb, pFCPST_bb, vFCPST_bb, vICMSDeson_c: PAnsiChar; motDesICMS_c: Integer): Integer; cdecl; external LIB_NAME;
function InformaICMSPart(nItem, orig: Integer; CST: PAnsiChar; modBC: Integer; vBC, pRedBCop, pICMS, vICMS: PAnsiChar; modBCST: Integer; pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, pBCOper, UFST: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSST(nItem, orig: Integer; CST, vBCSTRet, pSTop, vICMSSubstitutoOp, vICMSSTRet, vBCFCPSTRet_a, pFCPSTRet_a, vFCPSTRet_a, vBCSTDest, vICMSSTDest, pRedBCEfet_b, vBCEfet_b, pICMSEfet_b, vICMSEfet_b: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSSN101(nItem, orig: Integer; CSOSN, pCredSN, vCredICMSSN: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSSN102(nItem, orig: Integer; CSOSN: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSSN201(nItem, orig: Integer; CSOSN: PAnsiChar; modBCST: Integer; pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a, pCredSN, vCredICMSSN: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSSN202(nItem, orig: Integer; CSOSN: PAnsiChar; modBCST: Integer; pMVASTop, pRedBCSTop, vBCST, pICMSST, vICMSST, vBCFCPST_a, pFCPST_a, vFCPST_a: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSSN500(nItem, orig: Integer; CSOSN, vBCSTRet_a, pST_a, vICMSSubstitutoOp_a, vICMSSTRet_a, vBCFCPSTRet_b, pFCPSTRet_b, vFCPSTRet_b, pRedBCEfet_c, vBCEfet_c, pICMSEfet_c, vICMSEfet_c: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSSN900(nItem, orig: Integer; CSOSN: PAnsiChar; modBC_a: Integer; vBC_a, pRedBCop_a, pICMS_a, vICMS_a: PAnsiChar; modBCST_b: Integer; pMVASTop_b, pRedBCSTop_b, vBCST_b, pICMSST_b, vICMSST_b, vBCFCPST_c, pFCPST_c, vFCPST_c, pCredSN_d, vCredICMSSN_d: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaICMSUFDest(nItem: Integer; vBCUFDest, vBCFCPUFDest, pFCPUFDestOp, pICMSUFDest, pICMSInter, pICMSInterPart, vFCPUFDestOp, vICMSUFDest, vICMSUFRemet: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaIPITrib(nItem: Integer; CNPJProdOp, cSeloOp, qSeloOp, cEnq, CST, vBC_aEx, pIPI_aEx, qUnid_bEx, vUnid_bEx, vIPI: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaIPINT(nItem: Integer; CNPJProdOp, cSeloOp, qSeloOp, cEnq, CST: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaII(nItem: Integer; vBC, vDespAdu, vII, vIOF: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaPISAliq(nItem: Integer; CST, vBC, pPIS, vPIS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaPISQtde(nItem: Integer; CST, qBCProd, vAliqProd, vPIS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaPISNT(nItem: Integer; CST: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaPISOutr(nItem: Integer; CST, vBC_aEx, pPIS_aEx, qBCProd_bEx, vAliqProd_bEx, vPIS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaPISST(nItem: Integer; vBC_aEx, pPIS_aEx, qBCProd_bEx, vAliqProd_bEx, vPIS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaCOFINSAliq(nItem: Integer; CST, vBC, pCOFINS, vCOFINS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaCOFINSQtde(nItem: Integer; CST, qBCProd, vAliqProd, vCOFINS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaCOFINSNT(nItem: Integer; CST: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaCOFINSOutr(nItem: Integer; CST, vBC_aEx, pCOFINS_aEx, qBCProd_bEx, vAliqProd_bEx, vCOFINS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaCOFINSST(nItem: Integer; vBC_aEx, pCOFINS_aEx, qBCProd_bEx, vAliqProd_bEx, vCOFINS: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaISSQN(nItem: Integer; vBC, vAliq, vISSQN, cMunFG, cListServ, vDeducaoOp, vOutroOp, vDescIncondOp, vDescCondOp, vISSRetOp: PAnsiChar; indISS: Integer; cServicoOp, cMunOp, cPaisOp, nProcessoOp: PAnsiChar; indIncentivo: Integer): Integer; cdecl; external LIB_NAME;
function InformaValorTotalTributos(nItem: Integer; vTotTrib: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaPagamento(indPagOp: Integer; tPag, vPag: PAnsiChar; tpIntegra: Integer; CNPJOp, tBandOp, cAutOp: PAnsiChar): Integer; cdecl; external LIB_NAME;
function InformaValorTroco(vTroco: PAnsiChar): Integer; cdecl; external LIB_NAME;
function FechaCupomVenda(path: PAnsiChar): Integer; cdecl; external LIB_NAME;

implementation

end.
