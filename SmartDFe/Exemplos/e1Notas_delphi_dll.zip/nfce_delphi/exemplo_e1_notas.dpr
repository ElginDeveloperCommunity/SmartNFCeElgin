﻿program exemplo_e1_notas;

{$APPTYPE CONSOLE}

uses
  System.SysUtils,
  E1_Notas,
  System.Classes,
  System.JSON,
  System.Net.Mime,
  System.IOUtils,
  IdCoderMIME,
  IdGlobal;

function DecodeBase64(const EncodedText: string): TBytes;
var
  Decoder: TIdDecoderMIME;
  Stream: TBytesStream;
begin
  Decoder := TIdDecoderMIME.Create(nil);
  Stream := TBytesStream.Create;
  try
    Decoder.DecodeStream(EncodedText, Stream);
    Stream.Position := 0;
    SetLength(Result, Stream.Size);
    Stream.Read(Result, 0, Stream.Size);
  finally
    Stream.Free;
    Decoder.Free;
  end;
end;

function DesejaGravarXML: Boolean;
var
  Resposta: string;
begin
  Write('Deseja salvar o XML? (S/N): ');
  ReadLn(Resposta);
  Result := UpperCase(Resposta) = 'S';
end;

procedure SalvarXMLRetorno(const JsonRetorno: PAnsiChar);
var
  JSONStr, BodyStr, XMLBase64, chNFe, ErrorCode: string;
  JSON, BodyJSON: TJSONObject;
  XMLBytes: TBytes;
  XMLFileName: string;
  Status: Integer;
begin
  if JsonRetorno = nil then
  begin
    WriteLn('Retorno vazio, não é possível salvar o XML.');
    Exit;
  end;

  JSONStr := string(JsonRetorno);

  try
    JSON := TJSONObject.ParseJSONValue(JSONStr) as TJSONObject;
    try
      Status := JSON.GetValue<Integer>('status');
      WriteLn('Status do retorno: ', Status);

      if Status <> 200 then
      begin
        WriteLn('Erro na operação. XML não disponível para salvamento.');
        if JSON.GetValue('message') <> nil then
          WriteLn('Message: ', JSON.GetValue<string>('message'));
        Exit;
      end;

      BodyStr := JSON.GetValue<string>('body');
      BodyJSON := TJSONObject.ParseJSONValue(BodyStr) as TJSONObject;
      try
        ErrorCode := BodyJSON.GetValue<string>('Error');
        WriteLn('Error Code: ', ErrorCode);

        if ErrorCode <> '100' then
        begin
          // Erro na emissão - mostrar mensagem de erro
          WriteLn('ERRO na emissão da NFCe!');
          WriteLn('Código do erro: ', ErrorCode);
          WriteLn('Detalhes do erro:');
          WriteLn('----------------------------------------');

          // Decodificar o XML de erro e mostrar
          if BodyJSON.GetValue('data') <> nil then
          begin
            XMLBase64 := BodyJSON.GetValue<string>('data');
            XMLBytes := DecodeBase64(XMLBase64);
            WriteLn(TEncoding.UTF8.GetString(XMLBytes));
          end;
          WriteLn('----------------------------------------');
          Exit;
        end;

        // Sucesso (Error = 100) - pode salvar o XML
        WriteLn('NFCe emitida com sucesso!');

        if not DesejaGravarXML then
        begin
          WriteLn('Operação de salvamento do XML cancelada pelo usuário.');
          Exit;
        end;

        XMLBase64 := BodyJSON.GetValue<string>('data');
        chNFe := BodyJSON.GetValue<string>('chNFe');

        XMLBytes := DecodeBase64(XMLBase64);

        XMLFileName := chNFe + '.xml';
        TFile.WriteAllBytes(XMLFileName, XMLBytes);
        WriteLn('XML salvo como: ', XMLFileName);
      finally
        BodyJSON.Free;
      end;
    finally
      JSON.Free;
    end;
  except
    on E: Exception do
      WriteLn('Erro ao processar o retorno JSON: ', E.Message);
  end;
end;

procedure EmitirNFCe;
var
  CodigoMunicipio, CNPJ, IE, RazaoSocial, NomeFantasia, Logradouro, Numero,
  Complemento, Bairro, CodMunicipio, Municipio, UF, CEP, CodigoPais, Pais,
  Fone, IM, CNAE: string;
  ret: Integer;
  resultStr: PAnsiChar;
begin
  CodigoMunicipio := '3550308';
  CNPJ := '29720473000145';
  IE := '128237060114';
  RazaoSocial := '29.720.473 FERNANDA SERAFIM ABRANTES';
  NomeFantasia := '29.720.473 FERNANDA SERAFIM ABRANTES';
  Logradouro := 'RUA JOAO JOSE DE QUEIROZ';
  Numero := '111';
  Complemento := '333';
  Bairro := 'xyz';
  CodMunicipio := '3550308';
  Municipio := 'SAO PAULO';
  UF := 'SP';
  CEP := '03.679-000';
  CodigoPais := '1058';
  Pais := 'Brasil';
  Fone := '';
  IM := '128237060114';
  CNAE := '';

  ret := AbreCupomVenda(PAnsiChar(AnsiString('12345678901234567890123456789012345678901234')));
  WriteLn('Retorno AbreCupomVenda: ', ret);

  ret := InformaIdentificacao(PAnsiChar(AnsiString('35')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('venda')), 65, PAnsiChar(AnsiString('')),
    PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), 0, 0, PAnsiChar(AnsiString(CodigoMunicipio)), 5, 0, 0, 0, 1, 1, 1, 0, 0,
    PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')));
  WriteLn('Retorno InformaIdentificacao: ', ret);

  ret := InformaEmitente(
    PAnsiChar(AnsiString(CNPJ)), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString(RazaoSocial)), PAnsiChar(AnsiString(NomeFantasia)),
    PAnsiChar(AnsiString(Logradouro)), PAnsiChar(AnsiString(Numero)), PAnsiChar(AnsiString(Complemento)), PAnsiChar(AnsiString(Bairro)),
    PAnsiChar(AnsiString(CodMunicipio)), PAnsiChar(AnsiString(Municipio)), PAnsiChar(AnsiString(UF)), PAnsiChar(AnsiString(CEP)),
    PAnsiChar(AnsiString(CodigoPais)), PAnsiChar(AnsiString(Pais)), PAnsiChar(AnsiString(Fone)), PAnsiChar(AnsiString(IE)), PAnsiChar(AnsiString('')),
    PAnsiChar(AnsiString(IM)), PAnsiChar(AnsiString(CNAE)),
    1
  );
  WriteLn('Retorno InformaEmitente: ', ret);

  ret := InformaProduto(PAnsiChar(AnsiString('123')), PAnsiChar(AnsiString('SEM GTIN')), PAnsiChar(AnsiString('NFCe - Homologacao')), PAnsiChar(AnsiString('22030000')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('0302100')), PAnsiChar(AnsiString('S')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('5102')), PAnsiChar(AnsiString('UN')), PAnsiChar(AnsiString('1.0000')), PAnsiChar(AnsiString('1.00')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('SEM GTIN')), PAnsiChar(AnsiString('UN')), PAnsiChar(AnsiString('1.0000')), PAnsiChar(AnsiString('1.00')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), 1);
  WriteLn('Retorno InformaProduto: ', ret);

  ret := InformaICMSSN102(1, 0, PAnsiChar(AnsiString('102')));
  WriteLn('Retorno InformaICMSSN102: ', ret);

  ret := InformaPISAliq(1, PAnsiChar(AnsiString('99')), PAnsiChar(AnsiString('1.00')), PAnsiChar(AnsiString('1.65')), PAnsiChar(AnsiString('0.02')));
  WriteLn('Retorno InformaPISAliq: ', ret);

  ret := InformaCOFINSAliq(1, PAnsiChar(AnsiString('01')), PAnsiChar(AnsiString('1.00')), PAnsiChar(AnsiString('7.60')), PAnsiChar(AnsiString('0.08')));
  WriteLn('Retorno InformaCOFINSAliq: ', ret);

  ret := InformaPagamento(0, PAnsiChar(AnsiString('01')), PAnsiChar(AnsiString('10000.00')), 0, PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')), PAnsiChar(AnsiString('')));
  WriteLn('Retorno InformaPagamento: ', ret);

  ret := InformaValorTroco(PAnsiChar(AnsiString('0.00')));
  WriteLn('Retorno InformaValorTroco: ', ret);

  ret := FechaCupomVenda(PAnsiChar(AnsiString('./venda_990.xml')));
  WriteLn('Retorno FechaCupomVenda: ', ret);

  resultStr := EmitirNota(PAnsiChar(AnsiString('./venda_990.xml')));
  WriteLn('Retorno EmitirNota: ', string(resultStr));

  SalvarXMLRetorno(resultStr);
end;

procedure CancelarNFCe;
var
  ChaveNFCe, Justificativa, Protocolo: string;
  resultStr: PAnsiChar;
begin
  Write('Digite a chave da NFCe que deseja cancelar: ');
  ReadLn(ChaveNFCe);
  Write('Digite o protocolo de autorização: ');
  ReadLn(Protocolo);
  Write('Digite a justificativa do cancelamento (mínimo 15 caracteres): ');
  ReadLn(Justificativa);

  if Length(Justificativa) < 15 then
  begin
    WriteLn('A justificativa deve ter no mínimo 15 caracteres!');
    Exit;
  end;

  resultStr := CancelarNota(PAnsiChar(AnsiString(ChaveNFCe)), PAnsiChar(AnsiString(Protocolo)), PAnsiChar(AnsiString(Justificativa)));
  WriteLn('Retorno CancelarNota: ', string(resultStr));
end;

procedure ExibirMenu;
begin
  WriteLn;
  WriteLn('========================================');
  WriteLn('            MENU PRINCIPAL              ');
  WriteLn('========================================');
  WriteLn('1 - Emitir NFCe');
  WriteLn('2 - Cancelar NFCe');
  WriteLn('3 - Sair');
  WriteLn('========================================');
  Write('Escolha uma opção: ');
end;

var
  Opcao: string;
begin
  try
    repeat
      ExibirMenu;
      ReadLn(Opcao);
      WriteLn;

      if Opcao = '1' then
      begin
        WriteLn('=== EMISSÃO DE NFCe ===');
        EmitirNFCe;
        WriteLn('=======================');
        WriteLn('Pressione ENTER para voltar ao menu...');
        ReadLn;
      end
      else if Opcao = '2' then
      begin
        WriteLn('=== CANCELAMENTO DE NFCe ===');
        CancelarNFCe;
        WriteLn('===========================');
        WriteLn('Pressione ENTER para voltar ao menu...');
        ReadLn;
      end
      else if Opcao = '3' then
        WriteLn('Saindo do programa...')
      else
      begin
        WriteLn('Opção inválida!');
        WriteLn('Pressione ENTER para voltar ao menu...');
        ReadLn;
      end;
      WriteLn;
    until Opcao = '3';
  except
    on E: Exception do
      WriteLn(E.ClassName, ': ', E.Message);
  end;
end.
